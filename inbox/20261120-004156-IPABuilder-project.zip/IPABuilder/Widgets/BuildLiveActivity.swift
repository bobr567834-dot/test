import ActivityKit
import SwiftUI
import WidgetKit

@main
struct BuildWidgetsBundle: WidgetBundle {
    var body: some Widget {
        BuildLiveActivity()
    }
}

private extension BuildActivityAttributes.ContentState {
    var isRunning: Bool {
        phase != .success && phase != .failure
    }

    var symbol: String {
        switch phase {
        case .uploading: return "arrow.up.circle.fill"
        case .waiting: return "clock.fill"
        case .building: return "hammer.fill"
        case .success: return "checkmark.circle.fill"
        case .failure: return "xmark.octagon.fill"
        }
    }

    var tint: Color {
        switch phase {
        case .success: return .green
        case .failure: return .red
        default: return .orange
        }
    }

    var finishedLabel: String {
        phase == .success ? "Готово" : "Ошибка"
    }
}

/// «Устаревшая» активность: приложение давно не присылало обновлений (его могла усыпить iOS),
/// поэтому вместо идущего таймера показываем, что данных нет.
private extension ActivityViewContext where Attributes == BuildActivityAttributes {
    var isStaleRunning: Bool { isStale && state.isRunning }
    var showsTimer: Bool { state.isRunning && !isStale }

    var symbolName: String { isStaleRunning ? "exclamationmark.triangle.fill" : state.symbol }
    var tintColor: Color { isStaleRunning ? .yellow : state.tint }
    var stepText: String { isStaleRunning ? "Нет обновлений — откройте «Сборщик»" : state.step }
}

struct BuildLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: BuildActivityAttributes.self) { context in
            BuildLockScreenView(context: context)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: context.symbolName)
                        .font(.title2)
                        .foregroundStyle(context.tintColor)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if context.showsTimer {
                        Text(context.attributes.startedAt, style: .timer)
                            .monospacedDigit()
                            .font(.subheadline.weight(.semibold))
                            .frame(width: 62, alignment: .trailing)
                    } else if context.isStaleRunning {
                        Text("Нет данных")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(context.tintColor)
                    } else {
                        Text(context.state.finishedLabel)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(context.tintColor)
                    }
                }
                DynamicIslandExpandedRegion(.center) {
                    Text(context.attributes.projectName)
                        .font(.headline)
                        .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text(context.stepText)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            } compactLeading: {
                Image(systemName: context.symbolName)
                    .foregroundStyle(context.tintColor)
            } compactTrailing: {
                if context.showsTimer {
                    Text(context.attributes.startedAt, style: .timer)
                        .monospacedDigit()
                        .font(.caption2)
                        .frame(width: 44)
                } else if context.isStaleRunning {
                    Image(systemName: "exclamationmark")
                        .foregroundStyle(context.tintColor)
                } else {
                    Image(systemName: context.state.phase == .success ? "checkmark" : "xmark")
                        .foregroundStyle(context.tintColor)
                }
            } minimal: {
                Image(systemName: context.symbolName)
                    .foregroundStyle(context.tintColor)
            }
        }
    }
}

struct BuildLockScreenView: View {
    let context: ActivityViewContext<BuildActivityAttributes>

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: context.symbolName)
                .font(.system(size: 28))
                .foregroundStyle(context.tintColor)

            VStack(alignment: .leading, spacing: 2) {
                Text(context.attributes.projectName)
                    .font(.headline)
                    .lineLimit(1)
                Text(context.stepText)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            if context.showsTimer {
                Text(context.attributes.startedAt, style: .timer)
                    .monospacedDigit()
                    .font(.title3.weight(.semibold))
                    .frame(width: 70, alignment: .trailing)
            }
        }
        .padding(16)
    }
}

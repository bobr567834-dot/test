import SwiftUI

@main
struct IPABuilderApp: App {
    @StateObject private var model = BuilderModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .preferredColorScheme(.light)
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active { model.cleanupLiveActivities() }
        }
    }
}

import AVFoundation
import Foundation

/// Не даёт iOS усыпить приложение в фоне на время сборки: проигрывает тишину (режим «audio»).
/// Без этого Live Activity не обновится, пока приложение свёрнуто.
final class KeepAwake {
    private var player: AVAudioPlayer?

    init() {
        // После звонка, будильника или Siri iOS останавливает звук — запускаем тишину снова.
        NotificationCenter.default.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            guard let self = self,
                  let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  AVAudioSession.InterruptionType(rawValue: raw) == .ended,
                  let current = self.player else { return }
            try? AVAudioSession.sharedInstance().setActive(true)
            current.play()
        }
    }

    func start() {
        guard player == nil else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)

            let silent = try AVAudioPlayer(data: Self.silentWAV(seconds: 1), fileTypeHint: AVFileType.wav.rawValue)
            silent.numberOfLoops = -1
            silent.prepareToPlay()
            silent.play()
            player = silent
        } catch {
            player = nil
        }
    }

    func stop() {
        guard let current = player else { return }
        current.stop()
        player = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    /// Секунда тишины в формате WAV (8 кГц, 16 бит, моно), собранная в памяти.
    private static func silentWAV(seconds: Int) -> Data {
        let sampleRate = 8000
        let dataSize = sampleRate * 2 * seconds

        var data = Data()
        func append32(_ value: UInt32) { withUnsafeBytes(of: value.littleEndian) { data.append(contentsOf: $0) } }
        func append16(_ value: UInt16) { withUnsafeBytes(of: value.littleEndian) { data.append(contentsOf: $0) } }

        data.append(contentsOf: Array("RIFF".utf8))
        append32(UInt32(36 + dataSize))
        data.append(contentsOf: Array("WAVE".utf8))
        data.append(contentsOf: Array("fmt ".utf8))
        append32(16)
        append16(1)                       // PCM
        append16(1)                       // моно
        append32(UInt32(sampleRate))
        append32(UInt32(sampleRate * 2))  // байт в секунду
        append16(2)                       // выравнивание блока
        append16(16)                      // бит на отсчёт
        data.append(contentsOf: Array("data".utf8))
        append32(UInt32(dataSize))
        data.append(Data(count: dataSize))
        return data
    }
}

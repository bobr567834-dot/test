import UIKit

struct AppIconOption: Identifiable, Equatable {
    let id: String
    let title: String
    /// Имя набора иконки в Assets.xcassets; nil — основная иконка.
    let iconName: String?
    /// Имя картинки-превью для списка выбора.
    let preview: String

    static let all: [AppIconOption] = [
        AppIconOption(id: "default", title: "Оранжевая", iconName: nil, preview: "IconPreviewDefault"),
        AppIconOption(id: "dark", title: "Тёмная", iconName: "AppIconDark", preview: "IconPreviewDark"),
        AppIconOption(id: "blue", title: "Синяя", iconName: "AppIconBlue", preview: "IconPreviewBlue"),
        AppIconOption(id: "green", title: "Зелёная", iconName: "AppIconGreen", preview: "IconPreviewGreen"),
        AppIconOption(id: "light", title: "Светлая", iconName: "AppIconLight", preview: "IconPreviewLight"),
        AppIconOption(id: "hammer", title: "Молоток", iconName: "AppIconHammer", preview: "IconPreviewHammer")
    ]
}

/// Смена иконки приложения через альтернативные иконки iOS.
@MainActor
final class IconManager: ObservableObject {
    @Published private(set) var currentID = "default"
    @Published var message: String?

    var isSupported: Bool {
        UIApplication.shared.supportsAlternateIcons
    }

    init() {
        refresh()
    }

    func refresh() {
        let name = UIApplication.shared.alternateIconName
        currentID = AppIconOption.all.first { $0.iconName == name }?.id ?? "default"
    }

    func select(_ option: AppIconOption) async {
        guard option.id != currentID else { return }
        do {
            try await UIApplication.shared.setAlternateIconName(option.iconName)
            currentID = option.id
            message = nil
        } catch {
            message = "Не удалось сменить иконку: \(error.localizedDescription)"
        }
    }
}

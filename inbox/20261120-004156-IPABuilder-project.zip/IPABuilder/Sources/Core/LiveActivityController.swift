import ActivityKit
import Foundation

/// Запускает и обновляет Live Activity (Dynamic Island / экран блокировки) на время сборки.
@MainActor
final class LiveActivityController {
    typealias State = BuildActivityAttributes.ContentState
    typealias Live = Activity<BuildActivityAttributes>

    private var activity: Live?

    /// Если приложение не обновит активность за это время (например, iOS усыпила его в фоне),
    /// остров перестанет показывать идущий таймер и напишет «Нет обновлений».
    private let staleAfter: TimeInterval = 15 * 60

    private func runningContent(_ state: State) -> ActivityContent<State> {
        ActivityContent(state: state, staleDate: Date().addingTimeInterval(staleAfter))
    }

    func start(projectName: String) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }

        // Закрываем всё, что осталось от прошлых сборок, в том числе от прошлых запусков приложения.
        for old in Live.activities {
            Task { await old.end(nil, dismissalPolicy: .immediate) }
        }

        let attributes = BuildActivityAttributes(projectName: projectName, startedAt: Date())
        let content = runningContent(State(phase: .uploading, step: "Загрузка архива"))
        activity = try? Live.request(attributes: attributes, content: content)
    }

    func update(phase: State.Phase, step: String) async {
        // Если ссылка потерялась, но активность жива — берём её из системы.
        guard let target = activity ?? Live.activities.first else { return }
        await target.update(runningContent(State(phase: phase, step: step)))
    }

    /// Показывает итог (остров раскрывается с вибрацией) и оставляет его на экране ещё на время.
    func finish(success: Bool, detail: String) async {
        let all = Live.activities
        guard let current = activity ?? all.first else { return }
        activity = nil

        // Все остальные активности (старые, осиротевшие) закрываем сразу.
        for other in all where other.id != current.id {
            Task { await other.end(nil, dismissalPolicy: .immediate) }
        }

        let content = ActivityContent(
            state: State(phase: success ? .success : .failure, step: detail),
            staleDate: nil
        )
        let alert = AlertConfiguration(
            title: success ? "Сборка готова" : "Сборка не удалась",
            body: "Откройте «Сборщик»",
            sound: .default
        )
        await current.update(content, alertConfiguration: alert)

        // Через 5 минут убираем из острова (на экране блокировки итог останется ещё на 10 минут).
        Task {
            try? await Task.sleep(nanoseconds: 300_000_000_000)
            await current.end(content, dismissalPolicy: .after(Date().addingTimeInterval(600)))
        }
    }

    /// Закрывает вообще все активности «Сборщика» — и текущую, и оставшиеся от прошлых запусков.
    func endAll() async {
        activity = nil
        for item in Live.activities {
            await item.end(nil, dismissalPolicy: .immediate)
        }
    }

    func cancel() async {
        await endAll()
    }
}

import ActivityKit
import Foundation

/// Данные Live Activity (Dynamic Island и экран блокировки). Файл подключён и к приложению, и к расширению.
struct BuildActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        enum Phase: String, Codable, Hashable {
            case uploading, waiting, building, success, failure
        }

        var phase: Phase
        /// Текущий шаг или итог («Сборка», «MyApp.ipa», «Ошибка: Сборка»).
        var step: String
    }

    var projectName: String
    var startedAt: Date
}

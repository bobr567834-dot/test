import SwiftUI

struct ContentView: View {
    // Состояния для хранения очков и улучшений
    @State private var score: Int = 0
    @State private var pointsPerClick: Int = 1
    @State private var upgradeCost: Int = 10
    
    // Анимация кнопки
    @State private var isPressed: Bool = false

    var body: some View {
        ZStack {
            // Градиентный фон
            LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                // Счётчик очков
                VStack(spacing: 8) {
                    Text("Очки")
                        .font(.title2)
                        .fontWeight(.medium)
                        .foregroundColor(.white.opacity(0.8))
                    
                    Text("\(score)")
                        .font(.system(size: 54, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
                .padding(.top, 40)
                
                Spacer()
                
                // Главная кнопка-кликер
                Button(action: {
                    score += pointsPerClick
                    
                    // Легкая анимация нажатия
                    withAnimation(.spring(response: 0.2, dampingFraction: 0.5)) {
                        isPressed = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        isPressed = false
                    }
                }) {
                    ZStack {
                        Circle()
                            .fill(Color.white)
                            .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                            .frame(width: 180, height: 180)
                        
                        Image(systemName: "hand.tap.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.purple)
                    }
                }
                .scaleEffect(isPressed ? 0.9 : 1.0)
                
                Spacer()
                
                // Блок улучшений
                VStack(spacing: 12) {
                    Text("+ \(pointsPerClick) за клик")
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Button(action: {
                        if score >= upgradeCost {
                            score -= upgradeCost
                            pointsPerClick += 1
                            upgradeCost = Int(Double(upgradeCost) * 1.5) // Увеличение стоимости
                        }
                    }) {
                        HStack {
                            Text("Улучшить клик")
                                .fontWeight(.bold)
                            Spacer()
                            Text("Цена: \(upgradeCost)")
                                .fontWeight(.semibold)
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(score >= upgradeCost ? Color.green : Color.gray.opacity(0.6))
                        .foregroundColor(.white)
                        .cornerRadius(15)
                    }
                    .disabled(score < upgradeCost)
                }
                .padding(.horizontal, 30)
                .padding(.bottom, 30)
            }
        }
    }
}

#Preview {
    ContentView()
}

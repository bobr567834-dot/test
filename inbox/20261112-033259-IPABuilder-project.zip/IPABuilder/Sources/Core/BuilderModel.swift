import Foundation

@MainActor
final class BuilderModel: ObservableObject {
    enum Phase { case idle, uploading, waitingForRun, running, finished }

    private let repoKey = "builder.repo"
    private let configuredKey = "builder.configured"

    // MARK: Настройки

    @Published var token: String {
        didSet { isConfigured = false }
    }
    @Published var repoFull: String {
        didSet { isConfigured = false }
    }
    @Published var isConfigured: Bool {
        didSet { UserDefaults.standard.set(isConfigured, forKey: configuredKey) }
    }
    @Published var setupMessage: String?
    @Published var setupIsError = false
    @Published var isSettingUp = false

    // MARK: Режим загрузки и параметры генерируемого проекта

    @Published var mode: UploadMode {
        didSet { UserDefaults.standard.set(mode.rawValue, forKey: "builder.mode") }
    }
    @Published var appName: String {
        didSet { UserDefaults.standard.set(appName, forKey: "builder.appName") }
    }
    @Published var bundleID: String {
        didSet { UserDefaults.standard.set(bundleID, forKey: "builder.bundleID") }
    }
    @Published var platformChoice: PlatformChoice {
        didSet { UserDefaults.standard.set(platformChoice.rawValue, forKey: "builder.platform") }
    }
    @Published var iosVersion: String {
        didSet { UserDefaults.standard.set(iosVersion, forKey: "builder.iosVersion") }
    }
    @Published var watchVersion: String {
        didSet { UserDefaults.standard.set(watchVersion, forKey: "builder.watchVersion") }
    }
    @Published var themeChoice: ThemeChoice {
        didSet { UserDefaults.standard.set(themeChoice.rawValue, forKey: "builder.theme") }
    }

    // MARK: Исходники (режим «Только исходники»)

    @Published var pickedFiles: [PickedFile] = []
    @Published var sourceSummary: SourceSummary?
    @Published var pickedFolderName: String?

    // MARK: Встроенный редактор кода

    @Published var editorFiles: [EditorFile] {
        didSet { saveEditorFiles() }
    }
    @Published var selectedTab = 0
    /// Последняя сборка была запущена из редактора (чтобы предложить вернуться к коду).
    @Published var lastBuildWasEditor = false

    // MARK: Сборка

    @Published var zipName: String?
    @Published var zipData: Data?
    @Published var phase: Phase = .idle
    @Published var statusText = ""
    @Published var run: RunInfo?
    @Published var jobs: [JobInfo] = []
    @Published var errorLines: [String] = []
    @Published var failedStep: String?
    @Published var errorText: String?
    @Published var ipaURL: URL?
    @Published var history: [RunInfo] = []

    private var pollTask: Task<Void, Never>?

    init() {
        token = Keychain.load() ?? ""
        repoFull = UserDefaults.standard.string(forKey: "builder.repo") ?? ""
        isConfigured = UserDefaults.standard.bool(forKey: "builder.configured")

        let d = UserDefaults.standard
        mode = UploadMode(rawValue: d.string(forKey: "builder.mode") ?? "") ?? .archive
        appName = d.string(forKey: "builder.appName") ?? ""
        bundleID = d.string(forKey: "builder.bundleID") ?? ""
        platformChoice = PlatformChoice(rawValue: d.string(forKey: "builder.platform") ?? "") ?? .auto
        iosVersion = d.string(forKey: "builder.iosVersion") ?? "16.0"
        watchVersion = d.string(forKey: "builder.watchVersion") ?? "9.0"
        themeChoice = ThemeChoice(rawValue: d.string(forKey: "builder.theme") ?? "") ?? .system
        editorFiles = Self.loadEditorFiles()
    }

    /// Готово ли то, что нужно отправить на сборку, в текущем режиме.
    var isReadyToBuild: Bool {
        switch mode {
        case .archive: return zipData != nil
        case .sources: return !pickedFiles.isEmpty
        }
    }

    var effectivePlatform: BuildPlatform {
        switch platformChoice {
        case .auto: return sourceSummary?.platform ?? .ios
        case .ios: return .ios
        case .watchos: return .watchos
        }
    }

    /// Название, которое увидит пользователь под иконкой.
    var displayName: String {
        let typed = appName.trimmed
        if !typed.isEmpty { return typed }
        return pickedFolderName ?? "App"
    }

    var isBusy: Bool {
        phase == .uploading || phase == .waitingForRun || phase == .running
    }

    /// Шаги без служебных («Set up job», «Complete job», «Post …»).
    var visibleSteps: [StepInfo] {
        (jobs.first?.steps ?? []).filter {
            !$0.name.hasPrefix("Set up job") && !$0.name.hasPrefix("Complete job") && !$0.name.hasPrefix("Post ")
        }
    }

    private func makeClient() throws -> GitHubClient {
        let t = token.trimmed
        let parts = repoFull.trimmed.split(separator: "/").map(String.init)
        guard !t.isEmpty else {
            throw GitHubError(message: "Введите токен GitHub во вкладке «Настройка».")
        }
        guard parts.count == 2, !parts[0].isEmpty, !parts[1].isEmpty else {
            throw GitHubError(message: "Репозиторий нужно указать как владелец/имя, например ivan/ipa-builder.")
        }
        return GitHubClient(token: t, owner: parts[0], repo: parts[1])
    }

    // MARK: - Настройка

    func setup() {
        Task {
            isSettingUp = true
            setupMessage = nil
            setupIsError = false
            defer { isSettingUp = false }

            do {
                let client = try makeClient()
                let login = try await client.currentUser()
                var created = false

                let exists = try await client.repositoryExists()
                if !exists {
                    guard login.lowercased() == client.owner.lowercased() else {
                        throw GitHubError(message: "Репозиторий не найден. Создать его можно только в своём аккаунте (\(login)).")
                    }
                    try await client.createRepository()
                    created = true
                    try await Task.sleep(nanoseconds: 3_000_000_000)
                }

                var lastError: Error?
                for attempt in 0..<4 {
                    do {
                        try await client.installWorkflow()
                        lastError = nil
                        break
                    } catch {
                        lastError = error
                        if attempt < 3 { try await Task.sleep(nanoseconds: 2_000_000_000) }
                    }
                }
                if let lastError = lastError { throw lastError }

                Keychain.save(token.trimmed)
                UserDefaults.standard.set(repoFull.trimmed, forKey: repoKey)
                isConfigured = true
                setupMessage = (created ? "Репозиторий создан (приватный). " : "")
                    + "Всё готово: аккаунт \(login), workflow установлен."
            } catch {
                setupMessage = error.localizedDescription
                setupIsError = true
            }
        }
    }

    // MARK: - Выбор архива

    func pickZip(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result, let url = urls.first else { return }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }

        guard let data = try? Data(contentsOf: url) else {
            errorText = "Не удалось прочитать файл."
            return
        }
        if data.count > 50_000_000 {
            errorText = "Архив больше 50 МБ — слишком большой для загрузки через API."
            return
        }
        zipData = data
        zipName = url.lastPathComponent
        errorText = nil
    }

    // MARK: - Сборка

    func startBuild() {
        guard !isBusy else { return }
        lastBuildWasEditor = false
        let data: Data
        let name: String

        switch mode {
        case .archive:
            guard let zip = zipData, let zipFileName = zipName else { return }
            data = zip
            name = zipFileName
        case .sources:
            do {
                let packed = try packageSources()
                data = packed.0
                name = packed.1
            } catch {
                errorText = error.localizedDescription
                return
            }
        }

        pollTask?.cancel()
        pollTask = Task { await runBuild(data: data, name: name) }
    }

    // MARK: - Редактор кода

    private static let editorKey = "builder.editor.files.v1"

    private func saveEditorFiles() {
        if let data = try? JSONEncoder().encode(editorFiles) {
            UserDefaults.standard.set(data, forKey: Self.editorKey)
        }
    }

    private static func loadEditorFiles() -> [EditorFile] {
        if let data = UserDefaults.standard.data(forKey: editorKey),
           let files = try? JSONDecoder().decode([EditorFile].self, from: data),
           !files.isEmpty {
            return files
        }
        return EditorTemplates.defaultFiles
    }

    private static func normalizedFileName(_ raw: String) -> String {
        var name = raw.trimmed.replacingOccurrences(of: "/", with: "-")
        if name.isEmpty { name = "NewFile" }
        if !name.contains(".") { name += ".swift" }
        return name
    }

    private func uniqueEditorName(_ base: String, excluding id: UUID? = nil) -> String {
        let existing = Set(editorFiles.filter { $0.id != id }.map { $0.name.lowercased() })
        if !existing.contains(base.lowercased()) { return base }

        let nsName = base as NSString
        let ext = nsName.pathExtension
        let stem = nsName.deletingPathExtension
        var index = 2
        while true {
            let candidate = ext.isEmpty ? "\(stem)\(index)" : "\(stem)\(index).\(ext)"
            if !existing.contains(candidate.lowercased()) { return candidate }
            index += 1
        }
    }

    func addEditorFile(named raw: String) {
        let name = uniqueEditorName(Self.normalizedFileName(raw))
        let text = name.hasSuffix(".swift") ? "import SwiftUI\n\n" : ""
        editorFiles.append(EditorFile(name: name, text: text))
    }

    func renameEditorFile(id: UUID, to raw: String) {
        guard let index = editorFiles.firstIndex(where: { $0.id == id }) else { return }
        editorFiles[index].name = uniqueEditorName(Self.normalizedFileName(raw), excluding: id)
    }

    func deleteEditorFile(id: UUID) {
        editorFiles.removeAll { $0.id == id }
    }

    func loadTemplate(_ template: EditorTemplate) {
        editorFiles = template.files.map { EditorFile(name: $0.name, text: $0.text) }
    }

    /// Собирает проект из файлов редактора и запускает сборку.
    func startEditorBuild() {
        guard !isBusy else { return }
        errorText = nil

        let files = editorFiles.map { PickedFile(path: $0.name, data: Data($0.text.utf8)) }
        guard !files.isEmpty else {
            errorText = "Добавьте хотя бы один файл."
            return
        }

        let summary = ProjectScaffold.analyze(files)
        let title = appName.trimmed.isEmpty ? "MyApp" : appName.trimmed
        do {
            let packed = try packageSources(files: files, summary: summary, name: title)
            lastBuildWasEditor = true
            selectedTab = 0
            pollTask?.cancel()
            pollTask = Task { await runBuild(data: packed.0, name: packed.1) }
        } catch {
            errorText = error.localizedDescription
        }
    }

    // MARK: - Исходники

    func pickSourceFiles(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result else { return }
        var files = pickedFiles
        for url in urls {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            guard let data = try? Data(contentsOf: url) else { continue }
            let name = url.lastPathComponent
            files.removeAll { $0.path == name }
            files.append(PickedFile(path: name, data: data))
        }
        setPicked(files)
    }

    func pickSourceFolder(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result, let root = urls.first else { return }
        let scoped = root.startAccessingSecurityScopedResource()
        defer { if scoped { root.stopAccessingSecurityScopedResource() } }

        let rootCount = root.resolvingSymlinksInPath().pathComponents.count
        guard let enumerator = FileManager.default.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else {
            errorText = "Не удалось открыть папку."
            return
        }

        let skipped: Set<String> = ["build", "DerivedData", "xcuserdata", "Pods"]
        var files: [PickedFile] = []
        var total = 0

        for case let url as URL in enumerator {
            let components = url.resolvingSymlinksInPath().pathComponents
            guard components.count > rootCount else { continue }
            let relative = Array(components[rootCount...])
            if relative.contains(where: { skipped.contains($0) }) { continue }

            let isFile = (try? url.resourceValues(forKeys: [.isRegularFileKey]))?.isRegularFile ?? false
            guard isFile, let data = try? Data(contentsOf: url) else { continue }

            total += data.count
            if total > Self.maxSourceBytes {
                errorText = "Папка больше 40 МБ — слишком много для загрузки через API."
                return
            }
            files.append(PickedFile(path: relative.joined(separator: "/"), data: data))
        }

        pickedFolderName = root.lastPathComponent
        pickedFiles = []
        setPicked(files)
    }

    func clearSources() {
        pickedFiles = []
        sourceSummary = nil
        pickedFolderName = nil
        errorText = nil
    }

    private static let maxSourceBytes = 40_000_000

    private func setPicked(_ files: [PickedFile]) {
        let total = files.reduce(0) { $0 + $1.data.count }
        if total > Self.maxSourceBytes {
            errorText = "Файлы больше 40 МБ — слишком много для загрузки через API."
            return
        }
        pickedFiles = files
        sourceSummary = files.isEmpty ? nil : ProjectScaffold.analyze(files)
        errorText = nil
    }

    /// Собирает из выбранных файлов zip: добавляет project.yml (если проекта ещё нет).
    private func packageSources() throws -> (Data, String) {
        guard let summary = sourceSummary, !pickedFiles.isEmpty else {
            throw GitHubError(message: "Сначала выберите файлы приложения.")
        }
        return try packageSources(files: pickedFiles, summary: summary, name: displayName)
    }

    private func resolvePlatform(_ summary: SourceSummary) -> BuildPlatform {
        switch platformChoice {
        case .auto: return summary.platform
        case .ios: return .ios
        case .watchos: return .watchos
        }
    }

    /// Собирает zip из переданных файлов (используется и для выбранных файлов, и для встроенного редактора).
    private func packageSources(files inputFiles: [PickedFile], summary: SourceSummary, name: String) throws -> (Data, String) {
        let target = ProjectScaffold.targetName(from: name)
        var zip = ZipWriter()

        if summary.isCompleteProject {
            // Проект уже полный — отправляем как есть. Если есть project.yml,
            // старый .xcodeproj не нужен: его пересоздаст XcodeGen.
            let hasYML = inputFiles.contains { $0.path.lowercased().hasSuffix("project.yml") }
            for file in inputFiles {
                if hasYML && file.path.contains(".xcodeproj/") { continue }
                zip.add(path: "\(target)/\(file.path)", content: file.data)
            }
        } else {
            if !summary.hasMain {
                throw GitHubError(message: "В выбранных файлах нет точки входа @main (обычно это файл …App.swift). Без неё сборка падает на линковке с ошибкой «Undefined symbols _main». Добавьте этот файл.")
            }
            if summary.mainCount > 1 {
                throw GitHubError(message: "Найдено несколько @main (\(summary.mainCount)). В приложении должна быть одна точка входа — проверьте, не выбраны ли файлы от разных приложений.")
            }
            var files = inputFiles.filter { ($0.path.split(separator: "/").last.map(String.init)) != "Info.plist" }
            if !files.isEmpty && files.allSatisfy({ $0.path.hasPrefix("Sources/") }) {
                files = files.map { PickedFile(path: String($0.path.dropFirst("Sources/".count)), data: $0.data) }
            }
            for file in files {
                zip.add(path: "\(target)/Sources/\(file.path)", content: file.data)
            }

            let platform = resolvePlatform(summary)
            let yaml = ProjectScaffold.yaml(
                targetName: target,
                displayName: name,
                bundleID: ProjectScaffold.validBundleID(bundleID, fallbackTarget: target),
                platform: platform,
                iosVersion: iosVersion,
                watchVersion: watchVersion,
                theme: themeChoice,
                permissions: summary.permissions,
                iconName: summary.appIconName
            )
            // Пустой файл нужен, чтобы папка Resources существовала до запуска XcodeGen (там создаётся Info.plist).
            zip.add(path: "\(target)/Resources/.gitkeep", content: Data())
            zip.add(path: "\(target)/project.yml", content: Data(yaml.utf8))
        }
        return (zip.finish(), "\(target).zip")
    }

    func openRun(_ info: RunInfo) {
        pollTask?.cancel()
        resetBuildState()
        run = info
        pollTask = Task {
            guard let client = try? makeClient() else { return }
            await track(client: client, runID: info.id)
        }
    }

    func refreshHistory() async {
        guard isConfigured, let client = try? makeClient() else { return }
        if let runs = try? await client.recentRuns() { history = runs }
    }

    private func resetBuildState() {
        run = nil
        jobs = []
        errorLines = []
        failedStep = nil
        errorText = nil
        ipaURL = nil
        statusText = ""
        phase = .idle
    }

    private func runBuild(data: Data, name: String) async {
        resetBuildState()
        do {
            let client = try makeClient()

            phase = .uploading
            statusText = "Загружаю архив в GitHub…"
            let path = "inbox/\(Self.timestamp())-\(Self.safeFileName(name))"
            let commitSHA = try await client.putFile(path: path, data: data, message: "Build \(name)", sha: nil)

            phase = .waitingForRun
            statusText = "Жду запуск сборки…"
            var found: RunInfo?
            for _ in 0..<20 {
                if Task.isCancelled { return }
                found = try await client.findRun(headSHA: commitSHA)
                if found != nil { break }
                try await Task.sleep(nanoseconds: 3_000_000_000)
            }
            guard let started = found else {
                throw GitHubError(message: "Сборка не запустилась. Проверьте, что workflow установлен («Настройка») и в репозитории включены GitHub Actions.")
            }
            run = started
            await track(client: client, runID: started.id)
        } catch {
            errorText = error.localizedDescription
            phase = .idle
        }
    }

    private func track(client: GitHubClient, runID: Int) async {
        phase = .running
        var failures = 0
        while !Task.isCancelled {
            do {
                let current = try await client.run(id: runID)
                run = current
                jobs = try await client.jobs(runID: runID)
                failures = 0

                if current.isFinished {
                    await finish(client: client, run: current)
                    return
                }
                let activeStep = visibleSteps.first(where: { $0.status == "in_progress" })?.name
                statusText = activeStep ?? current.statusLabel
            } catch {
                failures += 1
                if failures >= 5 {
                    errorText = error.localizedDescription
                    phase = .idle
                    return
                }
            }
            try? await Task.sleep(nanoseconds: 6_000_000_000)
        }
    }

    private func finish(client: GitHubClient, run: RunInfo) async {
        if run.isSuccess {
            statusText = "Скачиваю IPA…"
            do {
                var assets: [AssetInfo] = []
                for _ in 0..<5 {
                    assets = try await client.releaseAssets(tag: "build-\(run.id)")
                    if !assets.isEmpty { break }
                    try await Task.sleep(nanoseconds: 3_000_000_000)
                }
                guard let asset = assets.first(where: { $0.name.lowercased().hasSuffix(".ipa") }) else {
                    throw GitHubError(message: "Сборка прошла, но IPA в релизе не найден.")
                }
                let data = try await client.downloadAsset(id: asset.id)

                let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let dir = docs.appendingPathComponent("Builds", isDirectory: true)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let url = dir.appendingPathComponent(asset.name)
                try data.write(to: url, options: .atomic)
                ipaURL = url
                statusText = "Готово"
            } catch {
                errorText = error.localizedDescription
            }
        } else {
            statusText = "Сборка не удалась"
            await loadFailure(client: client)
        }
        phase = .finished
        await refreshHistory()
    }

    private func loadFailure(client: GitHubClient) async {
        guard let job = jobs.first(where: { $0.conclusion == "failure" }) ?? jobs.first else { return }
        failedStep = job.steps.first(where: { $0.conclusion == "failure" })?.name
        if let log = try? await client.jobLog(jobID: job.id) {
            errorLines = Self.extractErrors(from: log)
        }
    }

    // MARK: - Помощники

    private static func timestamp() -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmmss"
        return f.string(from: Date())
    }

    private static func safeFileName(_ name: String) -> String {
        let allowed = Set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        var out = String(name.map { allowed.contains($0) ? $0 : "-" })
        if !out.lowercased().hasSuffix(".zip") { out += ".zip" }
        return out
    }

    /// Вытаскивает из лога строки с ошибками: компилятор, линковщик, xcodebuild.
    /// Строки с текстом команд (`echo "error: …"`) пропускаются — это не ошибки.
    static func extractErrors(from log: String) -> [String] {
        func clean(_ line: String) -> String {
            var s = line.replacingOccurrences(of: #"^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s?"#, with: "", options: .regularExpression)
            s = s.replacingOccurrences(of: #"(\u001B)?\[[0-9;]+m"#, with: "", options: .regularExpression)
            s = s.replacingOccurrences(of: #"/Users/runner/work/[^/]+/[^/]+/work/"#, with: "", options: .regularExpression)
            s = s.replacingOccurrences(of: #"^[A-Za-z0-9_]+/Sources/"#, with: "", options: .regularExpression)
            return s.trimmed
        }

        let lines = log.split(whereSeparator: { $0.isNewline }).map { clean(String($0)) }
        var seen = Set<String>()
        var result: [String] = []

        func add(_ line: String) {
            if !line.isEmpty, result.count < 40, seen.insert(line).inserted { result.append(line) }
        }

        for (index, line) in lines.enumerated() {
            if line.hasPrefix("echo ") || line.contains("echo \"error:") { continue }

            let linkerHeader = line.hasPrefix("Undefined symbols")
                || line.hasPrefix("duplicate symbol")
                || (line.hasPrefix("ld:") && !line.hasPrefix("ld: warning"))

            if linkerHeader {
                // Вместе с заголовком берём следующие строки: там перечислены сами символы.
                for next in index..<min(index + 6, lines.count) { add(lines[next]) }
            } else if line.contains("error:") || line.contains("fatal error")
                        || line.hasPrefix("##[error]") || line.contains("** BUILD FAILED **") {
                add(line)
            }
        }

        if result.isEmpty {
            result = lines
                .filter { !$0.isEmpty && !$0.hasPrefix("##[group]") && !$0.hasPrefix("##[endgroup]") }
                .suffix(30)
                .map { $0 }
        }
        return result
    }
}

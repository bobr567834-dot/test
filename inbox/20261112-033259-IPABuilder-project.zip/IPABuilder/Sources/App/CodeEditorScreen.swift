import SwiftUI

/// Экран редактирования одного файла.
struct CodeEditorScreen: View {
    @EnvironmentObject var model: BuilderModel
    let fileID: UUID

    var body: some View {
        if let index = model.editorFiles.firstIndex(where: { $0.id == fileID }) {
            CodeTextView(text: $model.editorFiles[index].text)
                .background(Theme.codeBG)
                .navigationTitle(model.editorFiles[index].name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            model.startEditorBuild()
                        } label: {
                            Label("Собрать", systemImage: "hammer.fill")
                        }
                        .disabled(model.isBusy || !model.isConfigured)
                    }
                }
        } else {
            Text("Файл удалён")
                .foregroundColor(Theme.inkSoft)
        }
    }
}

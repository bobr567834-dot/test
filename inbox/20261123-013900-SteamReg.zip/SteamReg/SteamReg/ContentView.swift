import SwiftUI
import WebKit

let steamJoinURL = URL(string: "https://store.steampowered.com/join/")!
let textToCopy = "vano1029384756"

struct WebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.allowsBackForwardNavigationGestures = true
        webView.load(URLRequest(url: url))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ContentView: View {
    @State private var webViewID = UUID()
    @State private var isClearing = false
    @State private var copied = false

    var body: some View {
        VStack(spacing: 0) {
            WebView(url: steamJoinURL)
                .id(webViewID)

            VStack(spacing: 8) {
                Button(action: copyText) {
                    Text(copied ? "Скопировано ✓" : "Копировать: \(textToCopy)")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(copied ? Color.green : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }

                Button(action: clearAndReload) {
                    Text(isClearing ? "Очистка..." : "Очистить данные и начать заново")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
                .disabled(isClearing)
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
            .background(Color(UIColor.systemBackground))
        }
    }

    private func copyText() {
        UIPasteboard.general.string = textToCopy
        copied = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            copied = false
        }
    }

    private func clearAndReload() {
        isClearing = true
        let store = WKWebsiteDataStore.default()
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        store.removeData(ofTypes: types, modifiedSince: .distantPast) {
            HTTPCookieStorage.shared.removeCookies(since: .distantPast)
            URLCache.shared.removeAllCachedResponses()
            webViewID = UUID()
            isClearing = false
        }
    }
}

import SpriteKit

class GameScene: SKScene {
    
    var playerCar: SKSpriteNode!
    var bots: [BotCar] = []
    var waypoints: [CGPoint] = []
    
    var isTurningLeft = false
    var isTurningRight = false
    
    // Настройки гонки (меняются в меню)
    var totalLaps = 3
    var botCount = 3
    
    // Состояния игры
    enum GameState {
        case menu
        case playing
        case paused
        case finished
    }
    var gameState: GameState = .menu
    
    // Физика игрока
    var playerVelocity = CGVector(dx: 0, dy: 0)
    let maxPlayerSpeed: CGFloat = 400
    let acceleration: CGFloat = 300
    let friction: CGFloat = 0.98
    let lateralGrip: CGFloat = 0.82
    let turnSpeed: CGFloat = 3.5
    
    var playerWaypointIndex = 1
    var playerLap = 1
    
    // Слои
    let worldLayer = SKNode()
    let skidMarkLayer = SKNode()
    let uiLayer = SKNode()
    
    // HUD и кнопки во время гонки
    let hudLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    let pauseButton = SKShapeNode(rectOf: CGSize(width: 44, height: 44), cornerRadius: 10)
    let pauseIconLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    
    // Оверлеи (Меню, Пауза, Финиш)
    let overlayNode = SKNode()
    let lapsValueLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    let botsValueLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    
    class BotCar {
        let node: SKSpriteNode
        var currentWaypoint = 1
        var lap = 1
        let maxSpeed: CGFloat
        let turnRate: CGFloat
        var offset: CGPoint
        
        init(color: UIColor, maxSpeed: CGFloat, turnRate: CGFloat, offset: CGPoint) {
            self.node = SKSpriteNode(color: color, size: CGSize(width: 22, height: 38))
            self.maxSpeed = maxSpeed
            self.turnRate = turnRate
            self.offset = offset
            
            let windshield = SKSpriteNode(color: .black, size: CGSize(width: 16, height: 7))
            windshield.position = CGPoint(x: 0, y: 9)
            self.node.addChild(windshield)
        }
    }
    
    override func didMove(to view: SKView) {
        backgroundColor = UIColor(red: 0.18, green: 0.45, blue: 0.22, alpha: 1.0)
        
        addChild(worldLayer)
        worldLayer.addChild(skidMarkLayer)
        addChild(uiLayer)
        addChild(overlayNode)
        
        setupTrack()
        setupHUD()
        showMainMenu()
    }
    
    // 1. Создание гладкой овальной трассы (без багнутых острых углов!)
    func setupTrack() {
        let w = size.width
        let h = size.height
        let centerX = w * 0.5
        let centerY = h * 0.48
        let radiusX = w * 0.34
        let radiusY = h * 0.34
        
        waypoints.removeAll()
        let numPoints = 32
        // Генерируем 32 точки по эллипсу против часовой стрелки, начиная справа (угол 0)
        for i in 0..<numPoints {
            let angle = (CGFloat(i) / CGFloat(numPoints)) * 2 * .pi
            // Добавляем легкий изгиб для интереса трассы
            let wave = sin(angle * 2) * (w * 0.04)
            let x = centerX + cos(angle) * (radiusX + wave)
            let y = centerY + sin(angle) * radiusY
            waypoints.append(CGPoint(x: x, y: y))
        }
        
        let path = CGMutablePath()
        path.addLines(between: waypoints)
        path.closeSubpath()
        
        // Поребрик (красно-белый/красный)
        let curbNode = SKShapeNode(path: path)
        curbNode.strokeColor = .systemRed
        curbNode.lineWidth = 108
        curbNode.lineJoin = .round
        curbNode.lineCap = .round
        worldLayer.addChild(curbNode)
        
        // Асфальт
        let roadNode = SKShapeNode(path: path)
        roadNode.strokeColor = UIColor(white: 0.22, alpha: 1.0)
        roadNode.lineWidth = 94
        roadNode.lineJoin = .round
        roadNode.lineCap = .round
        worldLayer.addChild(roadNode)
        
        // Осевая линия
        let centerLine = SKShapeNode(path: path)
        centerLine.strokeColor = UIColor(white: 1.0, alpha: 0.3)
        centerLine.lineWidth = 3
        centerLine.lineJoin = .round
        worldLayer.addChild(centerLine)
        
        // Линия старт/финиш на точке 0 (справа по центру, движение вверх)
        let finishLine = SKSpriteNode(color: .white, size: CGSize(width: 94, height: 10))
        finishLine.position = waypoints[0]
        worldLayer.addChild(finishLine)
    }
    
    // 2. Расстановка машин строго по направлению трассы
    func setupCars() {
        // Удаляем старые машины
        playerCar?.removeFromParent()
        for bot in bots {
            bot.node.removeFromParent()
        }
        bots.removeAll()
        skidMarkLayer.removeAllChildren()
        
        let startPos = waypoints[0]
        let nextPos = waypoints[1]
        // Вычисляем точный начальный угол трассы (вверх)
        let initialAngle = atan2(nextPos.y - startPos.y, nextPos.x - startPos.x) - .pi / 2
        
        // Игрок
        playerCar = SKSpriteNode(color: .systemBlue, size: CGSize(width: 22, height: 38))
        playerCar.position = CGPoint(x: startPos.x - 18, y: startPos.y - 25)
        playerCar.zRotation = initialAngle
        playerCar.zPosition = 5
        
        let windshield = SKSpriteNode(color: .cyan, size: CGSize(width: 16, height: 7))
        windshield.position = CGPoint(x: 0, y: 9)
        playerCar.addChild(windshield)
        worldLayer.addChild(playerCar)
        
        // Конфигурации для до 5 ботов
        let allBotConfigs: [(UIColor, CGFloat, CGPoint)] = [
            (.systemRed, 365, CGPoint(x: 18, y: -25)),
            (.systemYellow, 345, CGPoint(x: -18, y: -70)),
            (.systemOrange, 330, CGPoint(x: 18, y: -70)),
            (.systemPurple, 315, CGPoint(x: -18, y: -115)),
            (.systemTeal, 300, CGPoint(x: 18, y: -115))
        ]
        
        for i in 0..<botCount {
            let config = allBotConfigs[i]
            let bot = BotCar(color: config.0, maxSpeed: config.1, turnRate: 4.5, offset: config.2)
            bot.node.position = CGPoint(x: startPos.x + config.2.x, y: startPos.y + config.2.y)
            bot.node.zRotation = initialAngle
            bot.node.zPosition = 4
            bot.currentWaypoint = 1
            worldLayer.addChild(bot.node)
            bots.append(bot)
        }
    }
    
    // 3. Интерфейс (счетчик кругов/места и кнопка паузы)
    func setupHUD() {
        let topY = size.height - 55
        
        hudLabel.fontSize = 18
        hudLabel.fontColor = .white
        hudLabel.horizontalAlignmentMode = .left
        hudLabel.position = CGPoint(x: 24, y: topY - 6)
        hudLabel.zPosition = 10
        uiLayer.addChild(hudLabel)
        
        // Кнопка паузы в правом верхнем углу
        pauseButton.fillColor = UIColor(white: 0.1, alpha: 0.7)
        pauseButton.strokeColor = .white
        pauseButton.lineWidth = 2
        pauseButton.position = CGPoint(x: size.width - 42, y: topY)
        pauseButton.zPosition = 10
        pauseButton.name = "btn_pause"
        
        pauseIconLabel.text = "||"
        pauseIconLabel.fontSize = 18
        pauseIconLabel.fontColor = .white
        pauseIconLabel.verticalAlignmentMode = .center
        pauseIconLabel.name = "btn_pause"
        pauseButton.addChild(pauseIconLabel)
        
        uiLayer.addChild(pauseButton)
    }
    
    // Вспомогательная функция создания кнопок в меню
    func createButton(text: String, name: String, width: CGFloat, height: CGFloat, color: UIColor, pos: CGPoint) -> SKShapeNode {
        let btn = SKShapeNode(rectOf: CGSize(width: width, height: height), cornerRadius: 12)
        btn.fillColor = color
        btn.strokeColor = .white
        btn.lineWidth = 2
        btn.position = pos
        btn.name = name
        
        let lbl = SKLabelNode(fontNamed: "AvenirNext-Bold")
        lbl.text = text
        lbl.fontSize = 20
        lbl.fontColor = .white
        lbl.verticalAlignmentMode = .center
        lbl.name = name
        btn.addChild(lbl)
        
        return btn
    }
    
    // Экран стартового меню с настройками
    func showMainMenu() {
        gameState = .menu
        uiLayer.isHidden = true
        overlayNode.removeAllChildren()
        
        let bg = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.75), size: size)
        bg.position = CGPoint(x: size.width / 2, y: size.height / 2)
        overlayNode.addChild(bg)
        
        let title = SKLabelNode(fontNamed: "AvenirNext-Heavy")
        title.text = "2D ГОНКИ"
        title.fontSize = 38
        title.fontColor = .systemYellow
        title.position = CGPoint(x: size.width / 2, y: size.height * 0.75)
        overlayNode.addChild(title)
        
        // Настройка кругов
        let lapsTitle = SKLabelNode(fontNamed: "AvenirNext-Bold")
        lapsTitle.text = "Количество кругов:"
        lapsTitle.fontSize = 20
        lapsTitle.fontColor = .white
        lapsTitle.position = CGPoint(x: size.width / 2, y: size.height * 0.60)
        overlayNode.addChild(lapsTitle)
        
        lapsValueLabel.text = "\(totalLaps)"
        lapsValueLabel.fontSize = 26
        lapsValueLabel.fontColor = .cyan
        lapsValueLabel.verticalAlignmentMode = .center
        lapsValueLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.54)
        overlayNode.addChild(lapsValueLabel)
        
        overlayNode.addChild(createButton(text: "-", name: "btn_laps_minus", width: 50, height: 44, color: .darkGray, pos: CGPoint(x: size.width / 2 - 70, y: size.height * 0.54)))
        overlayNode.addChild(createButton(text: "+", name: "btn_laps_plus", width: 50, height: 44, color: .darkGray, pos: CGPoint(x: size.width / 2 + 70, y: size.height * 0.54)))
        
        // Настройка количества ботов
        let botsTitle = SKLabelNode(fontNamed: "AvenirNext-Bold")
        botsTitle.text = "Соперники (боты):"
        botsTitle.fontSize = 20
        botsTitle.fontColor = .white
        botsTitle.position = CGPoint(x: size.width / 2, y: size.height * 0.43)
        overlayNode.addChild(botsTitle)
        
        botsValueLabel.text = "\(botCount)"
        botsValueLabel.fontSize = 26
        botsValueLabel.fontColor = .cyan
        botsValueLabel.verticalAlignmentMode = .center
        botsValueLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.37)
        overlayNode.addChild(botsValueLabel)
        
        overlayNode.addChild(createButton(text: "-", name: "btn_bots_minus", width: 50, height: 44, color: .darkGray, pos: CGPoint(x: size.width / 2 - 70, y: size.height * 0.37)))
        overlayNode.addChild(createButton(text: "+", name: "btn_bots_plus", width: 50, height: 44, color: .darkGray, pos: CGPoint(x: size.width / 2 + 70, y: size.height * 0.37)))
        
        // Кнопка Старт
        overlayNode.addChild(createButton(text: "НАЧАТЬ ГОНКУ", name: "btn_start", width: 220, height: 56, color: .systemGreen, pos: CGPoint(x: size.width / 2, y: size.height * 0.22)))
    }
    
    // Экран паузы
    func showPauseMenu() {
        gameState = .paused
        isTurningLeft = false
        isTurningRight = false
        overlayNode.removeAllChildren()
        
        let bg = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.75), size: size)
        bg.position = CGPoint(x: size.width / 2, y: size.height / 2)
        overlayNode.addChild(bg)
        
        let title = SKLabelNode(fontNamed: "AvenirNext-Heavy")
        title.text = "ПАУЗА"
        title.fontSize = 36
        title.fontColor = .white
        title.position = CGPoint(x: size.width / 2, y: size.height * 0.68)
        overlayNode.addChild(title)
        
        overlayNode.addChild(createButton(text: "ПРОДОЛЖИТЬ", name: "btn_resume", width: 230, height: 52, color: .systemGreen, pos: CGPoint(x: size.width / 2, y: size.height * 0.54)))
        overlayNode.addChild(createButton(text: "НАЧАТЬ СНАЧАЛА", name: "btn_restart", width: 230, height: 52, color: .systemOrange, pos: CGPoint(x: size.width / 2, y: size.height * 0.43)))
        overlayNode.addChild(createButton(text: "В МЕНЮ НАСТРОЕК", name: "btn_menu", width: 230, height: 52, color: .systemBlue, pos: CGPoint(x: size.width / 2, y: size.height * 0.32)))
    }
    
    // Экран финиша
    func showFinishMenu(place: Int) {
        gameState = .finished
        isTurningLeft = false
        isTurningRight = false
        overlayNode.removeAllChildren()
        
        let bg = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.75), size: size)
        bg.position = CGPoint(x: size.width / 2, y: size.height / 2)
        overlayNode.addChild(bg)
        
        let title = SKLabelNode(fontNamed: "AvenirNext-Heavy")
        title.text = "ФИНИШ!"
        title.fontSize = 40
        title.fontColor = .systemYellow
        title.position = CGPoint(x: size.width / 2, y: size.height * 0.68)
        overlayNode.addChild(title)
        
        let result = SKLabelNode(fontNamed: "AvenirNext-Bold")
        result.text = "Твоё место: \(place) из \(botCount + 1)"
        result.fontSize = 24
        result.fontColor = .white
        result.position = CGPoint(x: size.width / 2, y: size.height * 0.59)
        overlayNode.addChild(result)
        
        overlayNode.addChild(createButton(text: "НАЧАТЬ СНАЧАЛА", name: "btn_restart", width: 230, height: 52, color: .systemGreen, pos: CGPoint(x: size.width / 2, y: size.height * 0.45)))
        overlayNode.addChild(createButton(text: "В МЕНЮ НАСТРОЕК", name: "btn_menu", width: 230, height: 52, color: .systemBlue, pos: CGPoint(x: size.width / 2, y: size.height * 0.34)))
    }
    
    func startRace() {
        overlayNode.removeAllChildren()
        uiLayer.isHidden = false
        playerLap = 1
        playerWaypointIndex = 1
        playerVelocity = CGVector(dx: 0, dy: 0)
        isTurningLeft = false
        isTurningRight = false
        lastUpdateTime = 0
        
        setupCars()
        updateRaceProgress()
        gameState = .playing
    }
    
    // Обработка нажатий (кнопки UI + руление)
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let loc = touch.location(in: self)
            let tappedNodes = nodes(at: loc)
            
            // Проверяем нажатие на кнопки интерфейса
            if let buttonName = tappedNodes.compactMap({ $0.name }).first {
                handleButtonTap(name: buttonName)
                return
            }
            
            // Если идет гонка — управляем поворотами
            if gameState == .playing {
                if loc.x < size.width / 2 {
                    isTurningLeft = true
                } else {
                    isTurningRight = true
                }
            }
        }
    }
    
    func handleButtonTap(name: String) {
        switch name {
        case "btn_laps_minus":
            totalLaps = max(1, totalLaps - 1)
            lapsValueLabel.text = "\(totalLaps)"
        case "btn_laps_plus":
            totalLaps = min(10, totalLaps + 1)
            lapsValueLabel.text = "\(totalLaps)"
        case "btn_bots_minus":
            botCount = max(1, botCount - 1)
            botsValueLabel.text = "\(botCount)"
        case "btn_bots_plus":
            botCount = min(5, botCount + 1)
            botsValueLabel.text = "\(botCount)"
        case "btn_start", "btn_restart":
            startRace()
        case "btn_pause":
            if gameState == .playing { showPauseMenu() }
        case "btn_resume":
            overlayNode.removeAllChildren()
            lastUpdateTime = 0
            gameState = .playing
        case "btn_menu":
            showMainMenu()
        default:
            break
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gameState != .playing { return }
        for touch in touches {
            let loc = touch.location(in: self)
            if loc.x < size.width / 2 { isTurningLeft = false }
            else { isTurningRight = false }
        }
    }
    
    private var lastUpdateTime: TimeInterval = 0
    
    override func update(_ currentTime: TimeInterval) {
        if gameState != .playing { return }
        
        if lastUpdateTime == 0 { lastUpdateTime = currentTime }
        let dt = min(CGFloat(currentTime - lastUpdateTime), 0.05)
        lastUpdateTime = currentTime
        
        updatePlayer(dt: dt)
        updateBots(dt: dt)
        checkCollisions()
        updateRaceProgress()
    }
    
    func isOnRoad(point: CGPoint) -> Bool {
        let roadHalfWidth: CGFloat = 47
        for i in 0..<waypoints.count {
            let p1 = waypoints[i]
            let p2 = waypoints[(i + 1) % waypoints.count]
            if distanceToSegment(p: point, a: p1, b: p2) <= roadHalfWidth {
                return true
            }
        }
        return false
    }
    
    func distanceToSegment(p: CGPoint, a: CGPoint, b: CGPoint) -> CGFloat {
        let l2 = (b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y)
        if l2 == 0 { return hypot(p.x - a.x, p.y - a.y) }
        var t = ((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)) / l2
        t = max(0, min(1, t))
        let proj = CGPoint(x: a.x + t * (b.x - a.x), y: a.y + t * (b.y - a.y))
        return hypot(p.x - proj.x, p.y - proj.y)
    }
    
    func updatePlayer(dt: CGFloat) {
        let onRoad = isOnRoad(point: playerCar.position)
        let currentMaxSpeed = onRoad ? maxPlayerSpeed : 135
        let currentAcceleration = onRoad ? acceleration : 75
        
        if isTurningLeft { playerCar.zRotation += turnSpeed * dt }
        if isTurningRight { playerCar.zRotation -= turnSpeed * dt }
        
        let forwardAngle = playerCar.zRotation + .pi / 2
        let forwardDir = CGVector(dx: cos(forwardAngle), dy: sin(forwardAngle))
        
        playerVelocity.dx += forwardDir.dx * currentAcceleration * dt
        playerVelocity.dy += forwardDir.dy * currentAcceleration * dt
        
        let speed = hypot(playerVelocity.dx, playerVelocity.dy)
        if speed > currentMaxSpeed {
            playerVelocity.dx = (playerVelocity.dx / speed) * currentMaxSpeed
            playerVelocity.dy = (playerVelocity.dy / speed) * currentMaxSpeed
        }
        
        let rightAngle = playerCar.zRotation
        let rightDir = CGVector(dx: cos(rightAngle), dy: sin(rightAngle))
        
        let forwardSpeed = playerVelocity.dx * forwardDir.dx + playerVelocity.dy * forwardDir.dy
        let lateralSpeed = playerVelocity.dx * rightDir.dx + playerVelocity.dy * rightDir.dy
        
        let grip = onRoad ? lateralGrip : 0.95
        let newLateralSpeed = lateralSpeed * grip
        
        playerVelocity.dx = forwardDir.dx * forwardSpeed + rightDir.dx * newLateralSpeed
        playerVelocity.dy = forwardDir.dy * forwardSpeed + rightDir.dy * newLateralSpeed
        
        playerVelocity.dx *= friction
        playerVelocity.dy *= friction
        
        playerCar.position.x += playerVelocity.dx * dt
        playerCar.position.y += playerVelocity.dy * dt
        
        if onRoad && (abs(lateralSpeed) > 105 || (isTurningLeft || isTurningRight) && speed > 220) {
            spawnSkidMark(at: playerCar.position, rotation: playerCar.zRotation)
        }
        
        // Проверка чекпоинтов (32 точки по кругу)
        let target = waypoints[playerWaypointIndex]
        if hypot(target.x - playerCar.position.x, target.y - playerCar.position.y) < 75 {
            playerWaypointIndex += 1
            if playerWaypointIndex >= waypoints.count {
                playerWaypointIndex = 0
            }
            // Если пересекли финишную точку (индекс 1 после 0)
            if playerWaypointIndex == 1 {
                playerLap += 1
                if playerLap > totalLaps {
                    let place = calculatePlayerPlace()
                    showFinishMenu(place: place)
                }
            }
        }
    }
    
    func spawnSkidMark(at position: CGPoint, rotation: CGFloat) {
        let skid = SKSpriteNode(color: UIColor(white: 0.1, alpha: 0.4), size: CGSize(width: 4, height: 10))
        skid.position = position
        skid.zRotation = rotation
        skid.zPosition = 2
        skidMarkLayer.addChild(skid)
        
        let fadeOut = SKAction.sequence([
            SKAction.fadeAlpha(to: 0, duration: 1.2),
            SKAction.removeFromParent()
        ])
        skid.run(fadeOut)
    }
    
    func updateBots(dt: CGFloat) {
        for bot in bots {
            let baseTarget = waypoints[bot.currentWaypoint]
            let target = CGPoint(x: baseTarget.x + bot.offset.x * 0.4, y: baseTarget.y + bot.offset.y * 0.4)
            
            let dx = target.x - bot.node.position.x
            let dy = target.y - bot.node.position.y
            let distance = hypot(dx, dy)
            
            let targetAngle = atan2(dy, dx) - .pi / 2
            var angleDiff = targetAngle - bot.node.zRotation
            while angleDiff > .pi { angleDiff -= 2 * .pi }
            while angleDiff < -.pi { angleDiff += 2 * .pi }
            
            bot.node.zRotation += angleDiff * bot.turnRate * dt
            
            let moveAngle = bot.node.zRotation + .pi / 2
            bot.node.position.x += cos(moveAngle) * bot.maxSpeed * dt
            bot.node.position.y += sin(moveAngle) * bot.maxSpeed * dt
            
            if distance < 55 {
                bot.currentWaypoint += 1
                if bot.currentWaypoint >= waypoints.count {
                    bot.currentWaypoint = 0
                }
                if bot.currentWaypoint == 1 {
                    bot.lap += 1
                }
            }
        }
    }
    
    func checkCollisions() {
        var allCars = bots.map { $0.node }
        allCars.append(playerCar)
        
        for i in 0..<allCars.count {
            for j in (i + 1)..<allCars.count {
                let carA = allCars[i]
                let carB = allCars[j]
                let dx = carB.position.x - carA.position.x
                let dy = carB.position.y - carA.position.y
                let dist = hypot(dx, dy)
                let minDist: CGFloat = 28
                
                if dist < minDist && dist > 0 {
                    let overlap = (minDist - dist) / 2
                    let nx = dx / dist
                    let ny = dy / dist
                    carA.position.x -= nx * overlap
                    carA.position.y -= ny * overlap
                    carB.position.x += nx * overlap
                    carB.position.y += ny * overlap
                }
            }
        }
    }
    
    func calculatePlayerPlace() -> Int {
        let adjustedPlayerIndex = (playerWaypointIndex == 0) ? waypoints.count : playerWaypointIndex
        let playerScore = playerLap * 1000 + adjustedPlayerIndex
        var place = 1
        for bot in bots {
            let adjustedBotIndex = (bot.currentWaypoint == 0) ? waypoints.count : bot.currentWaypoint
            let botScore = bot.lap * 1000 + adjustedBotIndex
            if botScore > playerScore { place += 1 }
        }
        return place
    }
    
    func updateRaceProgress() {
        let place = calculatePlayerPlace()
        let displayLap = min(playerLap, totalLaps)
        hudLabel.text = "Круг: \(displayLap)/\(totalLaps)   |   Место: \(place)/\(botCount + 1)"
    }
}

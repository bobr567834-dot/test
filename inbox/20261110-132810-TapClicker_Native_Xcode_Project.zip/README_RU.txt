TAP CLICKER — нативный проект iOS (SwiftUI)

СБОРКА IPA:
1. На Mac установи/открой Xcode.
2. Распакуй архив и открой TapClicker.xcodeproj.
3. Подключи iPhone к Mac (или выбери симулятор).
4. В Xcode открой TARGETS → TapClicker → Signing & Capabilities.
5. Включи Automatically manage signing и выбери свою Apple ID в Team.
   Если Xcode попросит, измени Bundle Identifier на уникальный, например com.ТВОЁИМЯ.TapClicker.
6. Для установки на подключённый iPhone выбери его в списке устройств и нажми Run (▶).
7. Для IPA: Product → Archive. В Organizer выбери архив → Distribute App.
   Для личной установки обычно подходит Development или Ad Hoc (нужна соответствующая подпись).
   Для распространения через App Store выбирай App Store Connect.

Важно:
- Проект содержит исходный SwiftUI-код, а не готовый подписанный IPA.
- Для установки на iPhone нужна подпись Apple. Бесплатный Apple ID позволяет запускать приложение на своём устройстве через Xcode, но имеет ограничения по сроку действия профиля.
- Для распространения другим людям и публикации нужны соответствующие сертификаты/профили Apple Developer.
- Минимальная версия iOS: 16.0.

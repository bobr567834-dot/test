import SwiftUI

struct Upgrade: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let symbol: String
    let baseCost: Double
    let gain: Double
    let isPerSecond: Bool
}

@MainActor
final class Game: ObservableObject {
    @Published var coins: Double = 0
    @Published var totalEarned: Double = 0
    @Published var taps: Int = 0
    @Published var clickPower: Double = 1
    @Published var incomePerSecond: Double = 0
    @Published var owned: [String: Int] = [:]

    let upgrades: [Upgrade] = [
        .init(id: "finger", title: "Сильный палец", subtitle: "+1 монета за нажатие", symbol: "hand.tap.fill", baseCost: 25, gain: 1, isPerSecond: false),
        .init(id: "auto", title: "Автокликер", subtitle: "+1 монета в секунду", symbol: "cpu", baseCost: 80, gain: 1, isPerSecond: true),
        .init(id: "robot", title: "Робот-ферма", subtitle: "+5 монет в секунду", symbol: "cpu", baseCost: 350, gain: 5, isPerSecond: true),
        .init(id: "crystal", title: "Кристалл энергии", subtitle: "+5 монет за нажатие", symbol: "diamond.fill", baseCost: 500, gain: 5, isPerSecond: false),
        .init(id: "factory", title: "Монетная фабрика", subtitle: "+25 монет в секунду", symbol: "building.2.fill", baseCost: 1800, gain: 25, isPerSecond: true),
        .init(id: "portal", title: "Золотой портал", subtitle: "+25 монет за нажатие", symbol: "sparkles", baseCost: 4000, gain: 25, isPerSecond: false)
    ]

    init() { load() }

    func cost(_ upgrade: Upgrade) -> Double {
        upgrade.baseCost * pow(1.17, Double(owned[upgrade.id, default: 0]))
    }

    func tap() {
        coins += clickPower
        totalEarned += clickPower
        taps += 1
        save()
    }

    func buy(_ upgrade: Upgrade) {
        let price = cost(upgrade)
        guard coins >= price else { return }
        coins -= price
        owned[upgrade.id, default: 0] += 1
        if upgrade.isPerSecond { incomePerSecond += upgrade.gain }
        else { clickPower += upgrade.gain }
        save()
    }

    func tick() {
        guard incomePerSecond > 0 else { return }
        coins += incomePerSecond
        totalEarned += incomePerSecond
        save()
    }

    func reset() {
        coins = 0; totalEarned = 0; taps = 0
        clickPower = 1; incomePerSecond = 0; owned = [:]
        save()
    }

    private func save() {
        let data: [String: Any] = [
            "coins": coins, "totalEarned": totalEarned, "taps": taps,
            "clickPower": clickPower, "incomePerSecond": incomePerSecond,
            "owned": owned
        ]
        UserDefaults.standard.set(data, forKey: "tapClickerSave")
    }

    private func load() {
        guard let data = UserDefaults.standard.dictionary(forKey: "tapClickerSave") else { return }
        coins = data["coins"] as? Double ?? 0
        totalEarned = data["totalEarned"] as? Double ?? 0
        taps = data["taps"] as? Int ?? 0
        clickPower = data["clickPower"] as? Double ?? 1
        incomePerSecond = data["incomePerSecond"] as? Double ?? 0
        owned = data["owned"] as? [String: Int] ?? [:]
    }
}

struct ContentView: View {
    @StateObject private var game = Game()
    @State private var selectedTab = 0
    @State private var showResetAlert = false
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    private var number: NumberFormatter {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.maximumFractionDigits = 0
        return f
    }

    private func formatted(_ value: Double) -> String {
        number.string(from: NSNumber(value: value)) ?? "0"
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.17, green: 0.20, blue: 0.40), Color(red: 0.045, green: 0.055, blue: 0.11)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 18) {
                header
                balanceCard
                if selectedTab == 0 { shopView } else { statsView }
                Spacer(minLength: 0)
                HStack(spacing: 8) {
                    tabButton(title: "Магазин", symbol: "cart.fill", index: 0)
                    tabButton(title: "Статистика", symbol: "chart.bar.fill", index: 1)
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 10)
            .padding(.bottom, 8)
        }
        .preferredColorScheme(.dark)
        .onReceive(timer) { _ in game.tick() }
        .alert("Сбросить прогресс?", isPresented: $showResetAlert) {
            Button("Отмена", role: .cancel) {}
            Button("Сбросить", role: .destructive) { game.reset() }
        } message: {
            Text("Все монеты и улучшения будут удалены.")
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("ТВОЯ ИМПЕРИЯ КЛИКОВ")
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(Color(red: 0.65, green: 0.70, blue: 0.95))
                Text("Tap Clicker")
                    .font(.system(size: 29, weight: .black, design: .rounded))
            }
            Spacer()
            Image(systemName: "gamecontroller.fill")
                .font(.title2)
                .foregroundStyle(.yellow)
                .padding(13)
                .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 15))
        }
    }

    private var balanceCard: some View {
        VStack(spacing: 7) {
            Text("ТВОИ МОНЕТЫ")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .tracking(2)
                .foregroundStyle(.white.opacity(0.65))
            Text(formatted(game.coins))
                .font(.system(size: 48, weight: .black, design: .rounded))
                .minimumScaleFactor(0.5)
                .lineLimit(1)
            HStack(spacing: 9) {
                Label("+\(formatted(game.clickPower)) за нажатие", systemImage: "hand.tap.fill")
                Text("•")
                Text("\(formatted(game.incomePerSecond))/сек")
            }
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(.white.opacity(0.75))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 21)
        .background(LinearGradient(colors: [Color(red: 0.18, green: 0.22, blue: 0.43), Color(red: 0.12, green: 0.15, blue: 0.31)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.10), lineWidth: 1))
    }

    private var shopView: some View {
        VStack(spacing: 13) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Улучшения").font(.system(size: 20, weight: .bold, design: .rounded))
                    Text("Прокачивай свой кликер").font(.caption).foregroundStyle(.white.opacity(0.55))
                }
                Spacer()
                Text("SHOP").font(.system(size: 10, weight: .black)).tracking(1.5)
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(.indigo.opacity(0.35), in: RoundedRectangle(cornerRadius: 9))
            }
            ScrollView {
                VStack(spacing: 9) {
                    ForEach(game.upgrades) { upgrade in
                        upgradeRow(upgrade)
                    }
                }
                .padding(.bottom, 4)
            }
        }
        .padding(16)
        .frame(maxHeight: .infinity)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.08), lineWidth: 1))
    }

    private func upgradeRow(_ upgrade: Upgrade) -> some View {
        let price = game.cost(upgrade)
        let count = game.owned[upgrade.id, default: 0]
        return HStack(spacing: 11) {
            Image(systemName: upgrade.symbol)
                .font(.title3)
                .foregroundStyle(.yellow)
                .frame(width: 43, height: 43)
                .background(.indigo.opacity(0.28), in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 4) {
                Text("\(upgrade.title)  ×\(count)")
                    .font(.system(size: 13, weight: .bold))
                    .lineLimit(1)
                Text(upgrade.subtitle)
                    .font(.system(size: 10))
                    .foregroundStyle(.white.opacity(0.58))
                    .lineLimit(1)
            }
            Spacer(minLength: 2)
            Button { game.buy(upgrade) } label: {
                VStack(spacing: 2) {
                    Text(formatted(price))
                    Text("🪙")
                }
                .font(.system(size: 11, weight: .heavy))
                .frame(width: 72, height: 43)
                .background(game.coins >= price ? Color.indigo : Color.gray.opacity(0.35), in: RoundedRectangle(cornerRadius: 11))
            }
            .disabled(game.coins < price)
        }
        .padding(9)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
    }

    private var statsView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Статистика").font(.system(size: 20, weight: .bold, design: .rounded))
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                statCard("Всего заработано", formatted(game.totalEarned), "sum")
                statCard("Всего нажатий", "\(game.taps)", "hand.tap")
                statCard("Сила клика", formatted(game.clickPower), "bolt.fill")
                statCard("Доход в секунду", formatted(game.incomePerSecond), "timer")
            }
            Button(role: .destructive) { showResetAlert = true } label: {
                Text("Сбросить прогресс")
                    .font(.system(size: 14, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .padding(13)
                    .background(.red.opacity(0.12), in: RoundedRectangle(cornerRadius: 13))
            }
            .padding(.top, 4)
            Spacer()
        }
        .padding(17)
        .frame(maxHeight: .infinity, alignment: .top)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.08), lineWidth: 1))
    }

    private func statCard(_ title: String, _ value: String, _ symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: symbol).foregroundStyle(.yellow)
            Text(title).font(.system(size: 11)).foregroundStyle(.white.opacity(0.6))
            Text(value).font(.system(size: 20, weight: .black, design: .rounded))
        }
        .frame(maxWidth: .infinity, minHeight: 94, alignment: .leading)
        .padding(12)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14))
    }

    private func tabButton(title: String, symbol: String, index: Int) -> some View {
        Button { selectedTab = index } label: {
            Label(title, systemImage: symbol)
                .font(.system(size: 13, weight: .bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .foregroundStyle(selectedTab == index ? .white : .white.opacity(0.65))
                .background(selectedTab == index ? Color.indigo : .white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
        }
    }
}

@main
struct TapClickerApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

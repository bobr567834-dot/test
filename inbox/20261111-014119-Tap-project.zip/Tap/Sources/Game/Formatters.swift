import Foundation

enum Formatters {
    private static let suffixes = ["", "K", "M", "B", "T", "Qa", "Qi"]

    /// Компактная запись: 950, 1.2K, 3.4M … Для маленьких дробных значений можно задать знаки после запятой.
    static func compact(_ value: Double, decimals: Int = 0) -> String {
        guard value.isFinite else { return "∞" }
        var v = abs(value)
        var index = 0
        while v >= 1000 && index < suffixes.count - 1 {
            v /= 1000
            index += 1
        }
        let sign = value < 0 ? "-" : ""

        if index == 0 {
            if decimals > 0 && v != v.rounded() {
                return sign + String(format: "%.\(decimals)f", v)
            }
            return sign + String(format: "%.0f", v)
        }
        var text = String(format: "%.1f", v)
        if text.hasSuffix(".0") { text.removeLast(2) }
        return sign + text + suffixes[index]
    }
}

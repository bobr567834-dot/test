import Foundation

struct Upgrade: Identifiable {
    enum Kind { case click, passive }

    let id: String
    let kind: Kind
    let name: String
    let symbol: String
    let baseCost: Double
    /// Для .click — прибавка за нажатие, для .passive — прибавка в секунду (за один уровень).
    let effect: Double
    let growth: Double

    static let all: [Upgrade] = [
        Upgrade(id: "tap1", kind: .click, name: "Усиление", symbol: "hand.point.up.fill", baseCost: 40, effect: 1, growth: 1.30),
        Upgrade(id: "tap2", kind: .click, name: "Перчатка", symbol: "hand.raised.fill", baseCost: 800, effect: 8, growth: 1.35),
        Upgrade(id: "tap3", kind: .click, name: "Мегаперчатка", symbol: "bolt.fill", baseCost: 25_000, effect: 100, growth: 1.40),
        Upgrade(id: "tap4", kind: .click, name: "Кулак титана", symbol: "flame.fill", baseCost: 1_000_000, effect: 2_500, growth: 1.45),

        Upgrade(id: "auto1", kind: .passive, name: "Помощник", symbol: "person.fill", baseCost: 15, effect: 0.5, growth: 1.15),
        Upgrade(id: "auto2", kind: .passive, name: "Автокликер", symbol: "cursorarrow.click", baseCost: 100, effect: 4, growth: 1.15),
        Upgrade(id: "auto3", kind: .passive, name: "Ферма", symbol: "leaf.fill", baseCost: 1_100, effect: 32, growth: 1.15),
        Upgrade(id: "auto4", kind: .passive, name: "Завод", symbol: "building.2.fill", baseCost: 12_000, effect: 260, growth: 1.15),
        Upgrade(id: "auto5", kind: .passive, name: "Лаборатория", symbol: "atom", baseCost: 130_000, effect: 2_200, growth: 1.15)
    ]

    static var clickUpgrades: [Upgrade] { all.filter { $0.kind == .click } }
    static var passiveUpgrades: [Upgrade] { all.filter { $0.kind == .passive } }
}

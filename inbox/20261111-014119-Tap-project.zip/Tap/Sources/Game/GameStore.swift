import SwiftUI
import UIKit

enum AccentChoice: String, CaseIterable, Identifiable, Codable {
    case blue, green, orange, pink, purple

    var id: String { rawValue }

    var color: Color {
        switch self {
        case .blue: return .blue
        case .green: return .green
        case .orange: return .orange
        case .pink: return .pink
        case .purple: return .purple
        }
    }
}

final class GameStore: ObservableObject {
    @Published private(set) var score: Double = 0
    @Published private(set) var totalEarned: Double = 0
    @Published private(set) var totalTaps: Int = 0
    @Published private(set) var levels: [String: Int] = [:]
    @Published var hapticsOn = true { didSet { saveNow() } }
    @Published var accent: AccentChoice = .blue { didSet { saveNow() } }
    /// Сколько накопилось, пока приложение было закрыто (показывается один раз).
    @Published var welcomeBack: Double?

    private static let maxOfflineSeconds: TimeInterval = 8 * 3600
    private let defaultsKey = "tap.save.v1"
    private let impact = UIImpactFeedbackGenerator(style: .light)
    private let notification = UINotificationFeedbackGenerator()

    private var lastTick = Date()
    private var lastSaved = Date.distantPast
    private var isLoading = false
    private var timer: Timer?

    init() {
        load()
        impact.prepare()
        let timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            self?.tick()
        }
        RunLoop.main.add(timer, forMode: .common)
        self.timer = timer
    }

    // MARK: - Значения

    func level(of upgrade: Upgrade) -> Int {
        levels[upgrade.id] ?? 0
    }

    func cost(of upgrade: Upgrade) -> Double {
        ceil(upgrade.baseCost * pow(upgrade.growth, Double(level(of: upgrade))))
    }

    func canAfford(_ upgrade: Upgrade) -> Bool {
        score >= cost(of: upgrade)
    }

    var pointsPerTap: Double {
        Upgrade.clickUpgrades.reduce(1.0) { $0 + Double(level(of: $1)) * $1.effect }
    }

    var pointsPerSecond: Double {
        Upgrade.passiveUpgrades.reduce(0.0) { $0 + Double(level(of: $1)) * $1.effect }
    }

    // MARK: - Действия

    func tap() {
        let gain = pointsPerTap
        score += gain
        totalEarned += gain
        totalTaps += 1
        if hapticsOn { impact.impactOccurred(intensity: 0.7) }
    }

    func buy(_ upgrade: Upgrade) {
        let price = cost(of: upgrade)
        guard score >= price else { return }
        score -= price
        levels[upgrade.id] = level(of: upgrade) + 1
        if hapticsOn { notification.notificationOccurred(.success) }
        saveNow()
    }

    func resetProgress() {
        score = 0
        totalEarned = 0
        totalTaps = 0
        levels = [:]
        welcomeBack = nil
        lastTick = Date()
        saveNow()
    }

    // MARK: - Время

    private func tick() {
        let now = Date()
        let delta = now.timeIntervalSince(lastTick)
        lastTick = now

        let rate = pointsPerSecond
        if rate > 0 {
            if delta > 2 {
                // Приложение было закрыто или свёрнуто: начисляем доход за это время (с ограничением).
                let capped = min(delta, Self.maxOfflineSeconds)
                let earned = capped * rate
                score += earned
                totalEarned += earned
                if capped > 10 { welcomeBack = earned }
            } else {
                let earned = delta * rate
                score += earned
                totalEarned += earned
            }
        }

        if now.timeIntervalSince(lastSaved) > 5 { saveNow() }
    }

    // MARK: - Сохранение

    private struct SaveData: Codable {
        var score: Double
        var totalEarned: Double
        var totalTaps: Int
        var levels: [String: Int]
        var lastSave: Date
        var hapticsOn: Bool
        var accent: AccentChoice
    }

    func saveNow() {
        guard !isLoading else { return }
        let data = SaveData(
            score: score,
            totalEarned: totalEarned,
            totalTaps: totalTaps,
            levels: levels,
            lastSave: Date(),
            hapticsOn: hapticsOn,
            accent: accent
        )
        if let encoded = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(encoded, forKey: defaultsKey)
            lastSaved = Date()
        }
    }

    private func load() {
        guard let raw = UserDefaults.standard.data(forKey: defaultsKey),
              let saved = try? JSONDecoder().decode(SaveData.self, from: raw) else { return }
        isLoading = true
        score = saved.score
        totalEarned = saved.totalEarned
        totalTaps = saved.totalTaps
        levels = saved.levels
        hapticsOn = saved.hapticsOn
        accent = saved.accent
        lastTick = saved.lastSave   // первый tick() начислит доход за время «офлайн»
        isLoading = false
    }
}

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: GameStore

    private var welcomeBinding: Binding<Bool> {
        Binding(
            get: { store.welcomeBack != nil },
            set: { shown in
                if !shown { store.welcomeBack = nil }
            }
        )
    }

    var body: some View {
        TabView {
            GameView()
                .tabItem { Label("Игра", systemImage: "hand.tap.fill") }

            UpgradesView()
                .tabItem { Label("Улучшения", systemImage: "arrow.up.circle.fill") }

            MoreView()
                .tabItem { Label("Ещё", systemImage: "ellipsis.circle.fill") }
        }
        .alert("С возвращением!", isPresented: welcomeBinding) {
            Button("Забрать", role: .cancel) {}
        } message: {
            Text("Пока вас не было, накоплено +\(Formatters.compact(floor(store.welcomeBack ?? 0)))")
        }
    }
}

import SwiftUI

@main
struct TapApp: App {
    @StateObject private var store = GameStore()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .tint(store.accent.color)
        }
        .onChange(of: scenePhase) { phase in
            if phase != .active { store.saveNow() }
        }
    }
}

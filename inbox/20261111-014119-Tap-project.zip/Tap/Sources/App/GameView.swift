import SwiftUI

private struct Floater: Identifiable {
    let id = UUID()
    let text: String
    let dx: CGFloat
}

/// Лёгкое сжатие кнопки при нажатии.
private struct TapButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

/// Всплывающее «+N», которое поднимается и исчезает.
private struct FloatingText: View {
    let text: String
    @State private var lifted = false

    var body: some View {
        Text(text)
            .font(.system(size: 24, weight: .semibold, design: .rounded))
            .foregroundStyle(.tint)
            .offset(y: lifted ? -80 : 0)
            .opacity(lifted ? 0 : 1)
            .onAppear {
                withAnimation(.easeOut(duration: 0.8)) { lifted = true }
            }
    }
}

struct GameView: View {
    @EnvironmentObject var store: GameStore
    @State private var floaters: [Floater] = []

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 0)

            VStack(spacing: 6) {
                Text(Formatters.compact(floor(store.score)))
                    .font(.system(size: 64, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)

                Text("\(Formatters.compact(store.pointsPerSecond, decimals: 1)) в секунду")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 24)

            Spacer(minLength: 0)

            ZStack {
                Button {
                    store.tap()
                    addFloater()
                } label: {
                    Circle()
                        .fill(.tint)
                        .frame(width: 220, height: 220)
                        .overlay(
                            Image(systemName: "hand.tap.fill")
                                .font(.system(size: 64))
                                .foregroundStyle(Color.white.opacity(0.95))
                        )
                        .shadow(color: store.accent.color.opacity(0.35), radius: 24, x: 0, y: 10)
                }
                .buttonStyle(TapButtonStyle())

                ZStack {
                    ForEach(floaters) { floater in
                        FloatingText(text: floater.text)
                            .offset(x: floater.dx, y: -110)
                    }
                }
                .allowsHitTesting(false)
            }

            Spacer(minLength: 0)

            Text("+\(Formatters.compact(store.pointsPerTap)) за нажатие")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .padding(.bottom, 24)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }

    private func addFloater() {
        let item = Floater(
            text: "+" + Formatters.compact(store.pointsPerTap),
            dx: CGFloat.random(in: -50...50)
        )
        floaters.append(item)
        if floaters.count > 12 { floaters.removeFirst() }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            floaters.removeAll { $0.id == item.id }
        }
    }
}

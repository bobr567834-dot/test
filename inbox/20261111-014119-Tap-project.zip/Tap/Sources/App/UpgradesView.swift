import SwiftUI

struct UpgradesView: View {
    @EnvironmentObject var store: GameStore

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(Upgrade.clickUpgrades) { upgrade in
                        row(upgrade)
                    }
                } header: {
                    Text("Сила нажатия")
                }

                Section {
                    ForEach(Upgrade.passiveUpgrades) { upgrade in
                        row(upgrade)
                    }
                } header: {
                    Text("Пассивный доход")
                } footer: {
                    Text("Доход копится и когда приложение закрыто — до 8 часов.")
                }
            }
            .navigationTitle("Улучшения")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Text(Formatters.compact(floor(store.score)))
                        .font(.body.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func detail(for upgrade: Upgrade) -> String {
        let level = store.level(of: upgrade)
        let effect = Formatters.compact(upgrade.effect, decimals: 1)
        switch upgrade.kind {
        case .click: return "+\(effect) за нажатие · ур. \(level)"
        case .passive: return "+\(effect) в секунду · ур. \(level)"
        }
    }

    private func row(_ upgrade: Upgrade) -> some View {
        HStack(spacing: 12) {
            Image(systemName: upgrade.symbol)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Color.white)
                .frame(width: 34, height: 34)
                .background(.tint, in: RoundedRectangle(cornerRadius: 8, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(upgrade.name)
                Text(detail(for: upgrade))
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            Button {
                store.buy(upgrade)
            } label: {
                Text(Formatters.compact(store.cost(of: upgrade)))
                    .monospacedDigit()
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.small)
            .disabled(!store.canAfford(upgrade))
        }
        .padding(.vertical, 2)
    }
}

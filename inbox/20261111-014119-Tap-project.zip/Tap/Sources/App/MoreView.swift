import SwiftUI

struct MoreView: View {
    @EnvironmentObject var store: GameStore
    @State private var confirmReset = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    LabeledContent("Нажатий", value: "\(store.totalTaps)")
                    LabeledContent("Всего заработано", value: Formatters.compact(floor(store.totalEarned)))
                    LabeledContent("За нажатие", value: Formatters.compact(store.pointsPerTap))
                    LabeledContent("В секунду", value: Formatters.compact(store.pointsPerSecond, decimals: 1))
                } header: {
                    Text("Статистика")
                }

                Section {
                    HStack(spacing: 16) {
                        ForEach(AccentChoice.allCases) { choice in
                            Button {
                                store.accent = choice
                            } label: {
                                Circle()
                                    .fill(choice.color)
                                    .frame(width: 30, height: 30)
                                    .overlay(
                                        Circle()
                                            .stroke(Color.primary.opacity(store.accent == choice ? 0.9 : 0), lineWidth: 2)
                                            .padding(-4)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 6)
                } header: {
                    Text("Цвет акцента")
                }

                Section {
                    Toggle("Вибрация", isOn: $store.hapticsOn)
                } header: {
                    Text("Отклик")
                }

                Section {
                    Button("Сбросить прогресс", role: .destructive) {
                        confirmReset = true
                    }
                }
            }
            .navigationTitle("Ещё")
            .confirmationDialog("Сбросить весь прогресс?", isPresented: $confirmReset, titleVisibility: .visible) {
                Button("Сбросить", role: .destructive) {
                    store.resetProgress()
                }
                Button("Отмена", role: .cancel) {}
            } message: {
                Text("Это действие нельзя отменить.")
            }
        }
    }
}

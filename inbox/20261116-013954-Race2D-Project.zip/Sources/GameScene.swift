import SpriteKit

class GameScene: SKScene {
    
    var playerCar: SKSpriteNode!
    var bots: [BotCar] = []
    var waypoints: [CGPoint] = []
    
    var isTurningLeft = false
    var isTurningRight = false
    
    var playerVelocity = CGVector(dx: 0, dy: 0)
    let maxPlayerSpeed: CGFloat = 400
    let acceleration: CGFloat = 300
    let friction: CGFloat = 0.98
    let lateralGrip: CGFloat = 0.82
    let turnSpeed: CGFloat = 3.5
    
    var playerWaypointIndex = 0
    var playerLap = 1
    let totalLaps = 3
    var raceFinished = false
    
    let skidMarkLayer = SKNode()
    
    let hudLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    let gameOverLabel = SKLabelNode(fontNamed: "AvenirNext-Heavy")
    
    class BotCar {
        let node: SKSpriteNode
        var currentWaypoint = 0
        var lap = 1
        let maxSpeed: CGFloat
        let turnRate: CGFloat
        var offset: CGPoint
        
        init(color: UIColor, maxSpeed: CGFloat, turnRate: CGFloat, offset: CGPoint) {
            self.node = SKSpriteNode(color: color, size: CGSize(width: 24, height: 42))
            self.maxSpeed = maxSpeed
            self.turnRate = turnRate
            self.offset = offset
            
            let windshield = SKSpriteNode(color: .black, size: CGSize(width: 18, height: 8))
            windshield.position = CGPoint(x: 0, y: 10)
            self.node.addChild(windshield)
        }
    }
    
    override func didMove(to view: SKView) {
        backgroundColor = UIColor(red: 0.18, green: 0.45, blue: 0.22, alpha: 1.0)
        
        addChild(skidMarkLayer)
        setupTrack()
        setupCars()
        setupHUD()
    }
    
    func setupTrack() {
        let w = size.width
        let h = size.height
        let marginX: CGFloat = w * 0.22
        let marginY: CGFloat = h * 0.18
        
        waypoints = [
            CGPoint(x: w - marginX, y: h * 0.5),
            CGPoint(x: w - marginX, y: h - marginY),
            CGPoint(x: w * 0.5, y: h - marginY * 0.7),
            CGPoint(x: marginX, y: h - marginY),
            CGPoint(x: marginX, y: h * 0.5),
            CGPoint(x: marginX, y: marginY),
            CGPoint(x: w * 0.5, y: marginY * 0.7),
            CGPoint(x: w - marginX, y: marginY)
        ]
        
        let path = CGMutablePath()
        path.addLines(between: waypoints)
        path.closeSubpath()
        
        let curbNode = SKShapeNode(path: path)
        curbNode.strokeColor = .systemRed
        curbNode.lineWidth = 115
        curbNode.lineJoin = .round
        addChild(curbNode)
        
        let roadNode = SKShapeNode(path: path)
        roadNode.strokeColor = UIColor(white: 0.22, alpha: 1.0)
        roadNode.lineWidth = 100
        roadNode.lineJoin = .round
        addChild(roadNode)
        
        let centerLine = SKShapeNode(path: path)
        centerLine.strokeColor = UIColor(white: 1.0, alpha: 0.3)
        centerLine.lineWidth = 3
        centerLine.lineJoin = .round
        addChild(centerLine)
        
        let finishLine = SKSpriteNode(color: .white, size: CGSize(width: 100, height: 10))
        finishLine.position = waypoints[0]
        addChild(finishLine)
    }
    
    func setupCars() {
        let startPos = waypoints[0]
        
        playerCar = SKSpriteNode(color: .systemBlue, size: CGSize(width: 24, height: 42))
        playerCar.position = CGPoint(x: startPos.x - 20, y: startPos.y - 30)
        
        let windshield = SKSpriteNode(color: .cyan, size: CGSize(width: 18, height: 8))
        windshield.position = CGPoint(x: 0, y: 10)
        playerCar.addChild(windshield)
        addChild(playerCar)
        
        let botConfigs: [(UIColor, CGFloat, CGPoint)] = [
            (.systemRed, 360, CGPoint(x: 20, y: -30)),
            (.systemYellow, 340, CGPoint(x: -20, y: -80)),
            (.systemOrange, 320, CGPoint(x: 20, y: -80))
        ]
        
        for config in botConfigs {
            let bot = BotCar(color: config.0, maxSpeed: config.1, turnRate: 3.5, offset: config.2)
            bot.node.position = CGPoint(x: startPos.x + config.2.x, y: startPos.y + config.2.y)
            bot.currentWaypoint = 1
            addChild(bot.node)
            bots.append(bot)
        }
    }
    
    func setupHUD() {
        hudLabel.fontSize = 20
        hudLabel.fontColor = .white
        hudLabel.position = CGPoint(x: size.width / 2, y: size.height - 60)
        hudLabel.zPosition = 10
        addChild(hudLabel)
        
        gameOverLabel.fontSize = 32
        gameOverLabel.fontColor = .yellow
        gameOverLabel.position = CGPoint(x: size.width / 2, y: size.height / 2)
        gameOverLabel.zPosition = 20
        gameOverLabel.isHidden = true
        addChild(gameOverLabel)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if raceFinished {
            restartGame()
            return
        }
        for touch in touches {
            let loc = touch.location(in: self)
            if loc.x < size.width / 2 { isTurningLeft = true }
            else { isTurningRight = true }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let loc = touch.location(in: self)
            if loc.x < size.width / 2 { isTurningLeft = false }
            else { isTurningRight = false }
        }
    }
    
    private var lastUpdateTime: TimeInterval = 0
    
    override func update(_ currentTime: TimeInterval) {
        if lastUpdateTime == 0 { lastUpdateTime = currentTime }
        let dt = CGFloat(currentTime - lastUpdateTime)
        lastUpdateTime = currentTime
        
        if raceFinished { return }
        
        updatePlayer(dt: dt)
        updateBots(dt: dt)
        checkCollisions()
        updateRaceProgress()
    }
    
    func isOnRoad(point: CGPoint) -> Bool {
        let roadHalfWidth: CGFloat = 50
        for i in 0..<waypoints.count {
            let p1 = waypoints[i]
            let p2 = waypoints[(i + 1) % waypoints.count]
            if distanceToSegment(p: point, a: p1, b: p2) <= roadHalfWidth {
                return true
            }
        }
        return false
    }
    
    func distanceToSegment(p: CGPoint, a: CGPoint, b: CGPoint) -> CGFloat {
        let l2 = (b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y)
        if l2 == 0 { return hypot(p.x - a.x, p.y - a.y) }
        var t = ((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)) / l2
        t = max(0, min(1, t))
        let proj = CGPoint(x: a.x + t * (b.x - a.x), y: a.y + t * (b.y - a.y))
        return hypot(p.x - proj.x, p.y - proj.y)
    }
    
    func updatePlayer(dt: CGFloat) {
        let onRoad = isOnRoad(point: playerCar.position)
        let currentMaxSpeed = onRoad ? maxPlayerSpeed : 130
        let currentAcceleration = onRoad ? acceleration : 70
        
        if isTurningLeft { playerCar.zRotation += turnSpeed * dt }
        if isTurningRight { playerCar.zRotation -= turnSpeed * dt }
        
        let forwardAngle = playerCar.zRotation + .pi / 2
        let forwardDir = CGVector(dx: cos(forwardAngle), dy: sin(forwardAngle))
        
        playerVelocity.dx += forwardDir.dx * currentAcceleration * dt
        playerVelocity.dy += forwardDir.dy * currentAcceleration * dt
        
        let speed = hypot(playerVelocity.dx, playerVelocity.dy)
        if speed > currentMaxSpeed {
            playerVelocity.dx = (playerVelocity.dx / speed) * currentMaxSpeed
            playerVelocity.dy = (playerVelocity.dy / speed) * currentMaxSpeed
        }
        
        let rightAngle = playerCar.zRotation
        let rightDir = CGVector(dx: cos(rightAngle), dy: sin(rightAngle))
        
        let forwardSpeed = playerVelocity.dx * forwardDir.dx + playerVelocity.dy * forwardDir.dy
        let lateralSpeed = playerVelocity.dx * rightDir.dx + playerVelocity.dy * rightDir.dy
        
        let grip = onRoad ? lateralGrip : 0.95
        let newLateralSpeed = lateralSpeed * grip
        
        playerVelocity.dx = forwardDir.dx * forwardSpeed + rightDir.dx * newLateralSpeed
        playerVelocity.dy = forwardDir.dy * forwardSpeed + rightDir.dy * newLateralSpeed
        
        playerVelocity.dx *= friction
        playerVelocity.dy *= friction
        
        playerCar.position.x += playerVelocity.dx * dt
        playerCar.position.y += playerVelocity.dy * dt
        
        if onRoad && (abs(lateralSpeed) > 110 || (isTurningLeft || isTurningRight) && speed > 220) {
            spawnSkidMark(at: playerCar.position, rotation: playerCar.zRotation)
        }
        
        let target = waypoints[playerWaypointIndex]
        if hypot(target.x - playerCar.position.x, target.y - playerCar.position.y) < 90 {
            playerWaypointIndex += 1
            if playerWaypointIndex >= waypoints.count {
                playerWaypointIndex = 0
                playerLap += 1
                if playerLap > totalLaps { finishRace() }
            }
        }
    }
    
    func spawnSkidMark(at position: CGPoint, rotation: CGFloat) {
        let skid = SKSpriteNode(color: UIColor(white: 0.1, alpha: 0.4), size: CGSize(width: 4, height: 10))
        skid.position = position
        skid.zRotation = rotation
        skid.zPosition = 1
        skidMarkLayer.addChild(skid)
        
        let fadeOut = SKAction.sequence([
            SKAction.fadeAlpha(to: 0, duration: 1.2),
            SKAction.removeFromParent()
        ])
        skid.run(fadeOut)
    }
    
    func updateBots(dt: CGFloat) {
        for bot in bots {
            let baseTarget = waypoints[bot.currentWaypoint]
            let target = CGPoint(x: baseTarget.x + bot.offset.x * 0.5, y: baseTarget.y + bot.offset.y * 0.5)
            
            let dx = target.x - bot.node.position.x
            let dy = target.y - bot.node.position.y
            let distance = hypot(dx, dy)
            
            let targetAngle = atan2(dy, dx) - .pi / 2
            var angleDiff = targetAngle - bot.node.zRotation
            while angleDiff > .pi { angleDiff -= 2 * .pi }
            while angleDiff < -.pi { angleDiff += 2 * .pi }
            
            bot.node.zRotation += angleDiff * bot.turnRate * dt
            
            let moveAngle = bot.node.zRotation + .pi / 2
            bot.node.position.x += cos(moveAngle) * bot.maxSpeed * dt
            bot.node.position.y += sin(moveAngle) * bot.maxSpeed * dt
            
            if distance < 65 {
                bot.currentWaypoint += 1
                if bot.currentWaypoint >= waypoints.count {
                    bot.currentWaypoint = 0
                    bot.lap += 1
                }
            }
        }
    }
    
    func checkCollisions() {
        var allCars = bots.map { $0.node }
        allCars.append(playerCar)
        
        for i in 0..<allCars.count {
            for j in (i + 1)..<allCars.count {
                let carA = allCars[i]
                let carB = allCars[j]
                let dx = carB.position.x - carA.position.x
                let dy = carB.position.y - carA.position.y
                let dist = hypot(dx, dy)
                let minDist: CGFloat = 30
                
                if dist < minDist && dist > 0 {
                    let overlap = (minDist - dist) / 2
                    let nx = dx / dist
                    let ny = dy / dist
                    carA.position.x -= nx * overlap
                    carA.position.y -= ny * overlap
                    carB.position.x += nx * overlap
                    carB.position.y += ny * overlap
                }
            }
        }
    }
    
    func updateRaceProgress() {
        let playerScore = playerLap * 100 + playerWaypointIndex
        var place = 1
        for bot in bots {
            let botScore = bot.lap * 100 + bot.currentWaypoint
            if botScore > playerScore { place += 1 }
        }
        let displayLap = min(playerLap, totalLaps)
        hudLabel.text = "Круг: \(displayLap)/\(totalLaps)   |   Место: \(place)/\(bots.count + 1)"
    }
    
    func finishRace() {
        raceFinished = true
        updateRaceProgress()
        gameOverLabel.text = "ФИНИШ! Тапни для рестарта"
        gameOverLabel.isHidden = false
    }
    
    func restartGame() {
        removeAllChildren()
        skidMarkLayer.removeAllChildren()
        addChild(skidMarkLayer)
        bots.removeAll()
        playerLap = 1
        playerWaypointIndex = 0
        playerVelocity = CGVector(dx: 0, dy: 0)
        raceFinished = false
        gameOverLabel.isHidden = true
        setupTrack()
        setupCars()
        setupHUD()
    }
}

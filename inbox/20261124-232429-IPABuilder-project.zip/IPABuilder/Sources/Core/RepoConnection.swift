import Foundation

/// Сохранённое подключение к репозиторию. Токен лежит в Keychain и в этой структуре не хранится.
struct RepoConnection: Identifiable, Codable, Equatable {
    var id = UUID()
    /// Имя в виде «владелец/репозиторий».
    var repo: String
    /// Установлен ли в репозитории workflow для сборки.
    var isConfigured = false
}

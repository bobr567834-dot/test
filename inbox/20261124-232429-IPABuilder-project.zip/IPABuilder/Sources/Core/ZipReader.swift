import Compression
import Foundation

struct ZipEntry {
    let path: String
    let isDirectory: Bool
    let flags: UInt16
    let method: UInt16
    let compressedSize: Int
    let uncompressedSize: Int
    let localHeaderOffset: Int
}

enum ZipError: LocalizedError {
    case notAZip
    case corrupted
    case unsupported(String)

    var errorDescription: String? {
        switch self {
        case .notAZip: return "Файл не похож на zip-архив."
        case .corrupted: return "Архив повреждён."
        case .unsupported(let what): return "Архив содержит неподдерживаемое: \(what)."
        }
    }
}

/// Чтение zip на устройстве: список файлов и распаковка (без сжатия и deflate). Zip64 и шифрование не поддерживаются.
enum ZipReader {
    private static func u16(_ d: Data, _ i: Int) -> Int {
        Int(d[i]) | Int(d[i + 1]) << 8
    }

    private static func u32(_ d: Data, _ i: Int) -> Int {
        Int(d[i]) | Int(d[i + 1]) << 8 | Int(d[i + 2]) << 16 | Int(d[i + 3]) << 24
    }

    /// Список записей из центрального каталога (сами файлы не распаковываются).
    static func entries(in data: Data) throws -> [ZipEntry] {
        guard data.count >= 22 else { throw ZipError.notAZip }

        // Запись конца каталога (сигнатура 0x06054b50) ищем с конца файла.
        var eocd = -1
        var position = data.count - 22
        let lowest = max(0, data.count - 22 - 65_535)
        while position >= lowest {
            if u32(data, position) == 0x06054b50 {
                eocd = position
                break
            }
            position -= 1
        }
        guard eocd >= 0 else { throw ZipError.notAZip }

        let total = u16(data, eocd + 10)
        let directoryOffset = u32(data, eocd + 16)
        if total == 0xFFFF || directoryOffset == 0xFFFF_FFFF { throw ZipError.unsupported("формат zip64") }

        var result: [ZipEntry] = []
        var p = directoryOffset
        for _ in 0..<total {
            guard p + 46 <= data.count, u32(data, p) == 0x02014b50 else { throw ZipError.corrupted }

            let flags = u16(data, p + 8)
            let method = u16(data, p + 10)
            let compressed = u32(data, p + 20)
            let uncompressed = u32(data, p + 24)
            let nameLength = u16(data, p + 28)
            let extraLength = u16(data, p + 30)
            let commentLength = u16(data, p + 32)
            let localOffset = u32(data, p + 42)

            guard p + 46 + nameLength <= data.count else { throw ZipError.corrupted }
            let name = String(decoding: data.subdata(in: (p + 46)..<(p + 46 + nameLength)), as: UTF8.self)

            result.append(ZipEntry(
                path: name,
                isDirectory: name.hasSuffix("/"),
                flags: UInt16(flags),
                method: UInt16(method),
                compressedSize: compressed,
                uncompressedSize: uncompressed,
                localHeaderOffset: localOffset
            ))
            p += 46 + nameLength + extraLength + commentLength
        }
        return result
    }

    /// Есть ли в архиве готовое описание проекта (project.yml или .xcodeproj).
    static func hasProjectDefinition(_ entries: [ZipEntry]) -> Bool {
        entries.contains { entry in
            let parts = entry.path.split(separator: "/").map(String.init)
            if parts.first == "__MACOSX" { return false }
            if !entry.isDirectory, parts.last == "project.yml" { return true }
            return parts.contains { $0.hasSuffix(".xcodeproj") }
        }
    }

    /// Распаковывает одну запись.
    static func extract(_ entry: ZipEntry, from data: Data, maxSize: Int) throws -> Data {
        if entry.flags & 0x1 != 0 { throw ZipError.unsupported("зашифрованные файлы") }
        guard entry.uncompressedSize <= maxSize else { throw ZipError.unsupported("слишком большой файл") }
        if entry.uncompressedSize == 0 { return Data() }

        let header = entry.localHeaderOffset
        guard header + 30 <= data.count, u32(data, header) == 0x04034b50 else { throw ZipError.corrupted }

        let start = header + 30 + u16(data, header + 26) + u16(data, header + 28)
        let end = start + entry.compressedSize
        guard end <= data.count, entry.compressedSize > 0 else { throw ZipError.corrupted }
        let body = data.subdata(in: start..<end)

        switch entry.method {
        case 0:
            return body
        case 8:
            var output = [UInt8](repeating: 0, count: entry.uncompressedSize)
            let written = body.withUnsafeBytes { source -> Int in
                output.withUnsafeMutableBytes { destination -> Int in
                    guard let from = source.bindMemory(to: UInt8.self).baseAddress,
                          let to = destination.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                    // COMPRESSION_ZLIB в Apple Compression — это «сырой» deflate, как внутри zip.
                    return compression_decode_buffer(to, destination.count, from, source.count, nil, COMPRESSION_ZLIB)
                }
            }
            guard written == entry.uncompressedSize else { throw ZipError.corrupted }
            return Data(output)
        default:
            throw ZipError.unsupported("метод сжатия \(entry.method)")
        }
    }
}

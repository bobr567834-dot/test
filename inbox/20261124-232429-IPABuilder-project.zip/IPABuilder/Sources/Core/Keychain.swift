import Foundation
import Security

/// Токены хранятся в Keychain (по одному на каждый репозиторий). Если подпись приложения не даёт доступа
/// к Keychain (бывает при пересборке сторонними подписывателями) — запасной вариант: UserDefaults.
enum Keychain {
    private static let service = "com.example.ipabuilder"
    /// Аккаунт, под которым токен хранился, пока репозиторий был один.
    static let legacyAccount = "github-token"

    private static func query(_ account: String) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
    }

    private static func fallbackKey(_ account: String) -> String {
        account == legacyAccount ? "builder.token.fallback" : "builder.token.fallback.\(account)"
    }

    static func save(_ value: String, account: String = legacyAccount) {
        SecItemDelete(query(account) as CFDictionary)
        var item = query(account)
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        if SecItemAdd(item as CFDictionary, nil) == errSecSuccess {
            UserDefaults.standard.removeObject(forKey: fallbackKey(account))
        } else {
            UserDefaults.standard.set(value, forKey: fallbackKey(account))
        }
    }

    static func load(account: String = legacyAccount) -> String? {
        var request = query(account)
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: AnyObject?
        if SecItemCopyMatching(request as CFDictionary, &result) == errSecSuccess,
           let data = result as? Data,
           let text = String(data: data, encoding: .utf8) {
            return text
        }
        return UserDefaults.standard.string(forKey: fallbackKey(account))
    }

    static func delete(account: String) {
        SecItemDelete(query(account) as CFDictionary)
        UserDefaults.standard.removeObject(forKey: fallbackKey(account))
    }
}

import UIKit

struct AppIconOption: Identifiable, Equatable {
    let id: String
    let title: String
    /// Имя набора иконки в Assets.xcassets; nil — основная иконка.
    let iconName: String?
    /// Имя картинки-превью для списка выбора.
    let preview: String

    static let all: [AppIconOption] = [
        AppIconOption(id: "default", title: "Оранжевая", iconName: nil, preview: "IconPreviewDefault"),
        AppIconOption(id: "dark", title: "Тёмная", iconName: "AppIconDark", preview: "IconPreviewDark"),
        AppIconOption(id: "blue", title: "Синяя", iconName: "AppIconBlue", preview: "IconPreviewBlue"),
        AppIconOption(id: "green", title: "Зелёная", iconName: "AppIconGreen", preview: "IconPreviewGreen"),
        AppIconOption(id: "light", title: "Светлая", iconName: "AppIconLight", preview: "IconPreviewLight"),
        AppIconOption(id: "hammer", title: "Молоток", iconName: "AppIconHammer", preview: "IconPreviewHammer"),
        AppIconOption(id: "purple", title: "Фиолетовая", iconName: "AppIconPurple", preview: "IconPreviewPurple"),
        AppIconOption(id: "pink", title: "Розовая", iconName: "AppIconPink", preview: "IconPreviewPink"),
        AppIconOption(id: "teal", title: "Бирюзовая", iconName: "AppIconTeal", preview: "IconPreviewTeal"),
        AppIconOption(id: "gold", title: "Золотая", iconName: "AppIconGold", preview: "IconPreviewGold"),
        AppIconOption(id: "midnight", title: "Полночь", iconName: "AppIconMidnight", preview: "IconPreviewMidnight"),
        AppIconOption(id: "black", title: "Чёрная", iconName: "AppIconBlack", preview: "IconPreviewBlack"),
        AppIconOption(id: "sunset", title: "Закат", iconName: "AppIconSunset", preview: "IconPreviewSunset"),
        AppIconOption(id: "bolt", title: "Молния", iconName: "AppIconBolt", preview: "IconPreviewBolt"),
        AppIconOption(id: "code", title: "Код", iconName: "AppIconCode", preview: "IconPreviewCode"),
        AppIconOption(id: "gear", title: "Шестерёнка", iconName: "AppIconGear", preview: "IconPreviewGear")
    ]
}

/// Смена иконки приложения через альтернативные иконки iOS.
@MainActor
final class IconManager: ObservableObject {
    @Published private(set) var currentID = "default"
    @Published var message: String?

    var isSupported: Bool {
        UIApplication.shared.supportsAlternateIcons
    }

    init() {
        refresh()
    }

    func refresh() {
        let name = UIApplication.shared.alternateIconName
        currentID = AppIconOption.all.first { $0.iconName == name }?.id ?? "default"
    }

    func select(_ option: AppIconOption) async {
        guard option.id != currentID else { return }
        do {
            try await UIApplication.shared.setAlternateIconName(option.iconName)
            currentID = option.id
            message = nil
        } catch {
            message = "Не удалось сменить иконку: \(error.localizedDescription)"
        }
    }
}

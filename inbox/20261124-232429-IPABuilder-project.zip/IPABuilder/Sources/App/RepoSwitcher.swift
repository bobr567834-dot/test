import SwiftUI

/// Быстрое переключение между сохранёнными репозиториями (экраны «Сборка» и «Код»).
struct RepoSwitcher: View {
    @EnvironmentObject var model: BuilderModel

    var body: some View {
        HStack {
            if model.connections.isEmpty {
                Button {
                    model.selectedTab = 2
                } label: {
                    pill(text: "Подключить репозиторий", icon: "plus", showsChevron: false)
                }
                .buttonStyle(.plain)
            } else {
                Menu {
                    ForEach(model.connections) { connection in
                        Button {
                            model.selectConnection(connection.id)
                        } label: {
                            if connection.id == model.activeID && !model.isAddingNew {
                                Label(connection.repo, systemImage: "checkmark")
                            } else {
                                Text(connection.repo)
                            }
                        }
                    }
                    Divider()
                    Button {
                        model.selectedTab = 2
                        model.beginAddingConnection()
                    } label: {
                        Label("Добавить репозиторий…", systemImage: "plus")
                    }
                } label: {
                    pill(text: model.activeRepoTitle, icon: "shippingbox.fill", showsChevron: true)
                }
                .disabled(model.isBusy)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 24)
        .padding(.top, 14)
    }

    private func pill(text: String, icon: String, showsChevron: Bool) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(Theme.accent)
            Text(text)
                .lineLimit(1)
            if showsChevron {
                Image(systemName: "chevron.up.chevron.down")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(Theme.inkSoft)
            }
        }
        .font(.rounded(13, .semibold))
        .foregroundColor(Theme.ink)
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Theme.surface)
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Theme.line, lineWidth: 1))
    }
}

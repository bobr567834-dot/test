import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject var model: BuilderModel
    @StateObject private var icons = IconManager()
    @State private var confirmDelete = false

    private let iconColumns = [
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10)
    ]

    private let tokenURL = URL(string: "https://github.com/settings/tokens/new?scopes=repo,workflow&description=IPA%20Builder")

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                ScreenHeader(title: "Настройка", subtitle: "Подключите GitHub один раз")

                SectionLabel("Параметры приложения")
                ProjectParamsPanel()
                    .padding(.horizontal, 20)

                Text("Нужны, когда приложение само создаёт проект: для выбранных файлов и папки, архива без project.yml и кода из редактора. Если в архиве уже есть project.yml или .xcodeproj, он уходит на сборку как есть. Платформа «Авто» определяется по коду (WatchKit — это watchOS), а разрешения добавляются по тому, что код использует.")
                    .font(.system(size: 12))
                    .foregroundColor(Theme.inkSoft)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 24)
                    .padding(.top, 10)

                SectionLabel("Репозитории")
                Panel {
                    if model.connections.isEmpty {
                        Text("Пока нет репозиториев. Введите токен и имя репозитория ниже и нажмите «Проверить и подключить».")
                            .font(.system(size: 13))
                            .foregroundColor(Theme.inkSoft)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                    } else {
                        ForEach(model.connections) { connection in
                            VStack(spacing: 0) {
                                Button {
                                    model.selectConnection(connection.id)
                                } label: {
                                    repoRow(connection)
                                }
                                .buttonStyle(.plain)
                                .disabled(model.isBusy)
                                .contextMenu {
                                    Button(role: .destructive) {
                                        model.deleteConnection(connection.id)
                                    } label: {
                                        Label("Удалить", systemImage: "trash")
                                    }
                                }
                                RowDivider()
                            }
                        }

                        Button {
                            model.beginAddingConnection()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "plus")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(Theme.accent)
                                    .frame(width: 36, height: 36)
                                    .background(Theme.accent.opacity(0.12))
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                Text("Добавить репозиторий")
                                    .font(.rounded(15, .semibold))
                                    .foregroundColor(Theme.accent)
                                Spacer(minLength: 0)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .disabled(model.isBusy)
                    }
                }
                .padding(.horizontal, 20)

                SectionLabel(model.isAddingNew ? "Новый репозиторий" : "Доступ к репозиторию")
                Panel {
                    FieldRow(label: "Токен GitHub", text: $model.token, placeholder: "ghp_…", secure: true, mono: true)
                    RowDivider()
                    FieldRow(label: "Репозиторий (владелец/имя)", text: $model.repoFull, placeholder: "ivan/ipa-builder", mono: true)
                }
                .padding(.horizontal, 20)

                VStack(alignment: .leading, spacing: 12) {
                    Button {
                        model.setup()
                    } label: {
                        if model.isSettingUp {
                            HStack(spacing: 8) {
                                ProgressView().tint(.white)
                                Text("Подключаю…")
                            }
                            .font(.rounded(15, .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Theme.accent)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        } else {
                            PillButton(title: "Проверить и подключить", icon: "link")
                        }
                    }
                    .disabled(model.isSettingUp)

                    if let message = model.setupMessage {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: model.setupIsError ? "exclamationmark.circle.fill" : "checkmark.circle.fill")
                            Text(message)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .font(.system(size: 13))
                        .foregroundColor(model.setupIsError ? Theme.danger : Theme.success)
                    } else if model.isConfigured {
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.circle.fill")
                            Text("Подключено")
                        }
                        .font(.system(size: 13))
                        .foregroundColor(Theme.success)
                    }

                    if model.isAddingNew {
                        Button {
                            model.cancelAddingConnection()
                        } label: {
                            PillButton(title: "Отмена", icon: "xmark", filled: false)
                        }
                    } else if model.activeID != nil {
                        Button {
                            confirmDelete = true
                        } label: {
                            Text("Удалить это подключение")
                                .font(.rounded(14, .semibold))
                                .foregroundColor(Theme.danger)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                        }
                        .buttonStyle(.plain)
                        .disabled(model.isBusy)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .confirmationDialog("Удалить подключение к «\(model.activeRepoTitle)»?", isPresented: $confirmDelete, titleVisibility: .visible) {
                    Button("Удалить", role: .destructive) {
                        if let id = model.activeID { model.deleteConnection(id) }
                    }
                    Button("Отмена", role: .cancel) {}
                } message: {
                    Text("Токен будет стёрт с этого устройства. Сам репозиторий на GitHub и его содержимое не изменятся.")
                }

                SectionLabel("Иконка приложения")
                Panel {
                    if icons.isSupported {
                        LazyVGrid(columns: iconColumns, spacing: 16) {
                            ForEach(AppIconOption.all) { option in
                                iconCell(option)
                            }
                        }
                        .padding(16)
                    } else {
                        Text("В этой сборке смена иконки недоступна.")
                            .font(.system(size: 13))
                            .foregroundColor(Theme.inkSoft)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                    }

                    if let message = icons.message {
                        RowDivider()
                        Text(message)
                            .font(.system(size: 13))
                            .foregroundColor(Theme.danger)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                    }
                }
                .padding(.horizontal, 20)

                Text("iOS при смене иконки сама покажет уведомление об этом — так и должно быть.")
                    .font(.system(size: 12))
                    .foregroundColor(Theme.inkSoft)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 24)
                    .padding(.top, 8)

                SectionLabel("Как получить токен")
                Panel {
                    VStack(alignment: .leading, spacing: 14) {
                        StepRow(number: 1, text: "Нажмите кнопку ниже — откроется GitHub, права repo и workflow уже отмечены.")
                        StepRow(number: 2, text: "Внизу страницы нажмите «Generate token» и скопируйте токен (он показывается один раз).")
                        StepRow(number: 3, text: "Вставьте токен выше, укажите репозиторий и нажмите «Проверить и подключить».")

                        if let tokenURL = tokenURL {
                            Link(destination: tokenURL) {
                                PillButton(title: "Создать токен на GitHub", icon: "key.fill", filled: false)
                            }
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, 20)

                SectionLabel("Важно знать")
                Panel {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Если репозитория нет, приложение создаст приватный репозиторий с этим именем (только в вашем аккаунте).")
                        Text("Токен хранится на этом устройстве в Keychain и отправляется только на api.github.com.")
                        Text("Архивы остаются в папке inbox/ репозитория — не кладите в них пароли и ключи.")
                        Text("Сборка идёт на macOS-серверах GitHub. В приватных репозиториях такие минуты расходуют лимит бесплатного тарифа с множителем (по правилам GitHub), в публичных они бесплатны.")
                    }
                    .font(.system(size: 13))
                    .foregroundColor(Theme.inkSoft)
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, 20)
            }
            .padding(.bottom, 40)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(ScreenBackground().ignoresSafeArea())
    }

    private func repoRow(_ connection: RepoConnection) -> some View {
        let active = model.activeID == connection.id && !model.isAddingNew
        return HStack(spacing: 12) {
            Image(systemName: "shippingbox.fill")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(Theme.accent)
                .frame(width: 36, height: 36)
                .background(Theme.accent.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(connection.repo)
                    .font(.mono(14, .medium))
                    .foregroundColor(Theme.ink)
                    .lineLimit(1)
                Text(connection.isConfigured ? "Подключён" : "Нужно подключить")
                    .font(.system(size: 12))
                    .foregroundColor(connection.isConfigured ? Theme.inkSoft : Theme.danger)
            }
            Spacer(minLength: 8)
            if active {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(Theme.accent)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }

    private func iconCell(_ option: AppIconOption) -> some View {
        let selected = icons.currentID == option.id
        return Button {
            Task { await icons.select(option) }
        } label: {
            VStack(spacing: 8) {
                Image(option.preview)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .stroke(Theme.accent, lineWidth: selected ? 3 : 0)
                            .padding(-3)
                    )
                    .shadow(color: Color.black.opacity(0.12), radius: 5, x: 0, y: 2)

                HStack(spacing: 4) {
                    if selected {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(Theme.accent)
                    }
                    Text(option.title)
                        .foregroundColor(selected ? Theme.ink : Theme.inkSoft)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                .font(.rounded(11, .semibold))
            }
        }
        .buttonStyle(.plain)
    }
}

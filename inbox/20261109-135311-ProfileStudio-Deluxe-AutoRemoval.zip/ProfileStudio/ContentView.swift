import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var displayName = "My Configuration"
    @State private var identifier = "com.example.profile"
    @State private var organization = ""
    @State private var descriptionText = "Created with Profile Studio"
    @State private var profileUUID = UUID().uuidString
    @State private var removalDisallowed = false
    @State private var removalMode = "never"
    @State private var removalDurationValue = "1"
    @State private var removalDurationUnit = "days"
    @State private var removalDate = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
    @State private var payloads: [ProfilePayload] = []

    @State private var selectedKind: PayloadKind?
    @State private var editingPayload: ProfilePayload?
    @State private var showingImporter = false
    @State private var showingPreview = false
    @State private var showingExporter = false
    @State private var showingResetConfirmation = false
    @State private var exportDocument = MobileConfigDocument(data: Data())
    @State private var exportName = "Configuration"
    @State private var errorMessage: String?

    private let accent = Color.indigo

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 18) {
                        heroCard
                        summaryCards
                        profileDetailsCard
                        automaticRemovalCard
                        payloadsCard
                        quickAddCard
                        exportCard
                        safetyNote
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("Profile Studio")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showingImporter = true
                    } label: {
                        Image(systemName: "square.and.arrow.down")
                    }
                    .accessibilityLabel("Import profile")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button {
                            profileUUID = UUID().uuidString
                        } label: {
                            Label("Generate profile UUID", systemImage: "arrow.clockwise")
                        }
                        Button {
                            showingResetConfirmation = true
                        } label: {
                            Label("New profile", systemImage: "doc.badge.plus")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                    .accessibilityLabel("More actions")
                }
            }
            .sheet(item: $selectedKind) { kind in
                PayloadEditorView(kind: kind, existing: nil) { payload in
                    payloads.append(payload)
                }
            }
            .sheet(item: $editingPayload) { payload in
                PayloadEditorView(kind: payload.kind, existing: payload) { updated in
                    if let index = payloads.firstIndex(where: { $0.id == payload.id }) {
                        payloads[index] = updated
                    }
                }
            }
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [MobileConfigDocument.mobileConfigType, .xml, .data],
                allowsMultipleSelection: false
            ) { result in
                importProfile(result)
            }
            .sheet(isPresented: $showingPreview) {
                ProfilePreviewView(data: exportDocument.data)
            }
            .fileExporter(
                isPresented: $showingExporter,
                document: exportDocument,
                contentType: MobileConfigDocument.mobileConfigType,
                defaultFilename: exportName
            ) { result in
                if case .failure(let error) = result {
                    errorMessage = error.localizedDescription
                }
            }
            .confirmationDialog(
                "Start a new profile?",
                isPresented: $showingResetConfirmation,
                titleVisibility: .visible
            ) {
                Button("Create new profile", role: .destructive) { resetProfile() }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("The current unsaved profile will be cleared.")
            }
            .alert("Profile Studio", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "Something went wrong.")
            }
        }
        .tint(accent)
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 22, weight: .semibold))
                    .frame(width: 48, height: 48)
                    .background(.white.opacity(0.16), in: RoundedRectangle(cornerRadius: 15))
                Spacer()
                Label("MOBILECONFIG", systemImage: "checkmark.seal.fill")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(1)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(.white.opacity(0.15), in: Capsule())
            }

            VStack(alignment: .leading, spacing: 5) {
                Text("Configuration profile")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                Text("Build, inspect and export Apple device profiles.")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.82))
            }

            HStack(spacing: 8) {
                Label("\(payloads.count) payloads", systemImage: "square.stack.3d.up")
                Circle().fill(.white.opacity(0.6)).frame(width: 3, height: 3)
                Label(payloads.isEmpty ? "Draft" : "Ready to review", systemImage: payloads.isEmpty ? "pencil" : "checkmark.circle")
            }
            .font(.caption.weight(.medium))
            .foregroundStyle(.white.opacity(0.9))
        }
        .foregroundStyle(.white)
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(
                colors: [Color(red: 0.24, green: 0.27, blue: 0.72), Color(red: 0.34, green: 0.42, blue: 0.92), Color(red: 0.18, green: 0.62, blue: 0.78)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 26, style: .continuous)
        )
        .shadow(color: accent.opacity(0.18), radius: 16, x: 0, y: 8)
    }

    private var summaryCards: some View {
        HStack(spacing: 10) {
            summaryTile(value: "\(payloads.count)", title: "Payloads", icon: "square.stack.3d.up.fill", color: .indigo)
            summaryTile(value: "\(Set(payloads.map(\.kind)).count)", title: "Types", icon: "square.grid.2x2.fill", color: .teal)
            summaryTile(value: payloads.contains(where: { $0.kind == .other }) ? "Yes" : "No", title: "Imported data", icon: "arrow.down.doc.fill", color: .orange)
        }
    }

    private func summaryTile(value: String, title: String, icon: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(color)
            Text(value)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .contentTransition(.numericText())
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
    }

    private var profileDetailsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            cardHeading("Profile details", subtitle: "Information shown during installation", icon: "doc.text")

            VStack(spacing: 12) {
                labeledField("Display name", placeholder: "My Configuration", text: $displayName)
                Divider()
                labeledField("Identifier", placeholder: "com.example.profile", text: $identifier, capitalization: .never)
                HStack {
                    Text("Unique ID")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Text(profileUUID.uppercased())
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    Button {
                        profileUUID = UUID().uuidString
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.caption.weight(.semibold))
                    }
                    .buttonStyle(.borderless)
                    .accessibilityLabel("Regenerate profile UUID")
                }
                Divider()
                labeledField("Organization", placeholder: "Optional", text: $organization)
                Divider()
                VStack(alignment: .leading, spacing: 5) {
                    Text("Description")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                    TextField("Describe what this profile does", text: $descriptionText, axis: .vertical)
                        .lineLimit(2...3)
                }
                Toggle(isOn: $removalDisallowed) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Prevent profile removal")
                            .font(.subheadline.weight(.medium))
                        Text("Affects whether the installed profile can be removed.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(.indigo)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private func labeledField(
        _ title: String,
        placeholder: String,
        text: Binding<String>,
        capitalization: TextInputAutocapitalization = .sentences
    ) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.caption.weight(.medium))
                .foregroundStyle(.secondary)
            TextField(placeholder, text: text)
                .textInputAutocapitalization(capitalization)
                .autocorrectionDisabled()
        }
    }

    private var automaticRemovalCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            cardHeading("Automatic removal", subtitle: "Set when iOS should remove this profile", icon: "timer")

            Picker("Removal schedule", selection: $removalMode) {
                Text("Never").tag("never")
                Text("After a duration").tag("duration")
                Text("At a date and time").tag("date")
            }
            .pickerStyle(.menu)

            if removalMode == "duration" {
                HStack(spacing: 10) {
                    TextField("Amount", text: $removalDurationValue)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .frame(maxWidth: 100)
                    Picker("Unit", selection: $removalDurationUnit) {
                        Text("Seconds").tag("seconds")
                        Text("Minutes").tag("minutes")
                        Text("Hours").tag("hours")
                        Text("Days").tag("days")
                    }
                    .pickerStyle(.segmented)
                }
                Text("The countdown is stored in the profile and starts when iOS installs it.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else if removalMode == "date" {
                DatePicker("Remove on", selection: $removalDate, in: Date()..., displayedComponents: [.date, .hourAndMinute])
                    .datePickerStyle(.compact)
                Text("iOS will remove the profile at the selected date and time.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                Text("The profile will not have an automatic removal date.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private var removalDurationSeconds: Double? {
        guard removalMode == "duration",
              let amount = Double(removalDurationValue),
              amount > 0, amount.isFinite else { return nil }
        let multiplier: Double = removalDurationUnit == "seconds" ? 1 :
            (removalDurationUnit == "minutes" ? 60 :
            (removalDurationUnit == "hours" ? 3600 : 86400))
        return amount * multiplier
    }

    private var payloadsCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack(alignment: .center) {
                cardHeading("Payloads", subtitle: "Settings included in this profile", icon: "square.stack.3d.up")
                Spacer()
                Text("\(payloads.count)/20")
                    .font(.caption.monospacedDigit().weight(.semibold))
                    .foregroundStyle(.secondary)
            }

            if payloads.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tray")
                        .font(.system(size: 30))
                        .foregroundStyle(.tertiary)
                    Text("Your profile is empty")
                        .font(.headline)
                    Text("Add a setting below or import an existing configuration profile.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: 250)
                    Button {
                        selectedKind = .wifi
                    } label: {
                        Label("Add first payload", systemImage: "plus")
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.top, 3)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 22)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(payloads.enumerated()), id: \.element.id) { index, payload in
                        payloadRow(payload, index: index)
                        if index != payloads.count - 1 {
                            Divider().padding(.leading, 56)
                        }
                    }
                }
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private func payloadRow(_ payload: ProfilePayload, index: Int) -> some View {
        HStack(spacing: 11) {
            Image(systemName: payload.kind.symbol)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(payload.kind == .other ? .orange : .indigo)
                .frame(width: 42, height: 42)
                .background((payload.kind == .other ? Color.orange : Color.indigo).opacity(0.11), in: RoundedRectangle(cornerRadius: 13))

            Button {
                if payload.kind != .other { editingPayload = payload }
            } label: {
                VStack(alignment: .leading, spacing: 3) {
                    Text(payload.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                    Text(payload.subtitle.isEmpty ? payload.kind.shortName : payload.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(payload.kind == .other)

            Menu {
                if payload.kind != .other {
                    Button {
                        editingPayload = payload
                    } label: {
                        Label("Edit", systemImage: "pencil")
                    }
                }
                Button {
                    duplicatePayload(payload)
                } label: {
                    Label("Duplicate", systemImage: "plus.square.on.square")
                }
                Button(role: .destructive) {
                    withAnimation { payloads.removeAll { $0.id == payload.id } }
                } label: {
                    Label("Delete", systemImage: "trash")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.headline)
                    .foregroundStyle(.secondary)
                    .frame(width: 32, height: 40)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("Actions for \(payload.title)")
        }
        .padding(.vertical, 7)
    }

    private var quickAddCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            cardHeading("Quick add", subtitle: "Choose a configuration type", icon: "plus.circle")
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(PayloadKind.allCases.filter { $0 != .other }) { kind in
                    Button {
                        selectedKind = kind
                    } label: {
                        HStack(spacing: 9) {
                            Image(systemName: kind.symbol)
                                .font(.system(size: 16, weight: .semibold))
                                .frame(width: 30, height: 30)
                                .background(Color.indigo.opacity(0.1), in: RoundedRectangle(cornerRadius: 9))
                            VStack(alignment: .leading, spacing: 2) {
                                Text(kind.shortName)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                Text("Add setting")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "plus")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.indigo)
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(.tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                    .disabled(payloads.count >= 20)
                }
            }
            Button {
                showingImporter = true
            } label: {
                Label("Import an existing profile", systemImage: "square.and.arrow.down")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
                    .background(Color.indigo.opacity(0.09), in: RoundedRectangle(cornerRadius: 13))
            }
            .buttonStyle(.plain)
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private var exportCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            cardHeading("Review & export", subtitle: "Check the profile before saving it", icon: "square.and.arrow.up")
            HStack(spacing: 10) {
                Button {
                    makePreview()
                } label: {
                    Label("Preview", systemImage: "doc.text.magnifyingglass")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                }
                .buttonStyle(.bordered)
                .disabled(!canExport)

                Button {
                    exportProfile()
                } label: {
                    Label("Export", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                }
                .buttonStyle(.borderedProminent)
                .disabled(!canExport)
            }
            HStack(spacing: 6) {
                Image(systemName: canExport ? "checkmark.circle.fill" : "info.circle")
                    .foregroundStyle(canExport ? .green : .secondary)
                Text(validationMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private var safetyNote: some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "exclamationmark.shield.fill")
                .foregroundStyle(.orange)
            Text("Configuration profiles can change device settings. Review every payload before installing or sharing the exported file. Credentials such as Wi-Fi and CalDAV passwords are included in the file when provided.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 4)
    }

    private func cardHeading(_ title: String, subtitle: String, icon: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.indigo)
                .frame(width: 34, height: 34)
                .background(Color.indigo.opacity(0.1), in: RoundedRectangle(cornerRadius: 11))
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.headline)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private var canExport: Bool {
        !displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !identifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !payloads.isEmpty &&
        (removalMode != "duration" || removalDurationSeconds != nil)
    }

    private var validationMessage: String {
        if displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "Enter a profile display name."
        }
        if identifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "Enter a profile identifier."
        }
        if payloads.isEmpty {
            return "Add at least one payload to enable export."
        }
        return "Profile is ready to preview and export."
    }

    private func makePreview() {
        do {
            let data = try ProfileBuilder.make(
                displayName: displayName,
                identifier: identifier,
                organization: organization,
                description: descriptionText,
                payloads: payloads,
                profileUUID: profileUUID,
                removalDisallowed: removalDisallowed,
                durationUntilRemoval: removalMode == "duration" ? removalDurationSeconds : nil,
                removalDate: removalMode == "date" ? removalDate : nil
            )
            exportDocument = MobileConfigDocument(data: data)
            showingPreview = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func exportProfile() {
        do {
            let data = try ProfileBuilder.make(
                displayName: displayName,
                identifier: identifier,
                organization: organization,
                description: descriptionText,
                payloads: payloads,
                profileUUID: profileUUID,
                removalDisallowed: removalDisallowed,
                durationUntilRemoval: removalMode == "duration" ? removalDurationSeconds : nil,
                removalDate: removalMode == "date" ? removalDate : nil
            )
            exportDocument = MobileConfigDocument(data: data)
            exportName = safeFilename(displayName)
            showingExporter = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func importProfile(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else { return }
            let accessed = url.startAccessingSecurityScopedResource()
            defer { if accessed { url.stopAccessingSecurityScopedResource() } }
            let data = try Data(contentsOf: url)
            let imported = try ProfileImporter.read(data)
            displayName = imported.displayName
            identifier = imported.identifier
            organization = imported.organization
            descriptionText = imported.description
            profileUUID = imported.profileUUID
            payloads = imported.payloads
            removalDisallowed = imported.removalDisallowed
        } catch {
            errorMessage = "Import failed: \(error.localizedDescription)"
        }
    }

    private func duplicatePayload(_ payload: ProfilePayload) {
        var raw = payload.rawPayload
        let newID = UUID()
        if raw != nil {
            raw?["PayloadUUID"] = newID.uuidString
            raw?["PayloadIdentifier"] = "com.example.profile.payload.\(newID.uuidString.lowercased())"
            raw?["PayloadDisplayName"] = payload.title + " Copy"
        }
        let copy = ProfilePayload(
            id: newID,
            kind: payload.kind,
            title: payload.title + " Copy",
            fields: payload.fields,
            rawPayload: raw
        )
        withAnimation { payloads.append(copy) }
    }

    private func resetProfile() {
        displayName = "My Configuration"
        identifier = "com.example.profile"
        organization = ""
        descriptionText = "Created with Profile Studio"
        profileUUID = UUID().uuidString
        removalDisallowed = false
        payloads = []
    }

    private func safeFilename(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        let cleaned = value.replacingOccurrences(of: " ", with: "-")
            .unicodeScalars.filter { allowed.contains($0) }
        return String(String.UnicodeScalarView(cleaned)).isEmpty
            ? "Configuration" : String(String.UnicodeScalarView(cleaned))
    }
}

enum PayloadKind: String, CaseIterable, Identifiable, Hashable {
    case wifi, webClip, dns, httpProxy, caldav, other

    var id: String { rawValue }
    var title: String {
        switch self {
        case .wifi: return "Wi-Fi Network"
        case .webClip: return "Web Clip"
        case .dns: return "DNS Settings"
        case .httpProxy: return "HTTP Proxy"
        case .caldav: return "Calendar (CalDAV)"
        case .other: return "Other Payload"
        }
    }
    var shortName: String {
        switch self {
        case .wifi: return "Wi-Fi"
        case .webClip: return "Web Clip"
        case .dns: return "DNS"
        case .httpProxy: return "Proxy"
        case .caldav: return "CalDAV"
        case .other: return "Other"
        }
    }
    var symbol: String {
        switch self {
        case .wifi: return "wifi"
        case .webClip: return "safari"
        case .dns: return "network"
        case .httpProxy: return "server.rack"
        case .caldav: return "calendar"
        case .other: return "doc.text"
        }
    }
}

struct ProfilePayload: Identifiable {
    let id: UUID
    let kind: PayloadKind
    let title: String
    let fields: [String: String]
    var rawPayload: [String: Any]? = nil

    var subtitle: String {
        switch kind {
        case .wifi: return fields["SSID"] ?? ""
        case .webClip: return fields["URL"] ?? ""
        case .dns: return fields["Server URL"] ?? fields["Server name"] ?? ""
        case .httpProxy: return fields["Server"] ?? ""
        case .caldav: return fields["Host"] ?? ""
        case .other: return (rawPayload?["PayloadType"] as? String) ?? "Unrecognized payload — preserved"
        }
    }
}

struct PayloadEditorView: View {
    let kind: PayloadKind
    let existing: ProfilePayload?
    let onSave: (ProfilePayload) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var fields: [String: String] = [:]
    @State private var security = "WPA2"
    @State private var dnsProtocol = "HTTPS"
    @State private var autoJoin = true
    @State private var fullScreen = false
    @State private var proxyPort = "8080"
    @State private var calendarPort = "443"
    @State private var calendarSSL = true
    @State private var errorText: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Payload display name", text: $title)
                } header: {
                    Text("General")
                }

                switch kind {
                case .wifi:
                    Section {
                        TextField("Network name (SSID)", text: binding("SSID"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        SecureField("Wi-Fi password", text: binding("Password"))
                        Picker("Security", selection: $security) {
                            Text("WPA2").tag("WPA2")
                            Text("WPA3").tag("WPA3")
                            Text("WEP").tag("WEP")
                            Text("None").tag("None")
                        }
                        Toggle("Auto-join", isOn: $autoJoin)
                    } header: {
                        Text("Wi-Fi configuration")
                    } footer: {
                        Text("The password is stored inside the exported profile. Only share the file with people you trust.")
                    }
                case .webClip:
                    Section {
                        TextField("Website title", text: binding("Label"))
                        TextField("https://example.com", text: binding("URL"))
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        Toggle("Open in full screen", isOn: $fullScreen)
                    } header: {
                        Text("Home Screen shortcut")
                    } footer: {
                        Text("Adds a website shortcut to the Home Screen when the profile is installed.")
                    }
                case .dns:
                    Section {
                        Picker("Protocol", selection: $dnsProtocol) {
                            Text("DNS over HTTPS").tag("HTTPS")
                            Text("DNS over TLS").tag("TLS")
                        }
                        if dnsProtocol == "HTTPS" {
                            TextField("Server URL template", text: binding("Server URL"))
                                .keyboardType(.URL)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        } else {
                            TextField("DNS server IP address(es), comma-separated", text: binding("Server addresses"))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                            TextField("TLS server name", text: binding("Server name"))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        }
                    } header: {
                        Text("Encrypted DNS")
                    } footer: {
                        Text("Use a DNS endpoint provided by a trusted network administrator. The endpoint may affect domain-name lookups on the device.")
                    }
                case .httpProxy:
                    Section {
                        TextField("Proxy server hostname or IP", text: binding("Server"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        TextField("Port", text: $proxyPort)
                            .keyboardType(.numberPad)
                        TextField("Exceptions (comma-separated)", text: binding("Exceptions"))
                    } header: {
                        Text("HTTP proxy")
                    } footer: {
                        Text("Global HTTP Proxy is intended for managed or supervised devices. Verify the server with your network administrator.")
                    }
                case .caldav:
                    Section {
                        TextField("CalDAV server hostname", text: binding("Host"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        TextField("Port", text: $calendarPort)
                            .keyboardType(.numberPad)
                        TextField("Username", text: binding("Username"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        SecureField("Password (optional)", text: binding("Password"))
                        TextField("Principal URL (optional)", text: binding("Principal URL"))
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        Toggle("Use SSL", isOn: $calendarSSL)
                    } header: {
                        Text("CalDAV account")
                    } footer: {
                        Text("Only add an account for a CalDAV server you trust. Account credentials are stored in the exported profile.")
                    }
                case .other:
                    Text("This payload is preserved as imported and cannot be edited in this version.")
                }
            }
            .navigationTitle(existing == nil ? "Add \(kind.shortName)" : "Edit \(kind.shortName)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(existing == nil ? "Add" : "Save") { save() }
                        .disabled(!isValid)
                }
            }
            .alert("Check the fields", isPresented: Binding(
                get: { errorText != nil },
                set: { if !$0 { errorText = nil } }
            )) {
                Button("OK", role: .cancel) { errorText = nil }
            } message: {
                Text(errorText ?? "")
            }
            .onAppear {
                if let existing {
                    title = existing.title
                    fields = existing.fields
                    security = existing.fields["Security"] ?? "WPA2"
                    dnsProtocol = existing.fields["Protocol"] ?? "HTTPS"
                    autoJoin = existing.fields["AutoJoin"] != "false"
                    fullScreen = existing.fields["FullScreen"] == "true"
                    proxyPort = existing.fields["Port"] ?? "8080"
                    calendarPort = existing.fields["Port"] ?? "443"
                    calendarSSL = existing.fields["SSL"] != "false"
                } else if title.isEmpty {
                    title = kind.title
                }
            }
        }
    }

    private func binding(_ key: String) -> Binding<String> {
        Binding(
            get: { fields[key] ?? "" },
            set: { fields[key] = $0 }
        )
    }

    private var isValid: Bool {
        switch kind {
        case .wifi:
            return !(fields["SSID"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .webClip:
            guard let value = fields["URL"], let url = URL(string: value) else { return false }
            return ["http", "https"].contains(url.scheme?.lowercased() ?? "") && url.host != nil
        case .httpProxy:
            guard let port = Int(proxyPort), (1...65535).contains(port) else { return false }
            return !(fields["Server"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .caldav:
            guard let port = Int(calendarPort), (1...65535).contains(port) else { return false }
            return !(fields["Host"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty &&
                !(fields["Username"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .other:
            return false
        case .dns:
            if dnsProtocol == "HTTPS" {
                guard let value = fields["Server URL"], let url = URL(string: value) else { return false }
                return url.scheme == "https" && url.host != nil
            }
            return !(fields["Server addresses"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty &&
                !(fields["Server name"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        }
    }

    private func save() {
        guard isValid else {
            errorText = "Enter the required values and check the URL format."
            return
        }
        var values = fields
        if kind == .wifi {
            values["Security"] = security
            values["AutoJoin"] = autoJoin ? "true" : "false"
        } else if kind == .webClip {
            values["FullScreen"] = fullScreen ? "true" : "false"
        } else if kind == .dns {
            values["Protocol"] = dnsProtocol
        } else if kind == .httpProxy {
            values["Port"] = proxyPort
        } else if kind == .caldav {
            values["Port"] = calendarPort
            values["SSL"] = calendarSSL ? "true" : "false"
        }
        onSave(ProfilePayload(
            id: existing?.id ?? UUID(),
            kind: kind,
            title: title.isEmpty ? kind.title : title,
            fields: values,
            rawPayload: nil
        ))
        dismiss()
    }
}

enum ProfileBuilder {
    static func make(
        displayName: String,
        identifier: String,
        organization: String,
        description: String,
        payloads: [ProfilePayload],
        profileUUID: String = UUID().uuidString,
        removalDisallowed: Bool = false,
        durationUntilRemoval: Double? = nil,
        removalDate: Date? = nil
    ) throws -> Data {
        let content = payloads.map(makePayload)
        var profile: [String: Any] = [
            "PayloadContent": content,
            "PayloadDescription": description,
            "PayloadDisplayName": displayName,
            "PayloadIdentifier": identifier,
            "PayloadRemovalDisallowed": removalDisallowed,
            "PayloadType": "Configuration",
            "PayloadUUID": profileUUID,
            "PayloadVersion": 1
        ]
        if let duration = durationUntilRemoval, duration > 0, duration.isFinite {
            profile["DurationUntilRemoval"] = duration
        }
        if let date = removalDate {
            profile["RemovalDate"] = date
        }
        if !organization.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            profile["PayloadOrganization"] = organization
        }
        return try PropertyListSerialization.data(
            fromPropertyList: profile,
            format: .xml,
            options: 0
        )
    }

    private static func makePayload(_ item: ProfilePayload) -> [String: Any] {
        if let raw = item.rawPayload { return raw }
        let payloadType: String
        var settings: [String: Any] = [:]

        switch item.kind {
        case .wifi:
            payloadType = "com.apple.wifi.managed"
            settings["SSID_STR"] = item.fields["SSID"] ?? ""
            settings["AutoJoin"] = item.fields["AutoJoin"] == "true"
            settings["EncryptionType"] = item.fields["Security"] ?? "WPA2"
            if let password = item.fields["Password"], !password.isEmpty,
               (item.fields["Security"] ?? "WPA2") != "None" {
                settings["Password"] = password
            }
        case .webClip:
            payloadType = "com.apple.webClip.managed"
            settings["Label"] = item.fields["Label"] ?? item.title
            settings["URL"] = item.fields["URL"] ?? ""
            settings["IsRemovable"] = true
            settings["FullScreen"] = item.fields["FullScreen"] == "true"
        case .httpProxy:
            payloadType = "com.apple.proxy.http.global"
            settings["ProxyType"] = "Manual"
            settings["ProxyServer"] = item.fields["Server"] ?? ""
            settings["ProxyServerPort"] = Int(item.fields["Port"] ?? "8080") ?? 8080
            let exceptions = (item.fields["Exceptions"] ?? "")
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
            if !exceptions.isEmpty { settings["ProxyExceptionsList"] = exceptions }
        case .caldav:
            payloadType = "com.apple.caldav.account"
            settings["CalDAVHostName"] = item.fields["Host"] ?? ""
            settings["CalDAVPort"] = Int(item.fields["Port"] ?? "443") ?? 443
            settings["CalDAVUsername"] = item.fields["Username"] ?? ""
            settings["CalDAVUseSSL"] = item.fields["SSL"] != "false"
            settings["CalDAVAccountDescription"] = item.title
            if let password = item.fields["Password"], !password.isEmpty {
                settings["CalDAVPassword"] = password
            }
            if let principal = item.fields["Principal URL"], !principal.isEmpty {
                settings["CalDAVPrincipalURL"] = principal
            }
        case .other:
            return item.rawPayload ?? [:]
        case .dns:
            payloadType = "com.apple.dnsSettings.managed"
            let proto = item.fields["Protocol"] ?? "HTTPS"
            var dns: [String: Any] = ["DNSProtocol": proto]
            if proto == "TLS" {
                let addresses = (item.fields["Server addresses"] ?? "")
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                dns["ServerAddresses"] = addresses
                dns["ServerName"] = item.fields["Server name"] ?? ""
            } else {
                dns["ServerURL"] = item.fields["Server URL"] ?? ""
            }
            settings["DNSSettings"] = dns
        }

        settings["PayloadDisplayName"] = item.title
        settings["PayloadIdentifier"] = "com.example.profile.payload.\(item.id.uuidString.lowercased())"
        settings["PayloadType"] = payloadType
        settings["PayloadUUID"] = item.id.uuidString
        settings["PayloadVersion"] = 1
        return settings
    }
}

struct ImportedProfile {
    let displayName: String
    let identifier: String
    let organization: String
    let description: String
    let profileUUID: String
    let removalDisallowed: Bool
    let durationUntilRemoval: Double?
    let removalDate: Date?
    let payloads: [ProfilePayload]
}

enum ProfileImporter {
    static func read(_ data: Data) throws -> ImportedProfile {
        let plistData: Data
        do {
            _ = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
            plistData = data
        } catch {
            plistData = try decodeCMS(data)
        }
        let object = try PropertyListSerialization.propertyList(from: plistData, options: [], format: nil)
        guard let profile = object as? [String: Any],
              (profile["PayloadType"] as? String) == "Configuration" else {
            throw NSError(domain: "ProfileStudio", code: 1, userInfo: [NSLocalizedDescriptionKey: "The selected file is not an Apple configuration profile."])
        }
        let content = profile["PayloadContent"] as? [[String: Any]] ?? []
        return ImportedProfile(
            displayName: profile["PayloadDisplayName"] as? String ?? "Imported Profile",
            identifier: profile["PayloadIdentifier"] as? String ?? "com.example.imported",
            organization: profile["PayloadOrganization"] as? String ?? "",
            description: profile["PayloadDescription"] as? String ?? "",
            profileUUID: profile["PayloadUUID"] as? String ?? UUID().uuidString,
            removalDisallowed: profile["PayloadRemovalDisallowed"] as? Bool ?? false,
            durationUntilRemoval: (profile["DurationUntilRemoval"] as? NSNumber)?.doubleValue,
            removalDate: profile["RemovalDate"] as? Date,
            payloads: content.map(parsePayload)
        )
    }

    private static func decodeCMS(_ data: Data) throws -> Data {
        // CMSDecoder is not available in the iOS SDK. Signed .mobileconfig files
        // use a CMS/PKCS#7 envelope, so this iOS-only build cannot safely unwrap
        // or verify them. Unsigned XML and binary property-list profiles are
        // supported. Do not attempt to treat signed bytes as a property list.
        throw NSError(
            domain: "ProfileStudio",
            code: 2,
            userInfo: [NSLocalizedDescriptionKey: "This profile is CMS-signed. This version can import unsigned XML or binary .mobileconfig files, but cannot unwrap signed profiles on iOS. Export an unsigned copy from the profile source, then import it here."]
        )
    }

    private static func parsePayload(_ raw: [String: Any]) -> ProfilePayload {
        let type = raw["PayloadType"] as? String ?? "unknown"
        let title = raw["PayloadDisplayName"] as? String ?? type
        let uuid = UUID(uuidString: raw["PayloadUUID"] as? String ?? "") ?? UUID()
        var fields: [String: String] = [:]
        let kind: PayloadKind

        switch type {
        case "com.apple.wifi.managed":
            kind = .wifi
            fields["SSID"] = raw["SSID_STR"] as? String ?? ""
            fields["Password"] = raw["Password"] as? String ?? ""
            fields["Security"] = raw["EncryptionType"] as? String ?? "WPA2"
            fields["AutoJoin"] = (raw["AutoJoin"] as? Bool ?? true) ? "true" : "false"
        case "com.apple.webClip.managed":
            kind = .webClip
            fields["Label"] = raw["Label"] as? String ?? title
            fields["URL"] = raw["URL"] as? String ?? ""
            fields["FullScreen"] = (raw["FullScreen"] as? Bool ?? false) ? "true" : "false"
        case "com.apple.dnsSettings.managed":
            kind = .dns
            let dns = raw["DNSSettings"] as? [String: Any] ?? [:]
            let proto = dns["DNSProtocol"] as? String ?? "HTTPS"
            fields["Protocol"] = proto
            fields["Server URL"] = dns["ServerURL"] as? String ?? ""
            fields["Server name"] = dns["ServerName"] as? String ?? ""
            fields["Server addresses"] = (dns["ServerAddresses"] as? [String] ?? []).joined(separator: ", ")
        case "com.apple.proxy.http.global":
            kind = .httpProxy
            fields["Server"] = raw["ProxyServer"] as? String ?? ""
            fields["Port"] = String(raw["ProxyServerPort"] as? Int ?? 8080)
            fields["Exceptions"] = (raw["ProxyExceptionsList"] as? [String] ?? []).joined(separator: ", ")
        case "com.apple.caldav.account":
            kind = .caldav
            fields["Host"] = raw["CalDAVHostName"] as? String ?? ""
            fields["Port"] = String(raw["CalDAVPort"] as? Int ?? 443)
            fields["Username"] = raw["CalDAVUsername"] as? String ?? ""
            fields["Password"] = raw["CalDAVPassword"] as? String ?? ""
            fields["SSL"] = (raw["CalDAVUseSSL"] as? Bool ?? true) ? "true" : "false"
            fields["Principal URL"] = raw["CalDAVPrincipalURL"] as? String ?? ""
        default:
            return ProfilePayload(id: uuid, kind: .other, title: title, fields: [:], rawPayload: raw)
        }
        return ProfilePayload(id: uuid, kind: kind, title: title, fields: fields)
    }
}

struct MobileConfigDocument: FileDocument {
    static var mobileConfigType: UTType { UTType(filenameExtension: "mobileconfig") ?? .data }
    static var readableContentTypes: [UTType] { [mobileConfigType] }
    let data: Data

    init(data: Data) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct ProfilePreviewView: View {
    let data: Data
    @Environment(\.dismiss) private var dismiss

    private var text: String {
        String(data: data, encoding: .utf8) ?? "Unable to display profile."
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text)
                    .font(.system(.footnote, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .navigationTitle("Profile Preview")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

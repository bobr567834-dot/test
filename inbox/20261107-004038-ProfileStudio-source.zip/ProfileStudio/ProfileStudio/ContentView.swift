import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var displayName = "My Configuration"
    @State private var identifier = "com.example.profile"
    @State private var organization = ""
    @State private var descriptionText = "Created with Profile Studio"
    @State private var payloads: [ProfilePayload] = []
    @State private var selectedKind: PayloadKind?
    @State private var showingPreview = false
    @State private var showingExporter = false
    @State private var exportDocument = MobileConfigDocument(data: Data())
    @State private var exportName = "Configuration"
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Profile name", text: $displayName)
                    TextField("Identifier", text: $identifier)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Organization (optional)", text: $organization)
                    TextField("Description", text: $descriptionText, axis: .vertical)
                        .lineLimit(2...4)
                } header: {
                    Text("Profile details")
                } footer: {
                    Text("These details appear in the iOS profile installation screen.")
                }

                Section {
                    if payloads.isEmpty {
                        ContentUnavailableView(
                            "No payloads yet",
                            systemImage: "doc.badge.plus",
                            description: Text("Add a Wi-Fi, Web Clip, or DNS payload.")
                        )
                    } else {
                        ForEach(payloads) { payload in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Image(systemName: payload.kind.symbol)
                                        .foregroundStyle(.tint)
                                    Text(payload.title)
                                        .font(.headline)
                                    Spacer()
                                    Text(payload.kind.shortName)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Text(payload.subtitle)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                        .onDelete { payloads.remove(atOffsets: $0) }
                    }
                } header: {
                    Text("Payloads")
                } footer: {
                    Text("Swipe left on a payload to remove it. One profile can contain multiple payloads.")
                }

                Section {
                    Menu {
                        ForEach(PayloadKind.allCases) { kind in
                            Button {
                                selectedKind = kind
                            } label: {
                                Label(kind.title, systemImage: kind.symbol)
                            }
                        }
                    } label: {
                        Label("Add payload", systemImage: "plus.circle.fill")
                    }
                    .disabled(payloads.count >= 20)
                } footer: {
                    Text("This starter version supports Wi-Fi, Web Clip, and DNS settings payloads.")
                }

                Section {
                    Button {
                        makePreview()
                    } label: {
                        Label("Preview mobileconfig", systemImage: "doc.text.magnifyingglass")
                    }
                    .disabled(!canExport)

                    Button {
                        exportProfile()
                    } label: {
                        Label("Export .mobileconfig", systemImage: "square.and.arrow.up")
                    }
                    .disabled(!canExport)
                } footer: {
                    Text("The exported file is an unsigned configuration profile. Review its contents before installing it.")
                }
            }
            .navigationTitle("Profile Studio")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    EditButton()
                }
            }
            .sheet(item: $selectedKind) { kind in
                PayloadEditorView(kind: kind) { payload in
                    payloads.append(payload)
                }
            }
            .sheet(isPresented: $showingPreview) {
                ProfilePreviewView(data: exportDocument.data)
            }
            .fileExporter(
                isPresented: $showingExporter,
                document: exportDocument,
                contentType: MobileConfigDocument.mobileConfigType,
                defaultFilename: exportName
            ) { result in
                if case .failure(let error) = result {
                    errorMessage = error.localizedDescription
                }
            }
            .alert("Unable to create profile", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "Unknown error")
            }
        }
    }

    private var canExport: Bool {
        !displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !identifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !payloads.isEmpty
    }

    private func makePreview() {
        do {
            let data = try ProfileBuilder.make(
                displayName: displayName,
                identifier: identifier,
                organization: organization,
                description: descriptionText,
                payloads: payloads
            )
            exportDocument = MobileConfigDocument(data: data)
            showingPreview = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func exportProfile() {
        do {
            let data = try ProfileBuilder.make(
                displayName: displayName,
                identifier: identifier,
                organization: organization,
                description: descriptionText,
                payloads: payloads
            )
            exportDocument = MobileConfigDocument(data: data)
            exportName = safeFilename(displayName)
            showingExporter = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func safeFilename(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        let cleaned = value.replacingOccurrences(of: " ", with: "-")
            .unicodeScalars.filter { allowed.contains($0) }
        return String(String.UnicodeScalarView(cleaned)).isEmpty
            ? "Configuration" : String(String.UnicodeScalarView(cleaned))
    }
}

enum PayloadKind: String, CaseIterable, Identifiable {
    case wifi, webClip, dns

    var id: String { rawValue }
    var title: String {
        switch self {
        case .wifi: return "Wi-Fi Network"
        case .webClip: return "Web Clip"
        case .dns: return "DNS Settings"
        }
    }
    var shortName: String {
        switch self {
        case .wifi: return "Wi-Fi"
        case .webClip: return "Web Clip"
        case .dns: return "DNS"
        }
    }
    var symbol: String {
        switch self {
        case .wifi: return "wifi"
        case .webClip: return "safari"
        case .dns: return "network"
        }
    }
}

struct ProfilePayload: Identifiable {
    let id: UUID
    let kind: PayloadKind
    let title: String
    let fields: [String: String]

    var subtitle: String {
        switch kind {
        case .wifi: return fields["SSID"] ?? ""
        case .webClip: return fields["URL"] ?? ""
        case .dns: return fields["Server URL"] ?? fields["Server name"] ?? ""
        }
    }
}

struct PayloadEditorView: View {
    let kind: PayloadKind
    let onSave: (ProfilePayload) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var fields: [String: String] = [:]
    @State private var security = "WPA2"
    @State private var dnsProtocol = "HTTPS"
    @State private var autoJoin = true
    @State private var fullScreen = false
    @State private var errorText: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Payload display name", text: $title)
                } header: {
                    Text("General")
                }

                switch kind {
                case .wifi:
                    Section {
                        TextField("Network name (SSID)", text: binding("SSID"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        SecureField("Wi-Fi password", text: binding("Password"))
                        Picker("Security", selection: $security) {
                            Text("WPA2").tag("WPA2")
                            Text("WPA3").tag("WPA3")
                            Text("WEP").tag("WEP")
                            Text("None").tag("None")
                        }
                        Toggle("Auto-join", isOn: $autoJoin)
                    } header: {
                        Text("Wi-Fi configuration")
                    } footer: {
                        Text("The password is stored inside the exported profile. Only share the file with people you trust.")
                    }
                case .webClip:
                    Section {
                        TextField("Website title", text: binding("Label"))
                        TextField("https://example.com", text: binding("URL"))
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        Toggle("Open in full screen", isOn: $fullScreen)
                    } header: {
                        Text("Home Screen shortcut")
                    } footer: {
                        Text("Adds a website shortcut to the Home Screen when the profile is installed.")
                    }
                case .dns:
                    Section {
                        Picker("Protocol", selection: $dnsProtocol) {
                            Text("DNS over HTTPS").tag("HTTPS")
                            Text("DNS over TLS").tag("TLS")
                        }
                        if dnsProtocol == "HTTPS" {
                            TextField("Server URL template", text: binding("Server URL"))
                                .keyboardType(.URL)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        } else {
                            TextField("DNS server IP address(es), comma-separated", text: binding("Server addresses"))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                            TextField("TLS server name", text: binding("Server name"))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        }
                    } header: {
                        Text("Encrypted DNS")
                    } footer: {
                        Text("Use a DNS endpoint provided by a trusted network administrator. The endpoint may affect domain-name lookups on the device.")
                    }
                }
            }
            .navigationTitle("Add \(kind.shortName)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") { save() }
                        .disabled(!isValid)
                }
            }
            .alert("Check the fields", isPresented: Binding(
                get: { errorText != nil },
                set: { if !$0 { errorText = nil } }
            )) {
                Button("OK", role: .cancel) { errorText = nil }
            } message: {
                Text(errorText ?? "")
            }
            .onAppear {
                if title.isEmpty { title = kind.title }
            }
        }
    }

    private func binding(_ key: String) -> Binding<String> {
        Binding(
            get: { fields[key] ?? "" },
            set: { fields[key] = $0 }
        )
    }

    private var isValid: Bool {
        switch kind {
        case .wifi:
            return !(fields["SSID"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .webClip:
            guard let value = fields["URL"], let url = URL(string: value) else { return false }
            return ["http", "https"].contains(url.scheme?.lowercased() ?? "") && url.host != nil
        case .dns:
            if dnsProtocol == "HTTPS" {
                guard let value = fields["Server URL"], let url = URL(string: value) else { return false }
                return url.scheme == "https" && url.host != nil
            }
            return !(fields["Server addresses"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty &&
                !(fields["Server name"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        }
    }

    private func save() {
        guard isValid else {
            errorText = "Enter the required values and check the URL format."
            return
        }
        var values = fields
        if kind == .wifi {
            values["Security"] = security
            values["AutoJoin"] = autoJoin ? "true" : "false"
        } else if kind == .webClip {
            values["FullScreen"] = fullScreen ? "true" : "false"
        } else if kind == .dns {
            values["Protocol"] = dnsProtocol
        }
        onSave(ProfilePayload(
            id: UUID(),
            kind: kind,
            title: title.isEmpty ? kind.title : title,
            fields: values
        ))
        dismiss()
    }
}

enum ProfileBuilder {
    static func make(
        displayName: String,
        identifier: String,
        organization: String,
        description: String,
        payloads: [ProfilePayload]
    ) throws -> Data {
        let content = payloads.map(makePayload)
        var profile: [String: Any] = [
            "PayloadContent": content,
            "PayloadDescription": description,
            "PayloadDisplayName": displayName,
            "PayloadIdentifier": identifier,
            "PayloadRemovalDisallowed": false,
            "PayloadType": "Configuration",
            "PayloadUUID": UUID().uuidString,
            "PayloadVersion": 1
        ]
        if !organization.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            profile["PayloadOrganization"] = organization
        }
        return try PropertyListSerialization.data(
            fromPropertyList: profile,
            format: .xml,
            options: 0
        )
    }

    private static func makePayload(_ item: ProfilePayload) -> [String: Any] {
        let payloadType: String
        var settings: [String: Any] = [:]

        switch item.kind {
        case .wifi:
            payloadType = "com.apple.wifi.managed"
            settings["SSID_STR"] = item.fields["SSID"] ?? ""
            settings["AutoJoin"] = item.fields["AutoJoin"] == "true"
            settings["EncryptionType"] = item.fields["Security"] ?? "WPA2"
            if let password = item.fields["Password"], !password.isEmpty,
               (item.fields["Security"] ?? "WPA2") != "None" {
                settings["Password"] = password
            }
        case .webClip:
            payloadType = "com.apple.webClip.managed"
            settings["Label"] = item.fields["Label"] ?? item.title
            settings["URL"] = item.fields["URL"] ?? ""
            settings["IsRemovable"] = true
            settings["FullScreen"] = item.fields["FullScreen"] == "true"
        case .dns:
            payloadType = "com.apple.dnsSettings.managed"
            let proto = item.fields["Protocol"] ?? "HTTPS"
            var dns: [String: Any] = ["DNSProtocol": proto]
            if proto == "TLS" {
                let addresses = (item.fields["Server addresses"] ?? "")
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                dns["ServerAddresses"] = addresses
                dns["ServerName"] = item.fields["Server name"] ?? ""
            } else {
                dns["ServerURL"] = item.fields["Server URL"] ?? ""
            }
            settings["DNSSettings"] = dns
        }

        settings["PayloadDisplayName"] = item.title
        settings["PayloadIdentifier"] = "com.example.profile.payload.\(item.id.uuidString.lowercased())"
        settings["PayloadType"] = payloadType
        settings["PayloadUUID"] = item.id.uuidString
        settings["PayloadVersion"] = 1
        return settings
    }
}

struct MobileConfigDocument: FileDocument {
    static var mobileConfigType: UTType { UTType(filenameExtension: "mobileconfig") ?? .data }
    static var readableContentTypes: [UTType] { [mobileConfigType] }
    let data: Data

    init(data: Data) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct ProfilePreviewView: View {
    let data: Data
    @Environment(\.dismiss) private var dismiss
    @State private var copied = false

    private var text: String {
        String(data: data, encoding: .utf8) ?? "Unable to display profile."
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text)
                    .font(.system(.footnote, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .navigationTitle("Profile Preview")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

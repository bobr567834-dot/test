# Profile Studio

A SwiftUI iOS app for creating Apple configuration profiles (`.mobileconfig`).

## Included payloads
- **Wi-Fi** — SSID, security mode, optional password, and auto-join.
- **Web Clip** — Home Screen website shortcut.
- **DNS Settings** — DNS over HTTPS or DNS over TLS endpoint.

The app generates an unsigned XML property list configuration profile and exports it with the iOS share/save sheet.

## Build the IPA with GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open **Actions** and run **Build iOS IPA**, or push to `main` / `master`.
4. Download the `ProfileStudio-unsigned-ipa` artifact from the workflow run.

The workflow intentionally:
- uses `runs-on: macos-15`;
- prints `xcodebuild -version` without selecting an Xcode version;
- installs XcodeGen with Homebrew and generates the `.xcodeproj` from `project.yml`;
- builds with `CODE_SIGNING_ALLOWED=NO` and `generic/platform=iOS`;
- packages `Payload/ProfileStudio.app` into `ProfileStudio.ipa`.

## Important
The IPA is **unsigned**. It is a build artifact, not an installable signed app by itself. To install it on a device, sign it with a valid development/distribution signing setup using your own Apple developer credentials.

Configuration profiles can change device settings. Review every generated profile before installing it. Wi-Fi passwords are included in the exported file when supplied; protect the file accordingly.

import Security
import SwiftUI
import AVFoundation

// MARK: - Keychain
enum Keychain {
    static let base: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                      kSecAttrAccount as String: "groq_api_key"]
    static func save(_ s: String) {
        SecItemDelete(base as CFDictionary)
        var a = base; a[kSecValueData as String] = Data(s.utf8)
        SecItemAdd(a as CFDictionary, nil)
    }
    static func load() -> String {
        var q = base; q[kSecReturnData as String] = true
        var r: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &r) == errSecSuccess,
              let d = r as? Data else { return "" }
        return String(decoding: d, as: UTF8.self)
    }
}

// MARK: - Groq client
struct Groq {
    let key: String
    let base = "https://api.groq.com/openai/v1"

    func request(_ path: String, method: String = "POST") -> URLRequest {
        var r = URLRequest(url: URL(string: base + path)!)
        r.httpMethod = method
        r.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        return r
    }

    func send(_ r: URLRequest) async throws -> Data {
        let (d, resp) = try await URLSession.shared.data(for: r)
        if let h = resp as? HTTPURLResponse, h.statusCode >= 400 {
            let msg = ((try? JSONSerialization.jsonObject(with: d)) as? [String: Any])
                .flatMap { $0["error"] as? [String: Any] }?["message"] as? String
            throw NSError(domain: "Groq", code: h.statusCode,
                          userInfo: [NSLocalizedDescriptionKey: msg ?? "HTTP \(h.statusCode)"])
        }
        return d
    }

    func models() async throws -> [String] {
        let d = try await send(request("/models", method: "GET"))
        let j = try JSONSerialization.jsonObject(with: d) as? [String: Any]
        return ((j?["data"] as? [[String: Any]]) ?? []).compactMap { $0["id"] as? String }.sorted()
    }

    func chat(model: String, messages: [[String: String]]) async throws -> String {
        var r = request("/chat/completions")
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        r.httpBody = try JSONSerialization.data(withJSONObject: ["model": model, "messages": messages])
        let j = try JSONSerialization.jsonObject(with: try await send(r)) as? [String: Any]
        let m = ((j?["choices"] as? [[String: Any]])?.first?["message"]) as? [String: Any]
        return (m?["content"] as? String) ?? ""
    }

    func speech(model: String, voice: String, text: String) async throws -> Data {
        var r = request("/audio/speech")
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        r.httpBody = try JSONSerialization.data(withJSONObject:
            ["model": model, "voice": voice, "input": text, "response_format": "wav"])
        return try await send(r)
    }

    func transcribe(model: String, file: URL) async throws -> String {
        let boundary = UUID().uuidString
        var r = request("/audio/transcriptions")
        r.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        func field(_ n: String, _ v: String) {
            body.append("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(n)\"\r\n\r\n\(v)\r\n".data(using: .utf8)!)
        }
        field("model", model)
        field("response_format", "text")
        body.append("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.m4a\"\r\nContent-Type: audio/m4a\r\n\r\n".data(using: .utf8)!)
        body.append(try Data(contentsOf: file))
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        r.httpBody = body
        return String(decoding: try await send(r), as: UTF8.self)
    }
}

// MARK: - App state
@MainActor final class Store: ObservableObject {
    @Published var key = Keychain.load() { didSet { Keychain.save(key) } }
    @Published var available: [String] = []
    var api: Groq { Groq(key: key) }
    func refresh() async { available = (try? await api.models()) ?? [] }
}

@main struct GroqToolsApp: App {
    @StateObject var store = Store()
    var body: some Scene {
        WindowGroup {
            TabView {
                ChatView().tabItem { Label("Чат", systemImage: "bubble.left.and.bubble.right") }
                SafeguardView().tabItem { Label("Модерация", systemImage: "checkmark.shield") }
                GuardView().tabItem { Label("Guard", systemImage: "lock.shield") }
                TTSView().tabItem { Label("Озвучка", systemImage: "speaker.wave.2") }
                STTView().tabItem { Label("Речь", systemImage: "mic") }
                SettingsView().tabItem { Label("Ключ", systemImage: "key") }
            }
            .environmentObject(store)
            .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Shared bits
struct ResultBox: View {
    let text: String, error: String?, busy: Bool
    var body: some View {
        if busy { ProgressView().frame(maxWidth: .infinity) }
        if let error { Text(error).foregroundStyle(.red) }
        if !text.isEmpty { Text(text).textSelection(.enabled) }
    }
}

// MARK: - Chat
struct ChatView: View {
    @EnvironmentObject var s: Store
    @State var model = "openai/gpt-oss-120b"
    @State var system = ""
    @State var input = ""
    @State var history: [[String: String]] = []
    @State var busy = false
    @State var error: String?
    let models = ["allam-2-7b", "openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"]

    var body: some View {
        NavigationStack {
            VStack {
                Picker("Модель", selection: $model) { ForEach(models, id: \.self) { Text($0) } }
                TextField("Системный промпт (необязательно)", text: $system).textFieldStyle(.roundedBorder).padding(.horizontal)
                ScrollView {
                    ForEach(Array(history.enumerated()), id: \.offset) { _, m in
                        Text(m["content"] ?? "").padding(10).textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: m["role"] == "user" ? .trailing : .leading)
                            .background(m["role"] == "user" ? Color.green.opacity(0.25) : Color.gray.opacity(0.2))
                            .clipShape(RoundedRectangle(cornerRadius: 12)).padding(.horizontal)
                    }
                    ResultBox(text: "", error: error, busy: busy).padding()
                }
                HStack {
                    TextField("Сообщение", text: $input, axis: .vertical).textFieldStyle(.roundedBorder)
                    Button { Task { await send() } } label: { Image(systemName: "arrow.up.circle.fill").font(.title) }
                        .disabled(input.isEmpty || busy)
                }.padding()
            }
            .navigationTitle("Чат")
            .toolbar { Button("Очистить") { history = [] } }
        }
    }

    func send() async {
        history.append(["role": "user", "content": input]); input = ""; busy = true; error = nil
        var msgs = history
        if !system.isEmpty { msgs.insert(["role": "system", "content": system], at: 0) }
        do { history.append(["role": "assistant", "content": try await s.api.chat(model: model, messages: msgs)]) }
        catch { self.error = error.localizedDescription }
        busy = false
    }
}

// MARK: - Safeguard
struct SafeguardView: View {
    @EnvironmentObject var s: Store
    @State var policy = "Классифицируй текст: VIOLATION, если он содержит угрозы, оскорбления или инструкции по причинению вреда; иначе SAFE. Кратко объясни причину."
    @State var content = ""
    @State var out = ""; @State var busy = false; @State var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("Политика") { TextEditor(text: $policy).frame(minHeight: 110) }
                Section("Проверяемый текст") { TextEditor(text: $content).frame(minHeight: 110) }
                Button("Проверить") {
                    Task {
                        busy = true; error = nil; out = ""
                        do { out = try await s.api.chat(model: "openai/gpt-oss-safeguard-20b",
                                messages: [["role": "system", "content": policy], ["role": "user", "content": content]]) }
                        catch { self.error = error.localizedDescription }
                        busy = false
                    }
                }.disabled(content.isEmpty || busy)
                Section("Результат") { ResultBox(text: out, error: error, busy: busy) }
            }.navigationTitle("Модерация")
        }
    }
}

// MARK: - Prompt Guard
struct GuardView: View {
    @EnvironmentObject var s: Store
    @State var model = "meta-llama/llama-prompt-guard-2-86m"
    @State var text = ""
    @State var out = ""; @State var busy = false; @State var error: String?
    var score: Double? { Double(out.trimmingCharacters(in: .whitespacesAndNewlines)) }
    var body: some View {
        NavigationStack {
            Form {
                Picker("Модель", selection: $model) {
                    Text("22m (быстрая)").tag("meta-llama/llama-prompt-guard-2-22m")
                    Text("86m (точнее)").tag("meta-llama/llama-prompt-guard-2-86m")
                }
                Section("Текст / промпт") { TextEditor(text: $text).frame(minHeight: 140) }
                Button("Проверить на инъекцию") {
                    Task {
                        busy = true; error = nil; out = ""
                        do { out = try await s.api.chat(model: model, messages: [["role": "user", "content": text]]) }
                        catch { self.error = error.localizedDescription }
                        busy = false
                    }
                }.disabled(text.isEmpty || busy)
                Section("Риск (0–1)") {
                    if let sc = score {
                        Text(String(format: "%.3f", sc)).font(.largeTitle.bold())
                            .foregroundStyle(sc > 0.5 ? .red : .green)
                        Text(sc > 0.5 ? "Похоже на prompt injection / jailbreak" : "Выглядит безопасно")
                    } else { ResultBox(text: out, error: error, busy: busy) }
                }
            }.navigationTitle("Prompt Guard")
        }
    }
}

// MARK: - TTS
struct TTSView: View {
    @EnvironmentObject var s: Store
    @State var model = "canopylabs/orpheus-v1-english"
    @State var voice = "autumn"
    @State var text = ""
    @State var busy = false; @State var error: String?
    @State var player: AVAudioPlayer?
    var voices: [String] {
        model.contains("arabic") ? ["abdullah", "fahad", "sultan", "lulwah", "noura", "aisha"]
                                 : ["autumn", "diana", "hannah", "austin", "daniel", "troy"]
    }
    var body: some View {
        NavigationStack {
            Form {
                Picker("Модель", selection: $model) {
                    Text("Orpheus English").tag("canopylabs/orpheus-v1-english")
                    Text("Orpheus Arabic (Saudi)").tag("canopylabs/orpheus-arabic-saudi")
                }.onChange(of: model) { _, _ in voice = voices[0] }
                Picker("Голос", selection: $voice) { ForEach(voices, id: \.self) { Text($0) } }
                Section("Текст") { TextEditor(text: $text).frame(minHeight: 140) }
                Button("Озвучить") {
                    Task {
                        busy = true; error = nil
                        do {
                            let d = try await s.api.speech(model: model, voice: voice, text: text)
                            try AVAudioSession.sharedInstance().setCategory(.playback)
                            player = try AVAudioPlayer(data: d); player?.play()
                        } catch { self.error = error.localizedDescription }
                        busy = false
                    }
                }.disabled(text.isEmpty || busy)
                ResultBox(text: "", error: error, busy: busy)
            }.navigationTitle("Озвучка")
        }
    }
}

// MARK: - STT
final class Recorder: NSObject, ObservableObject {
    @Published var recording = false
    var rec: AVAudioRecorder?
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("rec.m4a")
    func toggle() {
        if recording { rec?.stop(); recording = false; return }
        let session = AVAudioSession.sharedInstance()
        session.requestRecordPermission { ok in
            guard ok else { return }
            try? session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try? session.setActive(true)
            self.rec = try? AVAudioRecorder(url: self.url, settings: [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC), AVSampleRateKey: 16000,
                AVNumberOfChannelsKey: 1])
            self.rec?.record()
            DispatchQueue.main.async { self.recording = true }
        }
    }
}

struct STTView: View {
    @EnvironmentObject var s: Store
    @StateObject var r = Recorder()
    @State var model = "whisper-large-v3-turbo"
    @State var out = ""; @State var busy = false; @State var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Picker("Модель", selection: $model) {
                    Text("whisper-large-v3-turbo (быстрее)").tag("whisper-large-v3-turbo")
                    Text("whisper-large-v3 (точнее)").tag("whisper-large-v3")
                }
                Button(r.recording ? "Остановить запись" : "Начать запись") { r.toggle() }
                    .foregroundStyle(r.recording ? .red : .green)
                Button("Распознать") {
                    Task {
                        busy = true; error = nil; out = ""
                        do { out = try await s.api.transcribe(model: model, file: r.url) }
                        catch { self.error = error.localizedDescription }
                        busy = false
                    }
                }.disabled(r.recording || busy)
                Section("Текст") { ResultBox(text: out, error: error, busy: busy) }
            }.navigationTitle("Речь в текст")
        }
    }
}

// MARK: - Settings
struct SettingsView: View {
    @EnvironmentObject var s: Store
    @State var show = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Groq API ключ") {
                    HStack {
                        Group { show ? AnyView(TextField("gsk_…", text: $s.key)) : AnyView(SecureField("gsk_…", text: $s.key)) }
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { show.toggle() } label: { Image(systemName: show ? "eye.slash" : "eye") }
                    }
                    Button("Обновить список моделей") { Task { await s.refresh() } }
                }
                Section("Доступно моделей: \(s.available.count)") {
                    ForEach(s.available, id: \.self) { Text($0) }
                }
            }.navigationTitle("Подключение")
        }
    }
}

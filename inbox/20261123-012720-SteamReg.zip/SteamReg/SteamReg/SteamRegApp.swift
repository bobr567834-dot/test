import SwiftUI

@main
struct SteamRegApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

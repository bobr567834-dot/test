import SwiftUI
import WebKit

let steamJoinURL = URL(string: "https://store.steampowered.com/join/")!

struct WebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.allowsBackForwardNavigationGestures = true
        webView.load(URLRequest(url: url))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ContentView: View {
    @State private var webViewID = UUID()
    @State private var isClearing = false

    var body: some View {
        VStack(spacing: 0) {
            WebView(url: steamJoinURL)
                .id(webViewID)

            Button(action: clearAndReload) {
                Text(isClearing ? "Очистка..." : "Очистить данные и начать заново")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .disabled(isClearing)
            .padding(.horizontal)
            .padding(.vertical, 10)
            .background(Color(UIColor.systemBackground))
        }
    }

    private func clearAndReload() {
        isClearing = true
        let store = WKWebsiteDataStore.default()
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        store.removeData(ofTypes: types, modifiedSince: .distantPast) {
            HTTPCookieStorage.shared.removeCookies(since: .distantPast)
            URLCache.shared.removeAllCachedResponses()
            webViewID = UUID() // пересоздаёт WebView -> страница грузится заново
            isClearing = false
        }
    }
}

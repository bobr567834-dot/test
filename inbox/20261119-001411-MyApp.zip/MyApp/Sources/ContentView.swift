//
//  ContentView.swift
//  TurboDrift2D
//
//  Created for iOS using SwiftUI & SpriteKit
//

import SwiftUI
import SpriteKit
import CoreMotion

// MARK: - Game Scene (SpriteKit)
class RaceGameScene: SKScene, SKPhysicsContactDelegate {
    
    // Nodes
    var playerCar: SKSpriteNode!
    var bots: [SKSpriteNode] = []
    var trackNode: SKShapeNode!
    
    // Game State
    var isGameOver = false
    var currentLap = 1
    var totalLaps = 3
    var playerSpeed: CGFloat = 0.0
    var maxSpeed: CGFloat = 350.0
    var acceleration: CGFloat = 150.0
    var nitroActive = false
    var nitroFuel: CGFloat = 100.0
    
    // Controls state
    var isAccelerating = false
    var isBraking = false
    var steeringInput: CGFloat = 0.0 // -1 to 1
    
    // Callbacks for SwiftUI overlay
    var onUpdateStats: ((Int, CGFloat, CGFloat) -> Void)?
    var onGameOver: ((Bool, String) -> Void)?
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        physicsWorld.gravity = .zero
        
        backgroundColor = UIColor(red: 0.1, green: 0.12, blue: 0.15, alpha: 1.0)
        
        setupTrack()
        setupPlayer()
        setupBots()
    }
    
    func setupTrack() {
        // Создаем гоночный трек (овальная трасса с барьерами)
        trackNode = SKShapeNode()
        let path = CGMutablePath()
        path.addEllipse(in: CGRect(x: 50, y: 50, width: size.width - 100, height: size.height - 100))
        trackNode.path = path
        trackNode.strokeColor = UIColor.darkGray
        trackNode.lineWidth = 120
        trackNode.isUserInteractionEnabled = false
        addChild(trackNode)
        
        // Внутренняя зона (трава)
        let innerGrass = SKShapeNode(ellipseIn: CGRect(x: 110, y: 110, width: size.width - 220, height: size.height - 220))
        innerGrass.fillColor = UIColor(red: 0.15, green: 0.35, blue: 0.2, alpha: 1.0)
        innerGrass.strokeColor = .clear
        addChild(innerGrass)
    }
    
    func setupPlayer() {
        playerCar = SKSpriteNode(color: .systemRed, size: CGSize(width: 30, height: 50))
        playerCar.position = CGPoint(x: size.width / 2 - 40, y: 120)
        playerCar.zRotation = 0
        
        playerCar.physicsBody = SKPhysicsBody(rectangleOf: playerCar.size)
        playerCar.physicsBody?.isDynamic = true
        playerCar.physicsBody?.allowsRotation = true
        playerCar.physicsBody?.mass = 1.0
        
        addChild(playerCar)
    }
    
    func setupBots() {
        let botColors: [UIColor] = [.systemBlue, .systemYellow, .systemPurple]
        for i in 0..<3 {
            let bot = SKSpriteNode(color: botColors[i], size: CGSize(width: 30, height: 50))
            bot.position = CGPoint(x: size.width / 2 + CGFloat(i * 40 - 40), y: 120 + CGFloat(i * 20))
            bot.zRotation = 0
            bot.userData = ["targetWaypoint": 0, "speed": CGFloat(240 + i * 20)]
            addChild(bot)
            bots.append(bot)
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        if isGameOver { return }
        
        // Управление скоростью игрока
        if isAccelerating {
            let currentMax = nitroActive ? maxSpeed * 1.5 : maxSpeed
            playerSpeed = min(playerSpeed + acceleration * 0.016, currentMax)
        } else if isBraking {
            playerSpeed = max(playerSpeed - acceleration * 0.032, 0)
        } else {
            playerSpeed = max(playerSpeed - acceleration * 0.008, 0)
        }
        
        // Нитро логика
        if nitroActive {
            nitroFuel = max(nitroFuel - 0.5, 0)
            if nitroFuel <= 0 { nitroActive = false }
        } else if nitroFuel < 100 {
            nitroFuel = min(nitroFuel + 0.1, 100)
        }
        
        // Поворот машины игрока
        if steeringInput != 0 {
            let rotationSpeed: CGFloat = 3.5
            playerCar.zRotation -= steeringInput * rotationSpeed * 0.016 * (playerSpeed / maxSpeed + 0.2)
        }
        
        // Движение вперед по текущему углу
        let dx = -sin(playerCar.zRotation) * playerSpeed * 0.016
        let dy = cos(playerCar.zRotation) * playerSpeed * 0.016
        playerCar.position.x += dx
        playerCar.position.y += dy
        
        // ИИ ботов (упрощенный патруль по кругу)
        updateBotsMovement()
        
        // Передача данных в SwiftUI
        onUpdateStats?(currentLap, playerSpeed, nitroFuel)
    }
    
    func updateBotsMovement() {
        let center = CGPoint(x: size.width / 2, y: size.height / 2)
        let radiusX = (size.width - 140) / 2
        let radiusY = (size.height - 140) / 2
        
        for (index, bot) in bots.enumerated() {
            var data = bot.userData ?? [:]
            var wpIndex = data["targetWaypoint"] as? Int ?? 0
            let bSpeed = data["speed"] as? CGFloat ?? 250
            
            // Набор точек эллипса для ботов
            let angle = CGFloat(wpIndex) * 0.05 + CGFloat(index) * 0.5
            let targetX = center.x + cos(angle) * radiusX
            let targetY = center.y + sin(angle) * radiusY
            let targetPoint = CGPoint(x: targetX, y: targetY)
            
            let dx = targetPoint.x - bot.position.x
            let dy = targetPoint.y - bot.position.y
            let targetAngle = atan2(-dx, dy)
            
            bot.zRotation = targetAngle
            let moveDx = -sin(bot.zRotation) * bSpeed * 0.016
            let moveDy = cos(bot.zRotation) * bSpeed * 0.016
            bot.position.x += moveDx
            bot.position.y += moveDy
            
            if hypot(dx, dy) < 40 {
                wpIndex = (wpIndex + 1) % 120
                data["targetWaypoint"] = wpIndex
                bot.userData = data
            }
        }
    }
}

// MARK: - SwiftUI Game View
struct ContentView: View {
    @State private var currentLap = 1
    @State private var speed: CGFloat = 0
    @State private var nitro: CGFloat = 100
    @State private var gameState: GameState = .menu
    @State private var gameOverMessage = ""
    
    enum GameState {
        case menu, playing, gameOver
    }
    
    var body: some View {
        ZStack {
            if gameState == .menu {
                VStack(spacing: 20) {
                    Text("🏎️ TURBO DRIFT 2D")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.white)
                    
                    Text("Аркадные гонки на iOS в SpriteKit")
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        gameState = .playing
                    }) {
                        Text("СТАРТ ГОНКИ")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 220)
                            .background(Color.red)
                            .cornerRadius(12)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black.ignoresSafeArea())
                
            } else {
                // Игровой процесс
                GeometryReader { geo in
                    SpriteView(scene: createScene(size: geo.size))
                        .ignoresSafeArea()
                }
                
                // HUD интерфейс поверх игры
                VStack {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("КРУГ: \(currentLap)/3")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                            Text("СКОРОСТЬ: \(Int(speed)) км/ч")
                                .font(.system(size: 14))
                                .foregroundColor(.cyan)
                        }
                        Spacer()
                        VStack(alignment: .trailing) {
                            Text("НИТРО")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(.orange)
                            ProgressView(value: nitro, total: 100)
                                .frame(width: 100)
                                .tint(.orange)
                        }
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)
                    .padding(.horizontal)
                    
                    Spacer()
                    
                    // Элементы управления на экране iPhone
                    HStack(spacing: 40) {
                        // Кнопки поворота
                        HStack(spacing: 20) {
                            Button(action: {}) {
                                Image(systemName: "arrow.left.circle.fill")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white.opacity(0.8))
                            }
                            // Здесь в реальном проекте привязываются Gesture / LongPress для управления поворотниками
                            Button(action: {}) {
                                Image(systemName: "arrow.right.circle.fill")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                        
                        Spacer()
                        
                        // Газ и Нитро
                        HStack(spacing: 15) {
                            Button(action: {}) {
                                Text("NITRO")
                                    .font(.system(size: 14, weight: .bold))
                                    .foregroundColor(.black)
                                    .frame(width: 70, height: 70)
                                    .background(Color.orange)
                                    .clipShape(Circle())
                            }
                            Button(action: {}) {
                                Text("GAZ")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(width: 85, height: 85)
                                    .background(Color.red)
                                    .clipShape(Circle())
                            }
                        }
                    }
                    .padding(.horizontal, 30)
                    .padding(.bottom, 30)
                }
            }
        }
    }
    
    func createScene(size: CGSize) -> RaceGameScene {
        let scene = RaceGameScene(size: size)
        scene.scaleMode = .fill
        scene.onUpdateStats = { lap, currentSpeed, currentNitro in
            self.currentLap = lap
            self.speed = currentSpeed
            self.nitro = currentNitro
        }
        return scene
    }
}

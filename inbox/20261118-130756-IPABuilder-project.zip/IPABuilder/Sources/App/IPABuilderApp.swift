import SwiftUI

@main
struct IPABuilderApp: App {
    @StateObject private var model = BuilderModel()

    init() {
        NotificationManager.shared.configure()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .preferredColorScheme(.light)
        }
    }
}

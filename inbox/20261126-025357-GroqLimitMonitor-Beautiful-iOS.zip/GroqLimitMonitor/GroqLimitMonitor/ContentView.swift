import SwiftUI
import Security

@main
struct GroqLimitMonitorApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

struct GroqModel: Identifiable, Decodable, Hashable { let id: String }
struct ModelsResponse: Decodable { let data: [GroqModel] }
struct CompletionRequest: Encodable {
    let model: String
    let messages: [Message]
    let max_tokens: Int
    struct Message: Encodable { let role: String; let content: String }
}
struct LimitSnapshot { let remaining: Int; let limit: Int; let resetText: String }
enum GroqAPIError: LocalizedError {
    case badKey, missingHeaders, server(Int)
    var errorDescription: String? {
        switch self {
        case .badKey: return "Проверь API-ключ Groq."
        case .missingHeaders: return "Groq не вернул заголовки лимитов. Попробуй ещё раз."
        case .server(let code): return "Ошибка Groq API: HTTP \(code)."
        }
    }
}
enum GroqAPI {
    static func loadModels(key: String) async throws -> [GroqModel] {
        var request = URLRequest(url: URL(string: "https://api.groq.com/openai/v1/models")!)
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw GroqAPIError.server(-1) }
        guard http.statusCode == 200 else {
            if http.statusCode == 401 { throw GroqAPIError.badKey }
            throw GroqAPIError.server(http.statusCode)
        }
        return try JSONDecoder().decode(ModelsResponse.self, from: data).data.sorted { $0.id < $1.id }
    }
    static func checkLimits(key: String, model: String) async throws -> LimitSnapshot {
        var request = URLRequest(url: URL(string: "https://api.groq.com/openai/v1/chat/completions")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(CompletionRequest(model: model, messages: [.init(role: "user", content: "Reply with OK.")], max_tokens: 1))
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw GroqAPIError.server(-1) }
        if http.statusCode == 401 { throw GroqAPIError.badKey }
        guard (200..<300).contains(http.statusCode) else { throw GroqAPIError.server(http.statusCode) }
        guard let rem = http.value(forHTTPHeaderField: "x-ratelimit-remaining-tokens"),
              let lim = http.value(forHTTPHeaderField: "x-ratelimit-limit-tokens"),
              let remaining = Int(rem), let limit = Int(lim),
              let reset = http.value(forHTTPHeaderField: "x-ratelimit-reset-tokens") else { throw GroqAPIError.missingHeaders }
        return LimitSnapshot(remaining: remaining, limit: limit, resetText: reset)
    }
}

struct ContentView: View {
    @State private var apiKey = Keychain.read() ?? ""
    @State private var models: [GroqModel] = []
    @State private var selectedModel = ""
    @State private var snapshot: LimitSnapshot?
    @State private var errorMessage = ""
    @State private var loading = false
    @State private var revealKey = false
    private let mint = Color(red: 0.40, green: 0.94, blue: 0.72)
    private var ratio: Double { guard let s = snapshot, s.limit > 0 else { return 0 }; return min(max(Double(s.remaining) / Double(s.limit), 0), 1) }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.045, green: 0.065, blue: 0.105), Color(red: 0.09, green: 0.12, blue: 0.18)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    keyCard
                    if !models.isEmpty { modelCard; limitCard } else { emptyCard }
                    if !errorMessage.isEmpty { errorCard }
                    footnote
                }
                .padding(.horizontal, 20).padding(.top, 14).padding(.bottom, 30).frame(maxWidth: 560).frame(maxWidth: .infinity)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 7) {
                Text("GROQ  /  API MONITOR").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(2).foregroundStyle(mint)
                Text("Лимиты API").font(.system(size: 32, weight: .bold, design: .rounded)).foregroundStyle(.white)
                Text("Токены, модели и время сброса").font(.system(size: 14)).foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            ZStack {
                RoundedRectangle(cornerRadius: 18).fill(mint.opacity(0.12)).frame(width: 58, height: 58)
                Image(systemName: "waveform.path.ecg").font(.system(size: 25, weight: .semibold)).foregroundStyle(mint)
            }
        }.padding(.bottom, 2)
    }

    private var keyCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                Label("Подключение", systemImage: "key.horizontal").font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
                Spacer()
                if Keychain.read() != nil { Label("Сохранён", systemImage: "checkmark.circle.fill").font(.system(size: 11, weight: .medium)).foregroundStyle(mint) }
            }
            HStack(spacing: 10) {
                Group {
                    if revealKey { TextField("Вставь API-ключ Groq", text: $apiKey) }
                    else { SecureField("gsk_••••••••••••", text: $apiKey) }
                }.textInputAutocapitalization(.never).autocorrectionDisabled().font(.system(size: 14, design: .monospaced))
                Button { revealKey.toggle() } label: { Image(systemName: revealKey ? "eye.slash" : "eye").foregroundStyle(.white.opacity(0.55)) }.buttonStyle(.plain)
            }.padding(14).background(.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 13)).overlay(RoundedRectangle(cornerRadius: 13).stroke(.white.opacity(0.07)))
            Button { Task { await loadModels() } } label: {
                HStack(spacing: 8) { if loading { ProgressView().tint(.black) } else { Image(systemName: "link") }; Text(models.isEmpty ? "Подключить Groq" : "Обновить список моделей") }
                    .font(.system(size: 14, weight: .bold)).foregroundStyle(Color.black.opacity(0.86)).frame(maxWidth: .infinity).padding(.vertical, 14).background(mint, in: RoundedRectangle(cornerRadius: 14))
            }.buttonStyle(.plain).disabled(loading || apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }.padding(18).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 22)).overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.08)))
    }

    private var modelCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionLabel("ВЫБРАННАЯ МОДЕЛЬ", icon: "cpu")
            Menu {
                ForEach(models) { model in Button { selectedModel = model.id; snapshot = nil; errorMessage = "" } label: { if selectedModel == model.id { Label(model.id, systemImage: "checkmark") } else { Text(model.id) } } }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "cube.transparent").font(.system(size: 19)).foregroundStyle(mint).frame(width: 42, height: 42).background(mint.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 3) { Text(selectedModel.isEmpty ? "Выбери модель" : selectedModel).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white).lineLimit(1); Text("Доступно моделей: \(models.count)").font(.system(size: 12)).foregroundStyle(.white.opacity(0.48)) }
                    Spacer(); Image(systemName: "chevron.up.chevron.down").font(.system(size: 12, weight: .semibold)).foregroundStyle(.white.opacity(0.5))
                }.padding(14).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 17)).overlay(RoundedRectangle(cornerRadius: 17).stroke(.white.opacity(0.08)))
            }.disabled(loading)
        }
    }

    private var limitCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack { sectionLabel("ОСТАТОК ТОКЕНОВ", icon: "chart.bar.fill"); Spacer(); if snapshot != nil { Text("TPM").font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1).foregroundStyle(mint).padding(.horizontal, 9).padding(.vertical, 6).background(mint.opacity(0.12), in: Capsule()) } }
            if let s = snapshot {
                HStack(alignment: .firstTextBaseline, spacing: 5) {
                    Text(s.remaining.formatted()).font(.system(size: 42, weight: .bold, design: .rounded)).tracking(-1.5).foregroundStyle(.white).minimumScaleFactor(0.6).lineLimit(1)
                    Text("/ \(s.limit.formatted())").font(.system(size: 15, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42)).lineLimit(1).minimumScaleFactor(0.65)
                }
                GeometryReader { geo in ZStack(alignment: .leading) { Capsule().fill(.white.opacity(0.08)); Capsule().fill(LinearGradient(colors: [mint, .cyan], startPoint: .leading, endPoint: .trailing)).frame(width: max(7, geo.size.width * ratio)) } }.frame(height: 9)
                HStack { Label("\(Int(ratio * 100))% осталось", systemImage: "circle.lefthalf.filled").foregroundStyle(mint); Spacer(); Text("из лимита").foregroundStyle(.white.opacity(0.45)) }.font(.system(size: 12, weight: .medium))
                HStack(spacing: 12) {
                    metric(title: "До сброса", value: s.resetText, icon: "timer", tint: .cyan)
                    metric(title: "Лимит", value: "\(s.limit.formatted()) TPM", icon: "speedometer", tint: .purple)
                }
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "chart.bar.xaxis").font(.system(size: 30)).foregroundStyle(mint.opacity(0.8))
                    Text("Лимит ещё не проверен").font(.system(size: 15, weight: .semibold)).foregroundStyle(.white)
                    Text("Проверь выбранную модель, чтобы получить актуальные данные.").font(.system(size: 13)).foregroundStyle(.white.opacity(0.48)).multilineTextAlignment(.center)
                }.frame(maxWidth: .infinity).padding(.vertical, 14)
            }
            Button { Task { await check() } } label: {
                HStack(spacing: 9) { if loading { ProgressView().tint(.white) } else { Image(systemName: "arrow.clockwise") }; Text(loading ? "Проверяем…" : "Проверить лимит") }
                    .font(.system(size: 15, weight: .bold)).foregroundStyle(.white).frame(maxWidth: .infinity).padding(.vertical, 15).background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(.white.opacity(0.1)))
            }.buttonStyle(.plain).disabled(loading || selectedModel.isEmpty || apiKey.isEmpty)
        }.padding(18).background(LinearGradient(colors: [Color(red: 0.12, green: 0.17, blue: 0.22), Color(red: 0.10, green: 0.13, blue: 0.19)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(mint.opacity(0.18))).shadow(color: .black.opacity(0.18), radius: 22, y: 10)
    }

    private var emptyCard: some View {
        HStack(spacing: 12) { Image(systemName: "sparkles").font(.title2).foregroundStyle(mint); VStack(alignment: .leading, spacing: 4) { Text("Готово к подключению").font(.system(size: 14, weight: .semibold)).foregroundStyle(.white); Text("Вставь ключ выше, чтобы загрузить модели.").font(.system(size: 12)).foregroundStyle(.white.opacity(0.5)) } }.padding(16).frame(maxWidth: .infinity, alignment: .leading).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18))
    }
    private var errorCard: some View {
        HStack(alignment: .top, spacing: 10) { Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange); Text(errorMessage).font(.system(size: 13)).foregroundStyle(.white.opacity(0.8)); Spacer(minLength: 0); Button { errorMessage = "" } label: { Image(systemName: "xmark").font(.system(size: 11, weight: .bold)).foregroundStyle(.white.opacity(0.5)) } }.padding(14).background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 15)).overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.orange.opacity(0.18)))
    }
    private var footnote: some View {
        HStack(alignment: .top, spacing: 9) { Image(systemName: "info.circle").foregroundStyle(.white.opacity(0.38)); Text("Проверка отправляет короткий запрос и расходует немного токенов. Отображается лимит в минуту, не месячный баланс. API-ключ хранится в Keychain на устройстве.").font(.system(size: 11)).foregroundStyle(.white.opacity(0.4)).fixedSize(horizontal: false, vertical: true) }.padding(.horizontal, 3)
    }
    private func sectionLabel(_ title: String, icon: String) -> some View { Label(title, systemImage: icon).font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1.4).foregroundStyle(.white.opacity(0.48)) }
    private func metric(title: String, value: String, icon: String, tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) { Image(systemName: icon).font(.system(size: 15, weight: .semibold)).foregroundStyle(tint); Text(title).font(.system(size: 11, weight: .medium)).foregroundStyle(.white.opacity(0.48)); Text(value).font(.system(size: 16, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.65) }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(.black.opacity(0.17), in: RoundedRectangle(cornerRadius: 15)).overlay(RoundedRectangle(cornerRadius: 15).stroke(.white.opacity(0.05)))
    }
    @MainActor private func loadModels() async {
        loading = true; errorMessage = ""; defer { loading = false }
        do { let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines); let loaded = try await GroqAPI.loadModels(key: key); models = loaded; if !loaded.contains(where: { $0.id == selectedModel }) { selectedModel = loaded.first?.id ?? "" }; Keychain.save(key) }
        catch let caughtError { errorMessage = caughtError.localizedDescription }
    }
    @MainActor private func check() async {
        loading = true; errorMessage = ""; defer { loading = false }
        do { snapshot = try await GroqAPI.checkLimits(key: apiKey.trimmingCharacters(in: .whitespacesAndNewlines), model: selectedModel) }
        catch let caughtError { errorMessage = caughtError.localizedDescription }
    }
}

enum Keychain {
    static let service = "com.example.GroqLimitMonitor"
    static let account = "groq-api-key"
    static func save(_ value: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
        var item = query; item[kSecValueData as String] = data; item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }
    static func read() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

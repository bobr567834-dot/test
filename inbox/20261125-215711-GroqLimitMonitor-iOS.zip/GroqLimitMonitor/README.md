# Groq Limits — iOS SwiftUI

Простой монитор лимита токенов Groq.

## Сборка
1. Установите Xcode и XcodeGen (`brew install xcodegen`).
2. В каталоге проекта выполните `xcodegen generate`.
3. Откройте `GroqLimitMonitor.xcodeproj` в Xcode.
4. Выберите iPhone Simulator или подключённый iPhone и нажмите Run.

## Что показывает
- Загружает список моделей, доступных API-ключу.
- После тестового запроса читает `x-ratelimit-remaining-tokens`,
  `x-ratelimit-limit-tokens` и `x-ratelimit-reset-tokens`.
- Сохраняет ключ в iOS Keychain.

Проверка лимита отправляет короткий запрос с `max_tokens: 1`, поэтому расходует немного токенов.
Показываемый остаток — лимит TPM из заголовка ответа, не общий месячный баланс или число всех токенов на аккаунте.

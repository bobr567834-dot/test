import SwiftUI
import Security

@main
struct GroqLimitMonitorApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct GroqModel: Identifiable, Decodable, Hashable {
    let id: String
    var name: String { id }
}

struct ModelsResponse: Decodable {
    let data: [GroqModel]
}

struct CompletionRequest: Encodable {
    let model: String
    let messages: [Message]
    let max_tokens: Int
    struct Message: Encodable {
        let role: String
        let content: String
    }
}

struct LimitSnapshot {
    let remaining: String
    let limit: String
    let reset: String
}

enum GroqAPIError: LocalizedError {
    case badKey, noRateHeaders, server(String)
    var errorDescription: String? {
        switch self {
        case .badKey: return "Проверь API-ключ Groq."
        case .noRateHeaders: return "Groq не вернул заголовки лимитов. Попробуй ещё раз."
        case .server(let message): return message
        }
    }
}

enum GroqAPI {
    static func loadModels(key: String) async throws -> [GroqModel] {
        var request = URLRequest(url: URL(string: "https://api.groq.com/openai/v1/models")!)
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw GroqAPIError.server("Не удалось прочитать ответ.") }
        guard http.statusCode == 200 else {
            if http.statusCode == 401 { throw GroqAPIError.badKey }
            throw GroqAPIError.server("Ошибка Groq API: HTTP \(http.statusCode)")
        }
        return try JSONDecoder().decode(ModelsResponse.self, from: data).data.sorted { $0.id < $1.id }
    }

    static func checkLimits(key: String, model: String) async throws -> LimitSnapshot {
        var request = URLRequest(url: URL(string: "https://api.groq.com/openai/v1/chat/completions")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(CompletionRequest(
            model: model,
            messages: [.init(role: "user", content: "Reply with OK.")],
            max_tokens: 1
        ))
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw GroqAPIError.server("Не удалось прочитать ответ.") }
        if http.statusCode == 401 { throw GroqAPIError.badKey }
        guard (200..<300).contains(http.statusCode) else {
            throw GroqAPIError.server("Groq API вернул HTTP \(http.statusCode).")
        }
        let remaining = http.value(forHTTPHeaderField: "x-ratelimit-remaining-tokens")
        let limit = http.value(forHTTPHeaderField: "x-ratelimit-limit-tokens")
        let reset = http.value(forHTTPHeaderField: "x-ratelimit-reset-tokens")
        guard let remaining, let limit, let reset else { throw GroqAPIError.noRateHeaders }
        return LimitSnapshot(remaining: remaining, limit: limit, reset: reset)
    }
}

struct ContentView: View {
    @State private var apiKey = Keychain.read() ?? ""
    @State private var models: [GroqModel] = []
    @State private var selectedModel = ""
    @State private var snapshot: LimitSnapshot?
    @State private var error = ""
    @State private var loading = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("API-ключ").font(.headline)
                        SecureField("gsk_…", text: $apiKey)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .padding(14)
                            .background(.quaternary.opacity(0.55), in: RoundedRectangle(cornerRadius: 14))
                        Button("Сохранить ключ и загрузить модели") { Task { await loadModels() } }
                            .buttonStyle(.borderedProminent)
                            .disabled(apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || loading)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    if !models.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Модель").font(.headline)
                            Picker("Модель", selection: $selectedModel) {
                                ForEach(models) { model in Text(model.id).tag(model.id) }
                            }
                            .pickerStyle(.menu)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(12)
                            .background(.quaternary.opacity(0.55), in: RoundedRectangle(cornerRadius: 14))
                            Button {
                                Task { await check() }
                            } label: {
                                if loading { ProgressView().tint(.white) }
                                else { Label("Проверить лимит", systemImage: "arrow.clockwise") }
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(loading || selectedModel.isEmpty)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    if let snapshot {
                        VStack(spacing: 14) {
                            Text("Лимит токенов в минуту")
                                .font(.headline).frame(maxWidth: .infinity, alignment: .leading)
                            HStack(alignment: .firstTextBaseline, spacing: 4) {
                                Text(snapshot.remaining).font(.system(size: 38, weight: .bold, design: .rounded))
                                Text("/ \(snapshot.limit)").foregroundStyle(.secondary)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                            ProgressView(value: Double(snapshot.remaining) ?? 0, total: max(Double(snapshot.limit) ?? 1, 1))
                                .tint(.green)
                            Label("Сброс через \(snapshot.reset)", systemImage: "timer")
                                .font(.subheadline).foregroundStyle(.secondary)
                            Text("Это остаток лимита TPM на момент последнего запроса, а не месячный баланс.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        .padding(16)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    }

                    if !error.isEmpty {
                        Text(error).foregroundStyle(.red).font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    Text("Проверка отправляет короткий запрос выбранной модели и расходует немного токенов. Ключ хранится в Keychain на этом устройстве.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding()
            }
            .navigationTitle("Groq Limits")
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }

    @MainActor
    private func loadModels() async {
        loading = true
        error = ""
        defer { loading = false }
        do {
            let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
            let result = try await GroqAPI.loadModels(key: key)
            models = result
            if !result.contains(where: { $0.id == selectedModel }) { selectedModel = result.first?.id ?? "" }
            Keychain.save(key)
        } catch { error = error.localizedDescription }
    }

    @MainActor
    private func check() async {
        loading = true
        error = ""
        defer { loading = false }
        do {
            snapshot = try await GroqAPI.checkLimits(
                key: apiKey.trimmingCharacters(in: .whitespacesAndNewlines),
                model: selectedModel
            )
        } catch { error = error.localizedDescription }
    }
}

enum Keychain {
    static let service = "com.example.GroqLimitMonitor"
    static let account = "groq-api-key"

    static func save(_ value: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
        var item = query
        item[kSecValueData as String] = data
        item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

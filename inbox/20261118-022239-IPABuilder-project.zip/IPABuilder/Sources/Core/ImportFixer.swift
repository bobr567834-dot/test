import Foundation

/// Добавляет в начало Swift-файлов недостающие `import`, если код явно использует типы из модуля.
/// Подход осторожный: лишний import ничему не мешает, а нехватка ломает сборку.
enum ImportFixer {
    private struct Rule {
        let module: String
        let pattern: NSRegularExpression
        let only: BuildPlatform?
    }

    /// Какие модули уже подтягиваются через другие (SwiftUI тянет Foundation, Combine, UIKit и т. д.).
    private static let implied: [String: Set<String>] = [
        "SwiftUI": ["Foundation", "Combine", "UIKit", "CoreGraphics"],
        "UIKit": ["Foundation", "CoreGraphics"],
        "WatchKit": ["Foundation", "CoreGraphics"],
        "Foundation": ["CoreGraphics"]
    ]

    /// Порядок важен: SwiftUI проверяется первым, чтобы не добавлять лишнее (UIKit, Foundation, Combine).
    private static let definitions: [(String, String, BuildPlatform?)] = [
        ("SwiftUI",
         #":\s*(?:View|App|Scene|ViewModifier|Shape|ButtonStyle|PreviewProvider)\b|@(?:State|Binding|StateObject|ObservedObject|EnvironmentObject|Environment|AppStorage|SceneStorage|ViewBuilder|FocusState)\b|\b(?:VStack|HStack|ZStack|LazyVStack|LazyHStack|NavigationStack|NavigationView|TabView|ScrollView|ForEach|Spacer|Toggle|TextField|Picker|Slider|Stepper)\b\s*[({]|\bText\(|\bButton\(|\bWindowGroup\b"#,
         nil),
        ("UIKit", #"\bUI[A-Z][A-Za-z]+\b"#, .ios),
        ("WatchKit", #"\b(?:WKInterfaceDevice|WKHapticType|WKExtension)\b"#, .watchos),
        ("Combine", #"@Published\b|\bObservableObject\b|\bAnyCancellable\b|\bPassthroughSubject\b|\bCurrentValueSubject\b"#, nil),
        ("Foundation",
         #"\b(?:Date|URL|URLSession|URLRequest|JSONEncoder|JSONDecoder|UserDefaults|Timer|DispatchQueue|FileManager|UUID|NSRegularExpression|ProcessInfo|Bundle|NotificationCenter|DateFormatter|Locale|TimeInterval|NSString|NSObject|Data)\b"#,
         nil),
        ("CoreBluetooth", #"\bCB[A-Z][A-Za-z]+\b"#, nil),
        ("CoreLocation", #"\bCL[A-Z][A-Za-z]+\b"#, nil),
        ("Network", #"\bNW[A-Z][A-Za-z]+\b"#, nil),
        ("AVFoundation", #"\bAV[A-Z][A-Za-z]+\b"#, nil),
        ("PhotosUI", #"\bPhotosPicker(?:Item)?\b|\bPHPicker[A-Za-z]*\b"#, nil),
        ("Photos", #"\bPH(?:PhotoLibrary|Asset|FetchResult|FetchOptions|AssetChangeRequest|ImageManager)\b"#, nil),
        ("LocalAuthentication", #"\bLAContext\b"#, nil),
        ("SpriteKit", #"\bSK[A-Z][A-Za-z]+\b|\bSpriteView\b"#, nil),
        ("Charts", #"\bChart\s*\{"#, nil),
        ("MapKit", #"\bMK[A-Z][A-Za-z]+\b"#, nil),
        ("CryptoKit", #"\b(?:SHA256|SHA384|SHA512|SymmetricKey|AES\.GCM|ChaChaPoly)\b"#, nil),
        ("Security", #"\b(?:SecItem[A-Za-z]*|SecCertificate[A-Za-z]*|kSec[A-Za-z]+)\b"#, nil),
        ("UserNotifications", #"\bUN(?:UserNotificationCenter|MutableNotificationContent|TimeIntervalNotificationTrigger)\b"#, nil),
        ("UniformTypeIdentifiers", #"\bUTType\b"#, nil)
    ]

    private static let rules: [Rule] = definitions.compactMap { definition in
        guard let regex = try? NSRegularExpression(pattern: definition.1) else { return nil }
        return Rule(module: definition.0, pattern: regex, only: definition.2)
    }

    private static let importPattern = try? NSRegularExpression(
        pattern: #"(?m)^[ \t]*(?:@[A-Za-z_]+[ \t]+)?import[ \t]+(?:(?:struct|class|enum|protocol|func|var|let|typealias)[ \t]+)?([A-Za-z0-9_]+)"#
    )

    private static func importedModules(in text: String) -> Set<String> {
        guard let regex = importPattern else { return [] }
        let ns = text as NSString
        var modules = Set<String>()
        for match in regex.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            modules.insert(ns.substring(with: match.range(at: 1)))
        }
        return modules
    }

    private static func isCovered(_ module: String, by have: Set<String>) -> Bool {
        if have.contains(module) { return true }
        return have.contains { implied[$0]?.contains(module) == true }
    }

    /// Возвращает файлы с добавленными import и пояснение для пользователя (nil, если ничего не добавлялось).
    static func fix(_ files: [PickedFile], platform: BuildPlatform) -> (files: [PickedFile], note: String?) {
        var counts: [String: Int] = [:]
        var result: [PickedFile] = []

        for file in files {
            guard file.path.hasSuffix(".swift") else {
                result.append(file)
                continue
            }

            let original = String(decoding: file.data, as: UTF8.self)
            // Комментарии не учитываем: слова из них не означают использование типа.
            let code = original.replacingOccurrences(of: #"//[^\n]*"#, with: "", options: .regularExpression)
            let range = NSRange(location: 0, length: (code as NSString).length)

            var have = importedModules(in: original)
            var added: [String] = []

            for rule in rules {
                if let only = rule.only, only != platform { continue }
                if isCovered(rule.module, by: have) { continue }
                if rule.pattern.firstMatch(in: code, range: range) != nil {
                    added.append(rule.module)
                    have.insert(rule.module)
                }
            }

            guard !added.isEmpty else {
                result.append(file)
                continue
            }

            for module in added { counts[module, default: 0] += 1 }
            let header = added.map { "import \($0)\n" }.joined()
            result.append(PickedFile(path: file.path, data: Data((header + original).utf8)))
        }

        guard !counts.isEmpty else { return (result, nil) }
        let list = counts.keys.sorted().map { "\($0) ×\(counts[$0] ?? 0)" }.joined(separator: ", ")
        return (result, "Добавлены недостающие import: \(list).")
    }
}

import ActivityKit
import Foundation

/// Запускает и обновляет Live Activity (Dynamic Island / экран блокировки) на время сборки.
@MainActor
final class LiveActivityController {
    typealias State = BuildActivityAttributes.ContentState

    private var activity: Activity<BuildActivityAttributes>?

    func start(projectName: String) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }

        // Если от прошлой сборки что-то осталось — закрываем.
        if let old = activity {
            Task { await old.end(nil, dismissalPolicy: .immediate) }
        }

        let attributes = BuildActivityAttributes(projectName: projectName, startedAt: Date())
        let content = ActivityContent(state: State(phase: .uploading, step: "Загрузка архива"), staleDate: nil)
        activity = try? Activity.request(attributes: attributes, content: content)
    }

    func update(phase: State.Phase, step: String) async {
        guard let activity = activity else { return }
        await activity.update(ActivityContent(state: State(phase: phase, step: step), staleDate: nil))
    }

    /// Показывает итог (остров раскрывается с вибрацией) и оставляет его на экране ещё на время.
    func finish(success: Bool, detail: String) async {
        guard let current = activity else { return }
        activity = nil

        let content = ActivityContent(state: State(phase: success ? .success : .failure, step: detail), staleDate: nil)
        let alert = AlertConfiguration(
            title: success ? "Сборка готова" : "Сборка не удалась",
            body: "Откройте «Сборщик»",
            sound: .default
        )
        await current.update(content, alertConfiguration: alert)

        // Через 5 минут убираем из острова (на экране блокировки итог останется ещё на 10 минут).
        Task {
            try? await Task.sleep(nanoseconds: 300_000_000_000)
            await current.end(content, dismissalPolicy: .after(Date().addingTimeInterval(600)))
        }
    }

    /// Тихо закрывает активность (например, если пользователь запустил другую сборку).
    func cancel() async {
        guard let current = activity else { return }
        activity = nil
        await current.end(nil, dismissalPolicy: .immediate)
    }
}

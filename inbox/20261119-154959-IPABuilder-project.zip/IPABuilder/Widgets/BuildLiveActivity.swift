import ActivityKit
import SwiftUI
import WidgetKit

@main
struct BuildWidgetsBundle: WidgetBundle {
    var body: some Widget {
        BuildLiveActivity()
    }
}

private extension BuildActivityAttributes.ContentState {
    var isRunning: Bool {
        phase != .success && phase != .failure
    }

    var symbol: String {
        switch phase {
        case .uploading: return "arrow.up.circle.fill"
        case .waiting: return "clock.fill"
        case .building: return "hammer.fill"
        case .success: return "checkmark.circle.fill"
        case .failure: return "xmark.octagon.fill"
        }
    }

    var tint: Color {
        switch phase {
        case .success: return .green
        case .failure: return .red
        default: return .orange
        }
    }

    var finishedLabel: String {
        phase == .success ? "Готово" : "Ошибка"
    }
}

struct BuildLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: BuildActivityAttributes.self) { context in
            BuildLockScreenView(context: context)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: context.state.symbol)
                        .font(.title2)
                        .foregroundStyle(context.state.tint)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if context.state.isRunning {
                        Text(context.attributes.startedAt, style: .timer)
                            .monospacedDigit()
                            .font(.subheadline.weight(.semibold))
                            .frame(width: 62, alignment: .trailing)
                    } else {
                        Text(context.state.finishedLabel)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(context.state.tint)
                    }
                }
                DynamicIslandExpandedRegion(.center) {
                    Text(context.attributes.projectName)
                        .font(.headline)
                        .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text(context.state.step)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            } compactLeading: {
                Image(systemName: context.state.symbol)
                    .foregroundStyle(context.state.tint)
            } compactTrailing: {
                if context.state.isRunning {
                    Text(context.attributes.startedAt, style: .timer)
                        .monospacedDigit()
                        .font(.caption2)
                        .frame(width: 44)
                } else {
                    Image(systemName: context.state.phase == .success ? "checkmark" : "xmark")
                        .foregroundStyle(context.state.tint)
                }
            } minimal: {
                Image(systemName: context.state.symbol)
                    .foregroundStyle(context.state.tint)
            }
        }
    }
}

struct BuildLockScreenView: View {
    let context: ActivityViewContext<BuildActivityAttributes>

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: context.state.symbol)
                .font(.system(size: 28))
                .foregroundStyle(context.state.tint)

            VStack(alignment: .leading, spacing: 2) {
                Text(context.attributes.projectName)
                    .font(.headline)
                    .lineLimit(1)
                Text(context.state.step)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            if context.state.isRunning {
                Text(context.attributes.startedAt, style: .timer)
                    .monospacedDigit()
                    .font(.title3.weight(.semibold))
                    .frame(width: 70, alignment: .trailing)
            }
        }
        .padding(16)
    }
}

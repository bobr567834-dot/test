import Foundation
import UIKit

@MainActor
final class BuilderModel: ObservableObject {
    enum Phase { case idle, uploading, waitingForRun, running, finished }

    private static let connectionsKey = "builder.connections.v1"
    private static let activeKey = "builder.activeConnection"

    // MARK: Настройки и репозитории

    /// Сохранённые подключения (репозиторий + токен в Keychain).
    @Published var connections: [RepoConnection] {
        didSet { Self.saveConnections(connections) }
    }
    @Published var activeID: UUID? {
        didSet { UserDefaults.standard.set(activeID?.uuidString, forKey: Self.activeKey) }
    }
    /// Включён режим добавления нового репозитория (поля формы пустые).
    @Published var isAddingNew = false
    private var isLoadingFields = false

    /// Поля формы для выбранного подключения: токен и репозиторий можно править.
    @Published var token: String {
        didSet { if !isLoadingFields { isConfigured = false } }
    }
    @Published var repoFull: String {
        didSet { if !isLoadingFields { isConfigured = false } }
    }
    /// Подключён ли выбранный репозиторий (и не изменены ли поля после проверки).
    @Published var isConfigured: Bool
    @Published var setupMessage: String?
    @Published var setupIsError = false
    @Published var isSettingUp = false

    // MARK: Режим загрузки и параметры генерируемого проекта

    @Published var mode: UploadMode {
        didSet { UserDefaults.standard.set(mode.rawValue, forKey: "builder.mode") }
    }
    @Published var appName: String {
        didSet { UserDefaults.standard.set(appName, forKey: "builder.appName") }
    }
    @Published var bundleID: String {
        didSet { UserDefaults.standard.set(bundleID, forKey: "builder.bundleID") }
    }
    @Published var platformChoice: PlatformChoice {
        didSet { UserDefaults.standard.set(platformChoice.rawValue, forKey: "builder.platform") }
    }
    @Published var iosVersion: String {
        didSet { UserDefaults.standard.set(iosVersion, forKey: "builder.iosVersion") }
    }
    @Published var watchVersion: String {
        didSet { UserDefaults.standard.set(watchVersion, forKey: "builder.watchVersion") }
    }
    @Published var themeChoice: ThemeChoice {
        didSet { UserDefaults.standard.set(themeChoice.rawValue, forKey: "builder.theme") }
    }

    // MARK: Исходники (режим «Только исходники»)

    @Published var pickedFiles: [PickedFile] = []
    @Published var sourceSummary: SourceSummary?
    @Published var pickedFolderName: String?

    // MARK: Встроенный редактор кода

    @Published var editorFiles: [EditorFile] {
        didSet { saveEditorFiles() }
    }
    @Published var selectedTab = 0
    /// Последняя сборка была запущена из редактора (чтобы предложить вернуться к коду).
    @Published var lastBuildWasEditor = false
    @Published var isDeleting = false

    /// Пояснение о том, что приложение добавило само (например, точку входа @main).
    @Published var buildNotice: String?

    // MARK: Сборка

    @Published var zipName: String?
    @Published var zipData: Data?
    @Published var phase: Phase = .idle
    @Published var statusText = ""
    @Published var run: RunInfo?
    @Published var jobs: [JobInfo] = []
    @Published var errorLines: [String] = []
    @Published var failedStep: String?
    @Published var errorText: String?
    @Published var ipaURL: URL?
    @Published var history: [RunInfo] = []

    private var pollTask: Task<Void, Never>?

    init() {
        let d = UserDefaults.standard

        // Подключения. Старая единственная настройка (репозиторий + токен) переносится в первое подключение.
        var saved = Self.loadConnections()
        var activeUUID = d.string(forKey: Self.activeKey).flatMap { UUID(uuidString: $0) }
        let legacyRepo = d.string(forKey: "builder.repo") ?? ""
        if saved.isEmpty, !legacyRepo.isEmpty {
            let legacy = RepoConnection(repo: legacyRepo, isConfigured: d.bool(forKey: "builder.configured"))
            if let oldToken = Keychain.load() {
                Keychain.save(oldToken, account: Self.tokenAccount(legacy.id))
            }
            saved = [legacy]
            activeUUID = legacy.id
        }
        if activeUUID == nil || !saved.contains(where: { $0.id == activeUUID }) {
            activeUUID = saved.first?.id
        }
        connections = saved
        activeID = activeUUID
        token = ""
        repoFull = ""
        isConfigured = false

        mode = UploadMode(rawValue: d.string(forKey: "builder.mode") ?? "") ?? .archive
        appName = d.string(forKey: "builder.appName") ?? ""
        bundleID = d.string(forKey: "builder.bundleID") ?? ""
        platformChoice = PlatformChoice(rawValue: d.string(forKey: "builder.platform") ?? "") ?? .auto
        iosVersion = d.string(forKey: "builder.iosVersion") ?? "16.0"
        watchVersion = d.string(forKey: "builder.watchVersion") ?? "9.0"
        themeChoice = ThemeChoice(rawValue: d.string(forKey: "builder.theme") ?? "") ?? .system
        editorFiles = Self.loadEditorFiles()

        // Поля формы берём из выбранного подключения.
        loadFields(for: saved.first(where: { $0.id == activeUUID }))
    }

    /// Готово ли то, что нужно отправить на сборку, в текущем режиме.
    var isReadyToBuild: Bool {
        switch mode {
        case .archive: return zipData != nil
        case .sources: return !pickedFiles.isEmpty
        }
    }

    var effectivePlatform: BuildPlatform {
        switch platformChoice {
        case .auto: return sourceSummary?.platform ?? .ios
        case .ios: return .ios
        case .watchos: return .watchos
        }
    }

    /// Название, которое увидит пользователь под иконкой.
    var displayName: String {
        let typed = appName.trimmed
        if !typed.isEmpty { return typed }
        return pickedFolderName ?? "App"
    }

    var isBusy: Bool {
        phase == .uploading || phase == .waitingForRun || phase == .running
    }

    /// Шаги без служебных («Set up job», «Complete job», «Post …»).
    var visibleSteps: [StepInfo] {
        (jobs.first?.steps ?? []).filter {
            !$0.name.hasPrefix("Set up job") && !$0.name.hasPrefix("Complete job") && !$0.name.hasPrefix("Post ")
        }
    }

    private func makeClient() throws -> GitHubClient {
        let t = token.trimmed
        let parts = repoFull.trimmed.split(separator: "/").map(String.init)
        guard !t.isEmpty else {
            throw GitHubError(message: "Введите токен GitHub во вкладке «Настройка».")
        }
        guard parts.count == 2, !parts[0].isEmpty, !parts[1].isEmpty else {
            throw GitHubError(message: "Репозиторий нужно указать как владелец/имя, например ivan/ipa-builder.")
        }
        return GitHubClient(token: t, owner: parts[0], repo: parts[1])
    }

    // MARK: - Репозитории

    private static func tokenAccount(_ id: UUID) -> String {
        "token-\(id.uuidString)"
    }

    private static func loadConnections() -> [RepoConnection] {
        guard let data = UserDefaults.standard.data(forKey: connectionsKey),
              let list = try? JSONDecoder().decode([RepoConnection].self, from: data) else { return [] }
        return list
    }

    private static func saveConnections(_ list: [RepoConnection]) {
        if let data = try? JSONEncoder().encode(list) {
            UserDefaults.standard.set(data, forKey: connectionsKey)
        }
    }

    /// Название выбранного репозитория для переключателей.
    var activeRepoTitle: String {
        if isAddingNew { return "Новый репозиторий" }
        if let id = activeID, let connection = connections.first(where: { $0.id == id }) {
            return connection.repo
        }
        return "Репозиторий не выбран"
    }

    /// Заполняет поля формы данными подключения (nil — пустая форма для нового репозитория, токен сохраняется).
    private func loadFields(for connection: RepoConnection?) {
        isLoadingFields = true
        defer { isLoadingFields = false }

        if let connection = connection {
            token = Keychain.load(account: Self.tokenAccount(connection.id)) ?? ""
            repoFull = connection.repo
            isConfigured = connection.isConfigured
        } else {
            repoFull = ""
            isConfigured = false
        }
    }

    func selectConnection(_ id: UUID) {
        guard !isBusy, let connection = connections.first(where: { $0.id == id }) else { return }
        isAddingNew = false
        activeID = id
        loadFields(for: connection)
        setupMessage = nil

        pollTask?.cancel()
        resetBuildState()
        history = []
        Task { await refreshHistory() }
    }

    func beginAddingConnection() {
        guard !isBusy else { return }
        isAddingNew = true
        setupMessage = nil
        loadFields(for: nil)
    }

    func cancelAddingConnection() {
        isAddingNew = false
        setupMessage = nil
        loadFields(for: connections.first(where: { $0.id == activeID }))
    }

    func deleteConnection(_ id: UUID) {
        guard !isBusy else { return }
        Keychain.delete(account: Self.tokenAccount(id))
        connections.removeAll { $0.id == id }

        guard activeID == id else { return }
        if let first = connections.first {
            selectConnection(first.id)
        } else {
            activeID = nil
            isAddingNew = false
            loadFields(for: nil)
            isLoadingFields = true
            token = ""
            isLoadingFields = false
            pollTask?.cancel()
            resetBuildState()
            history = []
        }
    }

    /// Добавляет новое подключение или обновляет выбранное (если репозиторий уже есть в списке — обновляет его).
    private func saveConnection(repo: String, token tokenValue: String) {
        let target: UUID
        if !isAddingNew, let id = activeID, connections.contains(where: { $0.id == id }) {
            target = id
        } else if let existing = connections.first(where: { $0.repo.lowercased() == repo.lowercased() }) {
            target = existing.id
        } else {
            target = UUID()
            connections.append(RepoConnection(id: target, repo: repo, isConfigured: true))
        }

        if let index = connections.firstIndex(where: { $0.id == target }) {
            connections[index].repo = repo
            connections[index].isConfigured = true
        }
        Keychain.save(tokenValue, account: Self.tokenAccount(target))
        activeID = target
    }

    // MARK: - Настройка

    func setup() {
        Task {
            isSettingUp = true
            setupMessage = nil
            setupIsError = false
            defer { isSettingUp = false }

            do {
                let client = try makeClient()
                let login = try await client.currentUser()
                var created = false

                let exists = try await client.repositoryExists()
                if !exists {
                    guard login.lowercased() == client.owner.lowercased() else {
                        throw GitHubError(message: "Репозиторий не найден. Создать его можно только в своём аккаунте (\(login)).")
                    }
                    try await client.createRepository()
                    created = true
                    try await Task.sleep(nanoseconds: 3_000_000_000)
                }

                var lastError: Error?
                for attempt in 0..<4 {
                    do {
                        try await client.installWorkflow()
                        lastError = nil
                        break
                    } catch {
                        lastError = error
                        if attempt < 3 { try await Task.sleep(nanoseconds: 2_000_000_000) }
                    }
                }
                if let lastError = lastError { throw lastError }

                saveConnection(repo: repoFull.trimmed, token: token.trimmed)
                isConfigured = true
                isAddingNew = false
                setupMessage = (created ? "Репозиторий создан (приватный). " : "")
                    + "Всё готово: аккаунт \(login), workflow установлен."
            } catch {
                setupMessage = error.localizedDescription
                setupIsError = true
            }
        }
    }

    // MARK: - Выбор архива

    func pickZip(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result, let url = urls.first else { return }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }

        guard let data = try? Data(contentsOf: url) else {
            errorText = "Не удалось прочитать файл."
            return
        }
        if data.count > 50_000_000 {
            errorText = "Архив больше 50 МБ — слишком большой для загрузки через API."
            return
        }
        zipData = data
        zipName = url.lastPathComponent
        errorText = nil
    }

    // MARK: - Сборка

    func startBuild() {
        guard !isBusy else { return }
        lastBuildWasEditor = false
        buildNotice = nil
        let data: Data
        let name: String

        switch mode {
        case .archive:
            guard let zip = zipData, let zipFileName = zipName else { return }
            data = zip
            name = zipFileName
        case .sources:
            do {
                let packed = try packageSources()
                data = packed.0
                name = packed.1
            } catch {
                errorText = error.localizedDescription
                return
            }
        }

        pollTask?.cancel()
        pollTask = Task { await runBuild(data: data, name: name) }
    }

    // MARK: - Удаление сборок

    func deleteBuild(_ info: RunInfo) {
        guard info.isFinished else {
            errorText = "Сборку нельзя удалить, пока она идёт."
            return
        }
        Task { await performDelete([info], removeAllLocal: false) }
    }

    func clearHistory() {
        let finished = history.filter { $0.isFinished }
        guard !finished.isEmpty else { return }
        Task { await performDelete(finished, removeAllLocal: true) }
    }

    private func performDelete(_ runs: [RunInfo], removeAllLocal: Bool) async {
        guard !isDeleting else { return }
        isDeleting = true
        defer { isDeleting = false }
        errorText = nil

        do {
            let client = try makeClient()
            var failures: [String] = []

            for info in runs {
                do {
                    try await client.deleteRelease(tag: "build-\(info.id)")
                    try await client.deleteRun(id: info.id)
                    if run?.id == info.id {
                        if let url = ipaURL { try? FileManager.default.removeItem(at: url) }
                        resetBuildState()
                    }
                } catch {
                    failures.append(error.localizedDescription)
                }
            }

            if removeAllLocal { removeLocalBuilds() }
            await refreshHistory()

            if let first = failures.first {
                errorText = "Не удалось удалить сборок: \(failures.count). \(first)"
            }
        } catch {
            errorText = error.localizedDescription
        }
    }

    /// Удаляет скачанные на телефон IPA (папка Builds).
    private func removeLocalBuilds() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        try? FileManager.default.removeItem(at: docs.appendingPathComponent("Builds", isDirectory: true))
        ipaURL = nil
    }

    // MARK: - Редактор кода

    private static let editorKey = "builder.editor.files.v1"

    private func saveEditorFiles() {
        if let data = try? JSONEncoder().encode(editorFiles) {
            UserDefaults.standard.set(data, forKey: Self.editorKey)
        }
    }

    private static func loadEditorFiles() -> [EditorFile] {
        if let data = UserDefaults.standard.data(forKey: editorKey),
           let files = try? JSONDecoder().decode([EditorFile].self, from: data) {
            return files
        }
        // Новый проект пустой: шаблоны добавляются только вручную (вкладка «Код» → «Шаблоны»).
        return []
    }

    private static func normalizedFileName(_ raw: String) -> String {
        var name = raw.trimmed.replacingOccurrences(of: "/", with: "-")
        if name.isEmpty { name = "NewFile" }
        if !name.contains(".") { name += ".swift" }
        return name
    }

    private func uniqueEditorName(_ base: String, excluding id: UUID? = nil) -> String {
        let existing = Set(editorFiles.filter { $0.id != id }.map { $0.name.lowercased() })
        if !existing.contains(base.lowercased()) { return base }

        let nsName = base as NSString
        let ext = nsName.pathExtension
        let stem = nsName.deletingPathExtension
        var index = 2
        while true {
            let candidate = ext.isEmpty ? "\(stem)\(index)" : "\(stem)\(index).\(ext)"
            if !existing.contains(candidate.lowercased()) { return candidate }
            index += 1
        }
    }

    func addEditorFile(named raw: String) {
        let name = uniqueEditorName(Self.normalizedFileName(raw))
        let text = name.hasSuffix(".swift") ? "import SwiftUI\n\n" : ""
        editorFiles.append(EditorFile(name: name, text: text))
    }

    func renameEditorFile(id: UUID, to raw: String) {
        guard let index = editorFiles.firstIndex(where: { $0.id == id }) else { return }
        editorFiles[index].name = uniqueEditorName(Self.normalizedFileName(raw), excluding: id)
    }

    /// Удаляет все файлы проекта.
    func clearEditorFiles() {
        editorFiles = []
    }

    /// Стирает весь код в одном файле (сам файл остаётся).
    func clearEditorFileText(id: UUID) {
        guard let index = editorFiles.firstIndex(where: { $0.id == id }) else { return }
        editorFiles[index].text = ""
    }

    func deleteEditorFile(id: UUID) {
        editorFiles.removeAll { $0.id == id }
    }

    func loadTemplate(_ template: EditorTemplate) {
        editorFiles = template.files.map { EditorFile(name: $0.name, text: $0.text) }
    }

    /// Собирает проект из файлов редактора и запускает сборку.
    func startEditorBuild() {
        guard !isBusy else { return }
        errorText = nil
        buildNotice = nil

        let files = editorFiles.map { PickedFile(path: $0.name, data: Data($0.text.utf8)) }
        guard !files.isEmpty else {
            errorText = "Добавьте хотя бы один файл."
            return
        }

        let summary = ProjectScaffold.analyze(files)
        let title = appName.trimmed.isEmpty ? "MyApp" : appName.trimmed
        do {
            let packed = try packageSources(files: files, summary: summary, name: title)
            lastBuildWasEditor = true
            selectedTab = 0
            pollTask?.cancel()
            pollTask = Task { await runBuild(data: packed.0, name: packed.1) }
        } catch {
            errorText = error.localizedDescription
        }
    }

    // MARK: - Исходники

    func pickSourceFiles(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result else { return }
        var files = pickedFiles
        for url in urls {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            guard let data = try? Data(contentsOf: url) else { continue }
            let name = url.lastPathComponent
            files.removeAll { $0.path == name }
            files.append(PickedFile(path: name, data: data))
        }
        setPicked(files)
    }

    func pickSourceFolder(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result, let root = urls.first else { return }
        let scoped = root.startAccessingSecurityScopedResource()
        defer { if scoped { root.stopAccessingSecurityScopedResource() } }

        let rootCount = root.resolvingSymlinksInPath().pathComponents.count
        guard let enumerator = FileManager.default.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else {
            errorText = "Не удалось открыть папку."
            return
        }

        let skipped: Set<String> = ["build", "DerivedData", "xcuserdata", "Pods"]
        var files: [PickedFile] = []
        var total = 0

        for case let url as URL in enumerator {
            let components = url.resolvingSymlinksInPath().pathComponents
            guard components.count > rootCount else { continue }
            let relative = Array(components[rootCount...])
            if relative.contains(where: { skipped.contains($0) }) { continue }

            let isFile = (try? url.resourceValues(forKeys: [.isRegularFileKey]))?.isRegularFile ?? false
            guard isFile, let data = try? Data(contentsOf: url) else { continue }

            total += data.count
            if total > Self.maxSourceBytes {
                errorText = "Папка больше 40 МБ — слишком много для загрузки через API."
                return
            }
            files.append(PickedFile(path: relative.joined(separator: "/"), data: data))
        }

        pickedFolderName = root.lastPathComponent
        pickedFiles = []
        setPicked(files)
    }

    func clearSources() {
        pickedFiles = []
        sourceSummary = nil
        pickedFolderName = nil
        errorText = nil
    }

    private static let maxSourceBytes = 40_000_000

    private func setPicked(_ files: [PickedFile]) {
        let total = files.reduce(0) { $0 + $1.data.count }
        if total > Self.maxSourceBytes {
            errorText = "Файлы больше 40 МБ — слишком много для загрузки через API."
            return
        }
        pickedFiles = files
        sourceSummary = files.isEmpty ? nil : ProjectScaffold.analyze(files)
        errorText = nil
    }

    /// Собирает из выбранных файлов zip: добавляет project.yml (если проекта ещё нет).
    private func packageSources() throws -> (Data, String) {
        guard let summary = sourceSummary, !pickedFiles.isEmpty else {
            throw GitHubError(message: "Сначала выберите файлы приложения.")
        }
        return try packageSources(files: pickedFiles, summary: summary, name: displayName)
    }

    private func resolvePlatform(_ summary: SourceSummary) -> BuildPlatform {
        switch platformChoice {
        case .auto: return summary.platform
        case .ios: return .ios
        case .watchos: return .watchos
        }
    }

    /// Собирает zip из переданных файлов (используется и для выбранных файлов, и для встроенного редактора).
    private func packageSources(files inputFiles: [PickedFile], summary: SourceSummary, name: String) throws -> (Data, String) {
        let target = ProjectScaffold.targetName(from: name)
        var zip = ZipWriter()

        if summary.isCompleteProject {
            // Проект уже полный — отправляем как есть. Если есть project.yml,
            // старый .xcodeproj не нужен: его пересоздаст XcodeGen.
            let hasYML = inputFiles.contains { $0.path.lowercased().hasSuffix("project.yml") }
            for file in inputFiles {
                if hasYML && file.path.contains(".xcodeproj/") { continue }
                zip.add(path: "\(target)/\(file.path)", content: file.data)
            }
        } else {
            var notices: [String] = []

            // Нет @main — создаём точку входа сами, если нашёлся SwiftUI-экран.
            var autoEntry: (name: String, code: String)?
            if !summary.hasMain {
                guard let root = summary.rootViewName else {
                    throw GitHubError(message: "В файлах нет точки входа @main, и я не нашёл SwiftUI-экран (struct …: View), чтобы создать её автоматически. Добавьте файл с @main или экран.")
                }
                let usedNames = Set(inputFiles.map { $0.path.split(separator: "/").last.map(String.init) ?? $0.path })
                var entryName = "AutoApp.swift"
                var number = 2
                while usedNames.contains(entryName) {
                    entryName = "AutoApp\(number).swift"
                    number += 1
                }
                autoEntry = (entryName, ProjectScaffold.entrySource(rootView: root))
                notices.append("Точка входа @main добавлена автоматически (файл \(entryName)): приложение открывается с экрана \(root).")
            }
            if summary.mainCount > 1 {
                throw GitHubError(message: "Найдено несколько @main (\(summary.mainCount)). В приложении должна быть одна точка входа — проверьте, не выбраны ли файлы от разных приложений.")
            }
            let platform = resolvePlatform(summary)
            var files = inputFiles.filter { ($0.path.split(separator: "/").last.map(String.init)) != "Info.plist" }
            if !files.isEmpty && files.allSatisfy({ $0.path.hasPrefix("Sources/") }) {
                files = files.map { PickedFile(path: String($0.path.dropFirst("Sources/".count)), data: $0.data) }
            }
            // Дописываем недостающие import в файлах (в том числе из редактора).
            let fixed = ImportFixer.fix(files, platform: platform)
            files = fixed.files
            if let note = fixed.note { notices.append(note) }

            for file in files {
                zip.add(path: "\(target)/Sources/\(file.path)", content: file.data)
            }
            if let entry = autoEntry {
                zip.add(path: "\(target)/Sources/\(entry.name)", content: Data(entry.code.utf8))
            }
            buildNotice = notices.isEmpty ? nil : notices.joined(separator: "\n")

            let yaml = ProjectScaffold.yaml(
                targetName: target,
                displayName: name,
                bundleID: ProjectScaffold.validBundleID(bundleID, fallbackTarget: target),
                platform: platform,
                iosVersion: iosVersion,
                watchVersion: watchVersion,
                theme: themeChoice,
                permissions: summary.permissions,
                iconName: summary.appIconName
            )
            // Пустой файл нужен, чтобы папка Resources существовала до запуска XcodeGen (там создаётся Info.plist).
            zip.add(path: "\(target)/Resources/.gitkeep", content: Data())
            zip.add(path: "\(target)/project.yml", content: Data(yaml.utf8))
        }
        return (zip.finish(), "\(target).zip")
    }

    func openRun(_ info: RunInfo) {
        pollTask?.cancel()
        resetBuildState()
        run = info
        pollTask = Task {
            guard let client = try? makeClient() else { return }
            await track(client: client, runID: info.id)
        }
    }

    func refreshHistory() async {
        guard isConfigured, let client = try? makeClient() else { return }
        if let runs = try? await client.recentRuns() { history = runs }
    }

    private func resetBuildState() {
        run = nil
        jobs = []
        errorLines = []
        failedStep = nil
        errorText = nil
        ipaURL = nil
        statusText = ""
        phase = .idle
    }

    private func runBuild(data: Data, name: String) async {
        resetBuildState()
        do {
            let client = try makeClient()

            phase = .uploading
            statusText = "Загружаю архив в GitHub…"
            let path = "inbox/\(Self.timestamp())-\(Self.safeFileName(name))"
            let commitSHA = try await client.putFile(path: path, data: data, message: "Build \(name)", sha: nil)

            phase = .waitingForRun
            statusText = "Жду запуск сборки…"
            var found: RunInfo?
            for _ in 0..<20 {
                if Task.isCancelled { return }
                found = try await client.findRun(headSHA: commitSHA)
                if found != nil { break }
                try await Task.sleep(nanoseconds: 3_000_000_000)
            }
            guard let started = found else {
                throw GitHubError(message: "Сборка не запустилась. Проверьте, что workflow установлен («Настройка») и в репозитории включены GitHub Actions.")
            }
            run = started
            await track(client: client, runID: started.id)
        } catch {
            errorText = error.localizedDescription
            phase = .idle
        }
    }

    private func track(client: GitHubClient, runID: Int) async {
        phase = .running
        var failures = 0
        while !Task.isCancelled {
            do {
                let current = try await client.run(id: runID)
                run = current
                jobs = try await client.jobs(runID: runID)
                failures = 0

                if current.isFinished {
                    await finish(client: client, run: current)
                    return
                }
                let activeStep = visibleSteps.first(where: { $0.status == "in_progress" })?.name
                statusText = activeStep ?? current.statusLabel
            } catch {
                failures += 1
                if failures >= 5 {
                    errorText = error.localizedDescription
                    phase = .idle
                    return
                }
            }
            try? await Task.sleep(nanoseconds: 6_000_000_000)
        }
    }

    private func finish(client: GitHubClient, run: RunInfo) async {
        if run.isSuccess {
            statusText = "Скачиваю IPA…"
            do {
                var assets: [AssetInfo] = []
                for _ in 0..<5 {
                    assets = try await client.releaseAssets(tag: "build-\(run.id)")
                    if !assets.isEmpty { break }
                    try await Task.sleep(nanoseconds: 3_000_000_000)
                }
                guard let asset = assets.first(where: { $0.name.lowercased().hasSuffix(".ipa") }) else {
                    throw GitHubError(message: "Сборка прошла, но IPA в релизе не найден.")
                }
                let data = try await client.downloadAsset(id: asset.id)

                let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let dir = docs.appendingPathComponent("Builds", isDirectory: true)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let url = dir.appendingPathComponent(asset.name)
                try data.write(to: url, options: .atomic)
                ipaURL = url
                statusText = "Готово"
            } catch {
                errorText = error.localizedDescription
            }
        } else {
            statusText = "Сборка не удалась"
            await loadFailure(client: client)
        }
        phase = .finished
        await refreshHistory()
    }

    private func loadFailure(client: GitHubClient) async {
        guard let job = jobs.first(where: { $0.conclusion == "failure" }) ?? jobs.first else { return }
        failedStep = job.steps.first(where: { $0.conclusion == "failure" })?.name
        if let log = try? await client.jobLog(jobID: job.id) {
            errorLines = Self.extractErrors(from: log)
        }
    }

    // MARK: - Помощники

    private static func timestamp() -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmmss"
        return f.string(from: Date())
    }

    private static func safeFileName(_ name: String) -> String {
        let allowed = Set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        var out = String(name.map { allowed.contains($0) ? $0 : "-" })
        if !out.lowercased().hasSuffix(".zip") { out += ".zip" }
        return out
    }

    /// Вытаскивает из лога строки с ошибками: компилятор, линковщик, xcodebuild.
    /// Строки с текстом команд (`echo "error: …"`) пропускаются — это не ошибки.
    static func extractErrors(from log: String) -> [String] {
        func clean(_ line: String) -> String {
            var s = line.replacingOccurrences(of: #"^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s?"#, with: "", options: .regularExpression)
            s = s.replacingOccurrences(of: #"(\u001B)?\[[0-9;]+m"#, with: "", options: .regularExpression)
            s = s.replacingOccurrences(of: #"/Users/runner/work/[^/]+/[^/]+/work/"#, with: "", options: .regularExpression)
            s = s.replacingOccurrences(of: #"^[A-Za-z0-9_]+/Sources/"#, with: "", options: .regularExpression)
            return s.trimmed
        }

        let lines = log.split(whereSeparator: { $0.isNewline }).map { clean(String($0)) }
        var seen = Set<String>()
        var result: [String] = []

        func add(_ line: String) {
            if !line.isEmpty, result.count < 40, seen.insert(line).inserted { result.append(line) }
        }

        for (index, line) in lines.enumerated() {
            if line.hasPrefix("echo ") || line.contains("echo \"error:") { continue }

            let linkerHeader = line.hasPrefix("Undefined symbols")
                || line.hasPrefix("duplicate symbol")
                || (line.hasPrefix("ld:") && !line.hasPrefix("ld: warning"))

            if linkerHeader {
                // Вместе с заголовком берём следующие строки: там перечислены сами символы.
                for next in index..<min(index + 6, lines.count) { add(lines[next]) }
            } else if line.contains("error:") || line.contains("fatal error")
                        || line.hasPrefix("##[error]") || line.contains("** BUILD FAILED **") {
                add(line)
            }
        }

        if result.isEmpty {
            result = lines
                .filter { !$0.isEmpty && !$0.hasPrefix("##[group]") && !$0.hasPrefix("##[endgroup]") }
                .suffix(30)
                .map { $0 }
        }
        return result
    }
}

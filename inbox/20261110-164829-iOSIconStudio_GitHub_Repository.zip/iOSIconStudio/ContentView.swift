import SwiftUI
import UniformTypeIdentifiers

struct IconConfig: Identifiable, Codable {
    var id = UUID()
    var title: String = "My App"
    var targetURL: String = "https://apple.com"
    var emoji: String = "⚡️"
    var bgHex1: String = "6366F1"
    var bgHex2: String = "A855F7"
    var isGradient: Bool = true
}

@main
struct iOSIconStudioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var icons: [IconConfig] = [IconConfig()]
    @State private var selectedIndex: Int = 0
    @State private var showingExportSheet = false
    @State private var exportedURL: URL?

    var currentIcon: IconConfig {
        if icons.indices.contains(selectedIndex) {
            return icons[selectedIndex]
        }
        return IconConfig()
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // iPhone Preview Area
                VStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .fill(LinearGradient(colors: [.black.opacity(0.8), .black], startPoint: .top, endPoint: .bottom))
                            .frame(width: 220, height: 280)
                            .shadow(color: .black.opacity(0.3), radius: 15, x: 0, y: 10)
                        
                        VStack(spacing: 12) {
                            // Icon Squircle Preview
                            ZStack {
                                if currentIcon.isGradient {
                                    LinearGradient(
                                        colors: [Color(hex: currentIcon.bgHex1), Color(hex: currentIcon.bgHex2)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                } else {
                                    Color(hex: currentIcon.bgHex1)
                                }
                                
                                Text(currentIcon.emoji)
                                    .font(.system(size: 44))
                            }
                            .frame(width: 80, height: 80)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .shadow(radius: 4)

                            Text(currentIcon.title.isEmpty ? "App Title" : currentIcon.title)
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 20)
                .background(Color(UIColor.secondarySystemBackground))

                // Editor Form
                Form {
                    Section(header: Text("Иконки в паке")) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(Array(icons.enumerated()), id: \.element.id) { index, icon in
                                    Button(action: { selectedIndex = index }) {
                                        Text(icon.emoji.isEmpty ? "📱" : icon.emoji)
                                            .font(.title2)
                                            .frame(width: 50, height: 50)
                                            .background(selectedIndex == index ? Color.accentColor.opacity(0.2) : Color(UIColor.tertiarySystemFill))
                                            .cornerRadius(12)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 12)
                                                    .stroke(selectedIndex == index ? Color.accentColor : Color.clear, lineWidth: 2)
                                            )
                                    }
                                }
                                
                                Button(action: {
                                    icons.append(IconConfig(title: "New Icon \(icons.count + 1)"))
                                    selectedIndex = icons.count - 1
                                }) {
                                    Image(systemName: "plus")
                                        .font(.title2)
                                        .frame(width: 50, height: 50)
                                        .background(Color(UIColor.tertiarySystemFill))
                                        .cornerRadius(12)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }

                    Section(header: Text("Параметры иконки")) {
                        HStack {
                            Text("Название:")
                            TextField("My App", text: $icons[selectedIndex].title)
                                .multilineTextAlignment(.trailing)
                        }
                        
                        HStack {
                            Text("Ссылка (URL):")
                            TextField("https://...", text: $icons[selectedIndex].targetURL)
                                .keyboardType(.URL)
                                .autocapitalization(.none)
                                .multilineTextAlignment(.trailing)
                        }
                        
                        HStack {
                            Text("Эмодзи / Иконка:")
                            TextField("⚡️", text: $icons[selectedIndex].emoji)
                                .multilineTextAlignment(.trailing)
                        }
                    }

                    Section(header: Text("Дизайн")) {
                        Toggle("Градиент", isOn: $icons[selectedIndex].isGradient)
                        
                        ColorPicker("Основной цвет", selection: Binding(
                            get: { Color(hex: currentIcon.bgHex1) },
                            set: { icons[selectedIndex].bgHex1 = $0.toHex() }
                        ))
                        
                        if currentIcon.isGradient {
                            ColorPicker("Второй цвет", selection: Binding(
                                get: { Color(hex: currentIcon.bgHex2) },
                                set: { icons[selectedIndex].bgHex2 = $0.toHex() }
                            ))
                        }
                    }

                    Section {
                        Button(action: exportMobileConfig) {
                            HStack {
                                Spacer()
                                Image(systemName: "arrow.down.doc.fill")
                                Text("Экспортировать .mobileconfig")
                                    .bold()
                                Spacer()
                            }
                        }
                        .foregroundColor(.white)
                        .listRowBackground(Color.accentColor)
                    }
                }
            }
            .navigationTitle("Icon Studio")
            .sheet(isPresented: $showingExportSheet) {
                if let url = exportedURL {
                    ShareSheet(activityItems: [url])
                }
            }
        }
    }

    func exportMobileConfig() {
        let profileUUID = UUID().uuidString
        var payloadContent = ""

        for icon in icons {
            let itemUUID = UUID().uuidString
            let svgIcon = """
            <svg xmlns="http://www.w3.org/2000/svg" width="144" height="144" viewBox="0 0 144 144">
                <rect width="144" height="144" fill="#\(icon.bgHex1)"/>
                <text x="72" y="90" font-size="70" text-anchor="middle">\(icon.emoji)</text>
            </svg>
            """
            let base64Icon = Data(svgIcon.utf8).base64EncodedString()

            payloadContent += """
            <dict>
                <key>IsRemovable</key><true/>
                <key>Label</key><string>\(icon.title)</string>
                <key>PayloadDescription</key><string>Web Clip</string>
                <key>PayloadDisplayName</key><string>\(icon.title)</string>
                <key>PayloadIdentifier</key><string>com.studio.webclip.\(itemUUID)</string>
                <key>PayloadType</key><string>com.apple.webClip.managed</string>
                <key>PayloadUUID</key><string>\(itemUUID)</string>
                <key>PayloadVersion</key><integer>1</integer>
                <key>URL</key><string>\(icon.targetURL)</string>
                <key>Icon</key><data>\(base64Icon)</data>
            </dict>
            """
        }

        let fullConfig = """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
            <key>PayloadContent</key>
            <array>
                \(payloadContent)
            </array>
            <key>PayloadDisplayName</key><string>Custom Icon Pack</string>
            <key>PayloadIdentifier</key><string>com.studio.iconpack.\(profileUUID)</string>
            <key>PayloadRemovalDisallowed</key><false/>
            <key>PayloadType</key><string>Configuration</string>
            <key>PayloadUUID</key><string>\(profileUUID)</string>
            <key>PayloadVersion</key><integer>1</integer>
        </dict>
        </plist>
        """

        let fileManager = FileManager.default
        let tempDir = fileManager.temporaryDirectory
        let fileURL = tempDir.appendingPathComponent("icons.mobileconfig")

        do {
            try fullConfig.write(to: fileURL, atomically: true, encoding: .utf8)
            self.exportedURL = fileURL
            self.showingExportSheet = true
        } catch {
            print("Failed to generate profile: \(error)")
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r = Double((int >> 16) & 0xFF) / 255.0
        let g = Double((int >> 8) & 0xFF) / 255.0
        let b = Double(int & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }

    func toHex() -> String {
        guard let components = UIColor(self).cgColor.components, components.count >= 3 else {
            return "6366F1"
        }
        let r = Float(components[0])
        let g = Float(components[1])
        let b = Float(components[2])
        return String(format: "%02lX%02lX%02lX", lroundf(r * 255), lroundf(g * 255), lroundf(b * 255))
    }
}

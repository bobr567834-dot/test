import SwiftUI

struct ContentView: View {
    @State private var score: Double = 0.0
    @State private var clickPower: Double = 1.0
    @State private var autoClickerPower: Double = 0.0
    @State private var autoClickerCost: Double = 50.0
    @State private var clickUpgradeCost: Double = 25.0
    
    // Анимация пульсации ядра при клике
    @State private var coreScale: CGFloat = 1.0
    
    let timer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            // Тёмный фон в стиле iOS Dark Mode
            Color(.systemGroupedBackground)
                .ignoresSafeArea()

            VStack(spacing: 30) {
                // Шапка с балансом
                VStack(spacing: 6) {
                    Text("ЭНЕРГИЯ ЯДРА")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundColor(.secondary)
                    
                    Text("\(Int(score))")
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                    
                    if autoClickerPower > 0 {
                        Text("+\(Int(autoClickerPower))/сек")
                            .font(.subheadline)
                            .foregroundColor(.green)
                    }
                }
                .padding(.top, 20)

                Spacer()

                // Интерактивное ядро (кнопка)
                Button(action: {
                    score += clickPower
                    // Пружинящая анимация клика
                    withFactorySpring() {
                        coreScale = 1.15
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        withFactorySpring() {
                            coreScale = 1.0
                        }
                    }
                }) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 220, height: 220)
                            .shadow(color: .blue.opacity(0.5), radius: 20, x: 0, y: 10)
                        
                        Image(systemName: "bolt.fill")
                            .font(.system(size: 70))
                            .foregroundColor(.white)
                    }
                    .scaleEffect(coreScale)
                }
                .buttonStyle(PlainButtonStyle())

                Spacer()

                // Секция улучшений (в стиле iOS списка / карточек)
                VStack(spacing: 16) {
                    // Улучшение клика
                    UpgradeRow(
                        title: "Сила удара",
                        subtitle: "+\(Int(clickPower)) к клику",
                        cost: Int(clickUpgradeCost),
                        canAfford: score >= clickUpgradeCost
                    ) {
                        score -= clickUpgradeCost
                        clickPower += 1.0
                        clickUpgradeCost *= 1.5
                    }

                    // Автокликер
                    UpgradeRow(
                        title: "Квантовый генератор",
                        subtitle: "+\(Int(autoClickerPower + 1))/сек",
                        cost: Int(autoClickerCost),
                        canAfford: score >= autoClickerCost
                    ) {
                        score -= autoClickerCost
                        autoClickerPower += 1.0
                        autoClickerCost *= 1.6
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
        }
        // Автоматическое начисление очков каждую секунду
        .onReceive(timer) { _T in
            score += autoClickerPower
        }
    }
    
    private func withFactorySpring(_ body: () -> Void) {
        withAnimation(.interpolatingSpring(stiffness: 300, damping: 15)) {
            body()
        }
    }
}

// Вспомогательный компонент для строки улучшений
struct UpgradeRow: View {
    let title: String
    let subtitle: String
    let cost: Int
    let canAfford: Bool
    let action: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()

            Button(action: action) {
                Text("\(cost) ⚡")
                    .fontWeight(.semibold)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(canAfford ? Color.blue : Color.gray.opacity(0.3))
                    .foregroundColor(.white)
                    .cornerRadius(14)
            }
            .disabled(!canAfford)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(16)
    }
}

#Preview {
    ContentView()
}

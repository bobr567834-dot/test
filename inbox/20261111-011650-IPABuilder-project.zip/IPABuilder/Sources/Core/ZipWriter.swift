import Foundation

/// Минимальный ZIP-архиватор без сжатия (метод «stored»). Нужен, чтобы собрать из
/// отдельных файлов один архив, который workflow распакует командой unzip.
struct ZipWriter {
    private struct Entry {
        let name: Data
        let crc: UInt32
        let size: UInt32
        let offset: UInt32
    }

    private var body = Data()
    private var entries: [Entry] = []

    private static let crcTable: [UInt32] = (0..<256).map { index -> UInt32 in
        var c = UInt32(index)
        for _ in 0..<8 {
            c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1)
        }
        return c
    }

    private static func crc32(_ data: Data) -> UInt32 {
        var c: UInt32 = 0xFFFFFFFF
        for byte in data {
            c = crcTable[Int((c ^ UInt32(byte)) & 0xFF)] ^ (c >> 8)
        }
        return ~c
    }

    private static func le16(_ v: UInt16) -> Data {
        Data([UInt8(v & 0xFF), UInt8(v >> 8)])
    }

    private static func le32(_ v: UInt32) -> Data {
        Data([UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF), UInt8((v >> 16) & 0xFF), UInt8(v >> 24)])
    }

    // Дата 1980-01-01, время 00:00 (нулевой штамп не принимают некоторые распаковщики).
    private static let dosTime: UInt16 = 0
    private static let dosDate: UInt16 = 0x0021

    mutating func add(path: String, content: Data) {
        let name = Data(path.utf8)
        let crc = Self.crc32(content)
        let size = UInt32(content.count)
        let offset = UInt32(body.count)

        body.append(Self.le32(0x04034B50))      // сигнатура локального заголовка
        body.append(Self.le16(20))              // версия для распаковки
        body.append(Self.le16(0x0800))          // флаг: имя в UTF-8
        body.append(Self.le16(0))               // метод: stored
        body.append(Self.le16(Self.dosTime))
        body.append(Self.le16(Self.dosDate))
        body.append(Self.le32(crc))
        body.append(Self.le32(size))            // сжатый размер
        body.append(Self.le32(size))            // исходный размер
        body.append(Self.le16(UInt16(name.count)))
        body.append(Self.le16(0))               // длина extra
        body.append(name)
        body.append(content)

        entries.append(Entry(name: name, crc: crc, size: size, offset: offset))
    }

    func finish() -> Data {
        var out = body
        let directoryStart = UInt32(out.count)

        for entry in entries {
            out.append(Self.le32(0x02014B50))   // сигнатура записи каталога
            out.append(Self.le16(20))           // версия создателя
            out.append(Self.le16(20))           // версия для распаковки
            out.append(Self.le16(0x0800))
            out.append(Self.le16(0))
            out.append(Self.le16(Self.dosTime))
            out.append(Self.le16(Self.dosDate))
            out.append(Self.le32(entry.crc))
            out.append(Self.le32(entry.size))
            out.append(Self.le32(entry.size))
            out.append(Self.le16(UInt16(entry.name.count)))
            out.append(Self.le16(0))            // extra
            out.append(Self.le16(0))            // комментарий
            out.append(Self.le16(0))            // номер диска
            out.append(Self.le16(0))            // внутренние атрибуты
            out.append(Self.le32(0))            // внешние атрибуты
            out.append(Self.le32(entry.offset))
            out.append(entry.name)
        }

        let directorySize = UInt32(out.count) - directoryStart
        out.append(Self.le32(0x06054B50))       // конец каталога
        out.append(Self.le16(0))
        out.append(Self.le16(0))
        out.append(Self.le16(UInt16(entries.count)))
        out.append(Self.le16(UInt16(entries.count)))
        out.append(Self.le32(directorySize))
        out.append(Self.le32(directoryStart))
        out.append(Self.le16(0))
        return out
    }
}

import Foundation

enum UploadMode: String, CaseIterable {
    case archive, sources

    var title: String {
        switch self {
        case .archive: return "Готовый архив"
        case .sources: return "Только исходники"
        }
    }
}

enum PlatformChoice: String, CaseIterable {
    case auto, ios, watchos

    var title: String {
        switch self {
        case .auto: return "Авто"
        case .ios: return "iOS"
        case .watchos: return "watchOS"
        }
    }
}

enum ThemeChoice: String, CaseIterable {
    case system, light, dark

    var title: String {
        switch self {
        case .system: return "Системная"
        case .light: return "Светлая"
        case .dark: return "Тёмная"
        }
    }
}

enum BuildPlatform {
    case ios, watchos

    var title: String {
        switch self {
        case .ios: return "iOS"
        case .watchos: return "watchOS"
        }
    }
}

struct PickedFile {
    /// Относительный путь внутри выбранного набора файлов.
    let path: String
    let data: Data
}

enum AppPermission: CaseIterable {
    case bluetooth, location, camera, microphone, photos, localNetwork, faceID

    var title: String {
        switch self {
        case .bluetooth: return "Bluetooth"
        case .location: return "Геопозиция"
        case .camera: return "Камера"
        case .microphone: return "Микрофон"
        case .photos: return "Фото"
        case .localNetwork: return "Локальная сеть"
        case .faceID: return "Face ID"
        }
    }

    var infoKey: String {
        switch self {
        case .bluetooth: return "NSBluetoothAlwaysUsageDescription"
        case .location: return "NSLocationWhenInUseUsageDescription"
        case .camera: return "NSCameraUsageDescription"
        case .microphone: return "NSMicrophoneUsageDescription"
        case .photos: return "NSPhotoLibraryUsageDescription"
        case .localNetwork: return "NSLocalNetworkUsageDescription"
        case .faceID: return "NSFaceIDUsageDescription"
        }
    }

    var usageText: String {
        switch self {
        case .bluetooth: return "Приложению нужен доступ к Bluetooth для работы с устройствами поблизости."
        case .location: return "Приложению нужна геопозиция для работы функций, связанных с сетью и местоположением."
        case .camera: return "Приложению нужен доступ к камере."
        case .microphone: return "Приложению нужен доступ к микрофону."
        case .photos: return "Приложению нужен доступ к вашим фото."
        case .localNetwork: return "Приложению нужен доступ к локальной сети для поиска устройств."
        case .faceID: return "Face ID нужен для подтверждения вашей личности."
        }
    }

    /// Фрагменты кода, по которым понятно, что разрешение нужно.
    var triggers: [String] {
        switch self {
        case .bluetooth: return ["import CoreBluetooth"]
        case .location: return ["import CoreLocation", "CNCopyCurrentNetworkInfo"]
        case .camera: return ["AVCaptureDevice", "AVCaptureSession"]
        case .microphone: return ["AVAudioRecorder", "requestRecordPermission"]
        case .photos: return ["PHPhotoLibrary"]
        case .localNetwork: return ["NWBrowser", "NWConnection", "NetService"]
        case .faceID: return ["LAContext"]
        }
    }
}

struct SourceSummary {
    let fileCount: Int
    let totalBytes: Int
    let platform: BuildPlatform
    let permissions: [AppPermission]
    let hasMain: Bool
    /// Сколько раз в коде встречается @main (должно быть ровно одно).
    let mainCount: Int
    /// Среди файлов уже есть project.yml или .xcodeproj — отправляем как есть.
    let isCompleteProject: Bool
    let appIconName: String?
}

enum ProjectScaffold {
    static func analyze(_ files: [PickedFile]) -> SourceSummary {
        var code = ""
        for file in files where file.path.hasSuffix(".swift") {
            code += String(decoding: file.data, as: UTF8.self)
            code += "\n"
        }

        let platform: BuildPlatform =
            (code.contains("import WatchKit") || code.contains("WKInterfaceDevice")) ? .watchos : .ios

        let permissions = AppPermission.allCases.filter { permission in
            permission.triggers.contains { code.contains($0) }
        }

        let complete = files.contains {
            $0.path.lowercased().hasSuffix("project.yml") || $0.path.contains(".xcodeproj/")
        }

        var iconName: String?
        for file in files {
            if let part = file.path.split(separator: "/").first(where: { $0.hasSuffix(".appiconset") }) {
                iconName = String(part.dropLast(".appiconset".count))
                break
            }
        }

        let mainCount = code
            .split(whereSeparator: { $0.isNewline })
            .filter { $0.trimmingCharacters(in: .whitespaces).hasPrefix("@main") }
            .count
        let hasMainFile = files.contains { ($0.path.split(separator: "/").last.map(String.init) ?? "") == "main.swift" }

        return SourceSummary(
            fileCount: files.count,
            totalBytes: files.reduce(0) { $0 + $1.data.count },
            platform: platform,
            permissions: permissions,
            hasMain: mainCount > 0 || hasMainFile,
            mainCount: mainCount,
            isCompleteProject: complete,
            appIconName: iconName
        )
    }

    /// Имя таргета: только латиница и цифры, не с цифры.
    static func targetName(from name: String) -> String {
        let cleaned = String(name.filter { $0.isASCII && ($0.isLetter || $0.isNumber) })
        if cleaned.isEmpty { return "App" }
        if let first = cleaned.first, first.isNumber { return "App" + cleaned }
        return cleaned
    }

    static func validBundleID(_ text: String, fallbackTarget: String) -> String {
        let candidate = text.trimmed
        let pattern = #"^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$"#
        if candidate.range(of: pattern, options: .regularExpression) != nil { return candidate }
        return "com.example." + fallbackTarget.lowercased()
    }

    private static func quote(_ s: String) -> String {
        let escaped = s
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        return "\"" + escaped + "\""
    }

    static func yaml(targetName: String,
                     displayName: String,
                     bundleID: String,
                     platform: BuildPlatform,
                     iosVersion: String,
                     watchVersion: String,
                     theme: ThemeChoice,
                     permissions: [AppPermission],
                     iconName: String?) -> String {
        var lines: [String] = []
        lines.append("name: \(targetName)")
        lines.append("options:")
        lines.append("  bundleIdPrefix: com.example")
        lines.append("  deploymentTarget:")
        switch platform {
        case .ios: lines.append("    iOS: \(quote(iosVersion))")
        case .watchos: lines.append("    watchOS: \(quote(watchVersion))")
        }
        lines.append("settings:")
        lines.append("  base:")
        lines.append("    SWIFT_VERSION: 5.0")
        lines.append("targets:")
        lines.append("  \(targetName):")
        lines.append("    type: application")
        lines.append("    platform: \(platform.title)")
        lines.append("    sources:")
        lines.append("      - Sources")
        lines.append("    info:")
        lines.append("      path: Resources/Info.plist")
        lines.append("      properties:")
        lines.append("        CFBundleDisplayName: \(quote(displayName))")

        switch platform {
        case .ios:
            lines.append("        UILaunchScreen: {}")
            switch theme {
            case .system: break
            case .light: lines.append("        UIUserInterfaceStyle: Light")
            case .dark: lines.append("        UIUserInterfaceStyle: Dark")
            }
        case .watchos:
            lines.append("        WKApplication: true")
            lines.append("        WKWatchOnly: true")
        }

        for permission in permissions {
            lines.append("        \(permission.infoKey): \(quote(permission.usageText))")
            if permission == .localNetwork {
                lines.append("        NSBonjourServices:")
                lines.append("          - _services._dns-sd._udp")
            }
        }

        lines.append("    settings:")
        lines.append("      base:")
        lines.append("        PRODUCT_BUNDLE_IDENTIFIER: \(bundleID)")
        lines.append("        INFOPLIST_KEY_UIApplicationSceneManifest_Generation: true")
        switch platform {
        case .ios:
            lines.append("        TARGETED_DEVICE_FAMILY: \"1\"")
            lines.append("        SUPPORTS_MACCATALYST: false")
        case .watchos:
            lines.append("        TARGETED_DEVICE_FAMILY: \"4\"")
        }
        if let iconName = iconName {
            lines.append("        ASSETCATALOG_COMPILER_APPICON_NAME: \(quote(iconName))")
        }
        return lines.joined(separator: "\n") + "\n"
    }
}

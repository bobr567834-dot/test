import SwiftUI

struct Panel<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(spacing: 0) { content }
            .background(Theme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Theme.line, lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.04), radius: 10, x: 0, y: 3)
    }
}

struct RowDivider: View {
    var body: some View {
        Rectangle()
            .fill(Theme.line)
            .frame(height: 1)
            .padding(.leading, 16)
    }
}

struct SectionLabel: View {
    let text: String

    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text)
            .font(.rounded(13, .semibold))
            .foregroundColor(Theme.inkSoft)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.top, 22)
            .padding(.bottom, 8)
    }
}

struct ScreenHeader: View {
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.rounded(34, .bold))
                .foregroundColor(Theme.ink)
            Text(subtitle)
                .font(.system(size: 15))
                .foregroundColor(Theme.inkSoft)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 24)
        .padding(.top, 28)
    }
}

struct FieldRow: View {
    let label: String
    @Binding var text: String
    var placeholder: String = ""
    var secure = false
    var mono = false

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.rounded(12, .medium))
                .foregroundColor(Theme.inkSoft)

            Group {
                if secure {
                    SecureField("", text: $text, prompt: Text(placeholder).foregroundColor(Theme.inkSoft.opacity(0.55)))
                } else {
                    TextField("", text: $text, prompt: Text(placeholder).foregroundColor(Theme.inkSoft.opacity(0.55)))
                }
            }
            .font(mono ? .mono(15) : .system(size: 16))
            .foregroundColor(Theme.ink)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct PillButton: View {
    let title: String
    let icon: String
    var filled = true
    var tint: Color = Theme.accent
    var enabled = true

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
            Text(title)
        }
        .font(.rounded(15, .semibold))
        .foregroundColor(filled ? (enabled ? .white : Theme.inkSoft) : Theme.ink)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(filled ? (enabled ? tint : Theme.track) : Theme.track)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

struct StepRow: View {
    let number: Int
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(number)")
                .font(.rounded(12, .bold))
                .foregroundColor(Theme.accent)
                .frame(width: 22, height: 22)
                .background(Theme.accent.opacity(0.12))
                .clipShape(Circle())
            Text(text)
                .font(.system(size: 14))
                .foregroundColor(Theme.ink)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
    }
}

/// Иконка состояния шага сборки.
struct StepIcon: View {
    let status: String
    let conclusion: String?

    var body: some View {
        Group {
            if status == "in_progress" {
                ProgressView()
                    .scaleEffect(0.8)
            } else if status == "completed" {
                switch conclusion {
                case "success":
                    Image(systemName: "checkmark.circle.fill").foregroundColor(Theme.success)
                case "failure":
                    Image(systemName: "xmark.circle.fill").foregroundColor(Theme.danger)
                default:
                    Image(systemName: "minus.circle").foregroundColor(Theme.inkSoft)
                }
            } else {
                Image(systemName: "circle").foregroundColor(Theme.inkSoft.opacity(0.5))
            }
        }
        .font(.system(size: 18))
        .frame(width: 24, height: 24)
    }
}

struct StatusChip: View {
    let run: RunInfo

    private var color: Color {
        if !run.isFinished { return Theme.accent }
        return run.isSuccess ? Theme.success : Theme.danger
    }

    var body: some View {
        Text(run.statusLabel)
            .font(.rounded(12, .semibold))
            .foregroundColor(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(color.opacity(0.12))
            .clipShape(Capsule())
    }
}

/// Сегментированный переключатель в стиле iOS: серая дорожка и белый «ползунок».
struct ChoiceBar<T: Hashable>: View {
    let options: [T]
    @Binding var selection: T
    let title: (T) -> String

    var body: some View {
        HStack(spacing: 2) {
            ForEach(options, id: \.self) { option in
                let selected = selection == option
                Button {
                    withAnimation(.easeOut(duration: 0.15)) { selection = option }
                } label: {
                    Text(title(option))
                        .font(.rounded(13, .semibold))
                        .foregroundColor(selected ? Theme.ink : Theme.inkSoft)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selected ? Color.white : Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                        .shadow(color: selected ? Color.black.opacity(0.1) : Color.clear, radius: 2, x: 0, y: 1)
                }
            }
        }
        .padding(3)
        .background(Theme.track)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

/// Подписанный блок с переключателем внутри панели.
struct ChoiceRow<T: Hashable>: View {
    let label: String
    let options: [T]
    @Binding var selection: T
    let title: (T) -> String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.rounded(12, .medium))
                .foregroundColor(Theme.inkSoft)
            ChoiceBar(options: options, selection: $selection, title: title)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

/// Строка «подпись — значение».
struct InfoRow: View {
    let label: String
    let value: String
    var valueColor: Color = Theme.ink

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label)
                .font(.system(size: 14))
                .foregroundColor(Theme.inkSoft)
            Spacer(minLength: 12)
            Text(value)
                .font(.rounded(14, .semibold))
                .foregroundColor(valueColor)
                .multilineTextAlignment(.trailing)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

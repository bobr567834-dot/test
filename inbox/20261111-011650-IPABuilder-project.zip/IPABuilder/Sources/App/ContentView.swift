import SwiftUI

struct ContentView: View {
    @EnvironmentObject var model: BuilderModel
    @State private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            BuildView()
                .tabItem { Label("Сборка", systemImage: "hammer.fill") }
                .tag(0)

            SettingsView()
                .tabItem { Label("Настройка", systemImage: "gearshape.fill") }
                .tag(1)
        }
        .tint(Theme.accent)
        .onAppear {
            if !model.isConfigured { tab = 1 }
        }
    }
}

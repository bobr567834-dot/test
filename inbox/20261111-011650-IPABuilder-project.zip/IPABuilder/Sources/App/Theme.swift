import SwiftUI

enum Theme {
    static let bg = Color(hex: 0xF2F4F8)
    static let surface = Color.white
    static let line = Color(hex: 0xE3E7EE)
    static let track = Color(hex: 0xE8ECF2)
    static let ink = Color(hex: 0x151A23)
    static let inkSoft = Color(hex: 0x6B7482)
    static let codeBG = Color(hex: 0xF6F7FA)
    static let danger = Color(hex: 0xD93025)
    static let success = Color(hex: 0x12A150)
    static let accent = Color(hex: 0xF26B1D)
}

extension Color {
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255
        let g = Double((hex >> 8) & 0xFF) / 255
        let b = Double(hex & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
}

extension Font {
    static func rounded(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .rounded)
    }

    static func mono(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .monospaced)
    }
}

struct ScreenBackground: View {
    var body: some View {
        ZStack {
            Theme.bg
            LinearGradient(
                colors: [Theme.accent.opacity(0.14), Theme.bg.opacity(0)],
                startPoint: .top,
                endPoint: UnitPoint(x: 0.5, y: 0.4)
            )
        }
    }
}

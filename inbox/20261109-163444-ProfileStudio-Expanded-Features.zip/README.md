# Profile Studio — Deluxe UI

A SwiftUI iOS app for creating, importing, editing, previewing, and exporting Apple configuration profiles (`.mobileconfig`).

## Interface and features
- Redesigned dashboard with profile overview, payload counts, quick-add cards, and validation status.
- Edit profile display name, identifier, organization, description, profile UUID, and removal restriction.
- Add, edit, duplicate, and delete payloads.
- Import unsigned XML or binary property-list `.mobileconfig` profiles.
- Preserve unknown imported payload dictionaries when re-exporting.
- Preview generated XML and export using the iOS Files/share interface.

## Payload types in this build
- Wi-Fi network
- Web Clip
- Encrypted DNS (DoH / DoT)
- Global HTTP Proxy
- CalDAV account

## Import limitations
- CMS/PKCS#7 signed profiles cannot be unwrapped by this iOS-only build. Export an unsigned XML or binary plist copy before importing.
- Unknown payloads are retained as raw dictionaries, but are not editable.
- Supported payloads are parsed into the app's editor model. Fields outside the editor's supported subset may not be retained when that payload is edited.

## GitHub Actions build
1. Upload the contents of this project folder to the repository root, or place the ZIP archive in `inbox/`.
2. Open **Actions** and run **Build iOS IPA**, or push to `main` / `master`.
3. Download the `ProfileStudio-unsigned-ipa` artifact.

The workflow:
- uses `runs-on: macos-15`;
- prints `xcodebuild -version` without selecting an Xcode version;
- installs XcodeGen with Homebrew and generates the `.xcodeproj` from `project.yml`;
- builds with `CODE_SIGNING_ALLOWED=NO` and `generic/platform=iOS`;
- packages `Payload/ProfileStudio.app` into `ProfileStudio.ipa`.

## Important
The IPA is unsigned and cannot be installed as-is. Sign it with your own valid Apple development/distribution credentials before installing. Configuration profiles can alter device settings. Review each profile before installing it. Wi-Fi and account credentials supplied in payloads are stored in the exported profile; protect the file accordingly.


## Automatic profile removal

The profile editor supports three removal modes:
- Never remove automatically.
- Remove after a duration (seconds, minutes, hours, or days).
- Remove at a selected date and time.

These options are written to the top-level `DurationUntilRemoval` and `RemovalDate` keys in the exported configuration profile. If both keys exist in an imported profile, iOS uses the earlier resulting removal time. The app itself does not run a background timer; iOS handles removal from the installed profile.

## Web Clip custom icons

- Choose an image from the Files app while adding or editing a Web Clip.
- PNG image data is embedded in the `Icon` key of the Web Clip payload.
- Images are converted to PNG and resized to a maximum dimension of 400 px and under 1 MB where possible.
- Existing imported Web Clip icons are loaded into the editor and preserved when saved.
- Optional `Precomposed` setting controls the iOS icon shine effect.


### Web Clip links
The Web Clip URL field accepts any non-empty link without URL-format validation.
Plain domains such as `youtube.com` automatically receive the `https://` prefix.
Links with an explicit scheme (for example `myapp://`, `tel:`, `https://`) are
kept as entered. Whether a custom scheme opens depends on support in the target app
and iOS.


## Additional tools
- Search payloads by title, type, or value.
- Reorder payloads with Move up / Move down actions.
- Copy the profile UUID and profile identifier from the action menu.
- Wi-Fi payloads support hidden-network configuration.
- Web Clip payloads include removable and manifest-scope options.
- Imported profile removal settings are restored in the editor.
- Exported profile metadata no longer contains a default “Created with Profile Studio” description.

import Foundation

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}

struct GitHubError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct RunInfo: Identifiable, Hashable {
    let id: Int
    let status: String
    let conclusion: String?
    let title: String
    let number: Int
    let created: Date?
    let htmlURL: String

    var isFinished: Bool { status == "completed" }
    var isSuccess: Bool { conclusion == "success" }

    var statusLabel: String {
        switch status {
        case "queued", "waiting", "pending", "requested": return "В очереди"
        case "in_progress": return "Идёт сборка"
        case "completed":
            switch conclusion {
            case "success": return "Готово"
            case "cancelled": return "Отменено"
            default: return "Ошибка"
            }
        default: return status
        }
    }
}

struct StepInfo: Identifiable, Hashable {
    let number: Int
    let name: String
    let status: String
    let conclusion: String?
    var id: Int { number }
}

struct JobInfo: Identifiable, Hashable {
    let id: Int
    let name: String
    let status: String
    let conclusion: String?
    let steps: [StepInfo]
}

struct AssetInfo {
    let id: Int
    let name: String
    let size: Int
}

/// Не переносит заголовок Authorization на другой хост при редиректе
/// (ссылки на скачивание логов и файлов — это подписанные адреса).
final class RedirectGuard: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession,
                    task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        var next = request
        if next.url?.host != task.originalRequest?.url?.host {
            next.setValue(nil, forHTTPHeaderField: "Authorization")
        }
        completionHandler(next)
    }
}

final class GitHubClient {
    let owner: String
    let repo: String
    private let token: String
    private let session: URLSession
    private static let iso = ISO8601DateFormatter()

    init(token: String, owner: String, repo: String) {
        self.token = token
        self.owner = owner
        self.repo = repo
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 60
        self.session = URLSession(configuration: config)
    }

    private var repoPath: String { "/repos/\(owner)/\(repo)" }

    // MARK: - Низкий уровень

    private func request(_ path: String,
                         method: String = "GET",
                         body: [String: Any]? = nil,
                         accept: String = "application/vnd.github+json") throws -> URLRequest {
        guard let url = URL(string: "https://api.github.com" + path) else {
            throw GitHubError(message: "Неверный адрес запроса.")
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue(accept, forHTTPHeaderField: "Accept")
        req.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        if let body = body {
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return req
    }

    /// Возвращает ответ при любом коде (без исключения).
    private func sendRaw(_ req: URLRequest) async throws -> (Data, Int) {
        let (data, response) = try await session.data(for: req, delegate: RedirectGuard())
        return (data, (response as? HTTPURLResponse)?.statusCode ?? 0)
    }

    /// Бросает исключение при коде вне 2xx.
    private func send(_ req: URLRequest) async throws -> Data {
        let (data, code) = try await sendRaw(req)
        guard (200..<300).contains(code) else {
            throw GitHubError(message: Self.describe(data, code: code))
        }
        return data
    }

    private static func json(_ data: Data) -> [String: Any] {
        (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
    }

    private static func describe(_ data: Data, code: Int) -> String {
        let apiMessage = json(data)["message"] as? String
        let hint: String
        switch code {
        case 401: hint = "Токен недействителен или истёк."
        case 403: hint = "Нет прав или превышен лимит запросов. Проверьте права токена (repo, workflow)."
        case 404: hint = "Не найдено. Проверьте имя репозитория и права токена (repo, workflow)."
        case 409: hint = "Конфликт — повторите попытку."
        case 422: hint = "GitHub не принял запрос."
        default: hint = "Ошибка GitHub (\(code))."
        }
        if let apiMessage = apiMessage { return "\(hint) \(apiMessage)" }
        return hint
    }

    private func encoded(_ path: String) -> String {
        path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
    }

    // MARK: - Аккаунт и репозиторий

    func currentUser() async throws -> String {
        let data = try await send(try request("/user"))
        guard let login = Self.json(data)["login"] as? String else {
            throw GitHubError(message: "Не удалось определить аккаунт по токену.")
        }
        return login
    }

    /// nil — репозиторий не найден.
    func repositoryExists() async throws -> Bool {
        let (data, code) = try await sendRaw(try request(repoPath))
        if code == 404 { return false }
        guard (200..<300).contains(code) else {
            throw GitHubError(message: Self.describe(data, code: code))
        }
        return true
    }

    func createRepository() async throws {
        let body: [String: Any] = [
            "name": repo,
            "private": true,
            "auto_init": true,
            "description": "Сборка iOS-приложений через GitHub Actions"
        ]
        _ = try await send(try request("/user/repos", method: "POST", body: body))
    }

    // MARK: - Файлы

    private func fileInfo(_ path: String) async throws -> (sha: String, content: String)? {
        let (data, code) = try await sendRaw(try request("\(repoPath)/contents/\(encoded(path))"))
        if code == 404 { return nil }
        guard (200..<300).contains(code) else {
            throw GitHubError(message: Self.describe(data, code: code))
        }
        let object = Self.json(data)
        guard let sha = object["sha"] as? String else { return nil }
        var text = ""
        if let base64 = object["content"] as? String,
           let decoded = Data(base64Encoded: base64, options: .ignoreUnknownCharacters) {
            text = String(decoding: decoded, as: UTF8.self)
        }
        return (sha, text)
    }

    /// Создаёт или обновляет файл, возвращает SHA коммита.
    func putFile(path: String, data: Data, message: String, sha: String?) async throws -> String {
        var body: [String: Any] = ["message": message, "content": data.base64EncodedString()]
        if let sha = sha { body["sha"] = sha }
        let response = try await send(try request("\(repoPath)/contents/\(encoded(path))", method: "PUT", body: body))
        let commit = Self.json(response)["commit"] as? [String: Any]
        guard let commitSHA = commit?["sha"] as? String else {
            throw GitHubError(message: "GitHub не вернул идентификатор коммита.")
        }
        return commitSHA
    }

    func installWorkflow() async throws {
        let existing = try await fileInfo(WorkflowTemplate.path)
        if let existing = existing, existing.content == WorkflowTemplate.yaml { return }
        _ = try await putFile(
            path: WorkflowTemplate.path,
            data: Data(WorkflowTemplate.yaml.utf8),
            message: "Add IPA builder workflow",
            sha: existing?.sha
        )
    }

    // MARK: - Запуски

    private static func parseRun(_ d: [String: Any]) -> RunInfo? {
        guard let id = d["id"] as? Int else { return nil }
        return RunInfo(
            id: id,
            status: d["status"] as? String ?? "",
            conclusion: d["conclusion"] as? String,
            title: (d["display_title"] as? String) ?? (d["name"] as? String) ?? "Сборка",
            number: d["run_number"] as? Int ?? 0,
            created: (d["created_at"] as? String).flatMap { iso.date(from: $0) },
            htmlURL: d["html_url"] as? String ?? ""
        )
    }

    func findRun(headSHA: String) async throws -> RunInfo? {
        let data = try await send(try request("\(repoPath)/actions/runs?head_sha=\(headSHA)&per_page=10"))
        let runs = Self.json(data)["workflow_runs"] as? [[String: Any]] ?? []
        return runs
            .filter { ($0["path"] as? String)?.hasSuffix("build-zip.yml") == true }
            .compactMap { Self.parseRun($0) }
            .first
    }

    func run(id: Int) async throws -> RunInfo {
        let data = try await send(try request("\(repoPath)/actions/runs/\(id)"))
        guard let run = Self.parseRun(Self.json(data)) else {
            throw GitHubError(message: "Не удалось прочитать состояние сборки.")
        }
        return run
    }

    func recentRuns() async throws -> [RunInfo] {
        let data = try await send(try request("\(repoPath)/actions/workflows/build-zip.yml/runs?per_page=15"))
        let runs = Self.json(data)["workflow_runs"] as? [[String: Any]] ?? []
        return runs.compactMap { Self.parseRun($0) }
    }

    func jobs(runID: Int) async throws -> [JobInfo] {
        let data = try await send(try request("\(repoPath)/actions/runs/\(runID)/jobs"))
        let jobs = Self.json(data)["jobs"] as? [[String: Any]] ?? []
        return jobs.compactMap { job -> JobInfo? in
            guard let id = job["id"] as? Int else { return nil }
            let steps = (job["steps"] as? [[String: Any]] ?? []).compactMap { step -> StepInfo? in
                guard let number = step["number"] as? Int else { return nil }
                return StepInfo(
                    number: number,
                    name: step["name"] as? String ?? "Шаг \(number)",
                    status: step["status"] as? String ?? "",
                    conclusion: step["conclusion"] as? String
                )
            }
            return JobInfo(
                id: id,
                name: job["name"] as? String ?? "build",
                status: job["status"] as? String ?? "",
                conclusion: job["conclusion"] as? String,
                steps: steps
            )
        }
    }

    func jobLog(jobID: Int) async throws -> String {
        let data = try await send(try request("\(repoPath)/actions/jobs/\(jobID)/logs"))
        return String(decoding: data, as: UTF8.self)
    }

    // MARK: - Релиз с IPA

    func releaseAssets(tag: String) async throws -> [AssetInfo] {
        let (data, code) = try await sendRaw(try request("\(repoPath)/releases/tags/\(tag)"))
        if code == 404 { return [] }
        guard (200..<300).contains(code) else {
            throw GitHubError(message: Self.describe(data, code: code))
        }
        let assets = Self.json(data)["assets"] as? [[String: Any]] ?? []
        return assets.compactMap { asset -> AssetInfo? in
            guard let id = asset["id"] as? Int, let name = asset["name"] as? String else { return nil }
            return AssetInfo(id: id, name: name, size: asset["size"] as? Int ?? 0)
        }
    }

    /// Удаляет завершённый запуск. Если его уже нет — ничего не делает.
    func deleteRun(id: Int) async throws {
        let (data, code) = try await sendRaw(try request("\(repoPath)/actions/runs/\(id)", method: "DELETE"))
        guard code == 204 || code == 404 else {
            throw GitHubError(message: Self.describe(data, code: code))
        }
    }

    /// Удаляет релиз с IPA и его тег. Если релиза нет — ничего не делает.
    func deleteRelease(tag: String) async throws {
        let (data, code) = try await sendRaw(try request("\(repoPath)/releases/tags/\(tag)"))

        if code == 404 {
            // Релиза нет — удалять нечего.
        } else if (200..<300).contains(code) {
            guard let releaseID = Self.json(data)["id"] as? Int else {
                throw GitHubError(message: "GitHub не вернул идентификатор релиза.")
            }
            let (body, status) = try await sendRaw(try request("\(repoPath)/releases/\(releaseID)", method: "DELETE"))
            guard status == 204 || status == 404 else {
                throw GitHubError(message: Self.describe(body, code: status))
            }
        } else {
            throw GitHubError(message: Self.describe(data, code: code))
        }

        // После удаления релиза тег остаётся — убираем и его (404/422: тега уже нет).
        let (tagBody, tagStatus) = try await sendRaw(try request("\(repoPath)/git/refs/tags/\(tag)", method: "DELETE"))
        guard tagStatus == 204 || tagStatus == 404 || tagStatus == 422 else {
            throw GitHubError(message: Self.describe(tagBody, code: tagStatus))
        }
    }

    func downloadAsset(id: Int) async throws -> Data {
        try await send(try request("\(repoPath)/releases/assets/\(id)", accept: "application/octet-stream"))
    }
}

import Foundation

/// Файл проекта, написанный в встроенном редакторе.
struct EditorFile: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var text: String
}

struct EditorTemplate: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let files: [(name: String, text: String)]
}

enum EditorTemplates {
    static let all: [EditorTemplate] = [hello, counter, todo]

    static var defaultFiles: [EditorFile] {
        hello.files.map { EditorFile(name: $0.name, text: $0.text) }
    }

    private static let appFile = #"""
import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
"""#

    static let hello = EditorTemplate(
        id: "hello",
        title: "Привет, мир",
        subtitle: "Самое простое приложение",
        files: [
            ("App.swift", appFile),
            ("ContentView.swift", #"""
import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "hammer.fill")
                .font(.system(size: 48))
                .foregroundStyle(.tint)

            Text("Привет, мир!")
                .font(.title)

            Text("Это приложение собрано из кода, написанного прямо на телефоне.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding()
    }
}
"""#)
        ]
    )

    static let counter = EditorTemplate(
        id: "counter",
        title: "Счётчик",
        subtitle: "Состояние и кнопки",
        files: [
            ("App.swift", appFile),
            ("ContentView.swift", #"""
import SwiftUI

struct ContentView: View {
    @State private var count = 0

    var body: some View {
        VStack(spacing: 24) {
            Text("\(count)")
                .font(.system(size: 72, weight: .semibold, design: .rounded))
                .monospacedDigit()

            HStack(spacing: 16) {
                Button("−") { count -= 1 }
                    .buttonStyle(.bordered)

                Button("+") { count += 1 }
                    .buttonStyle(.borderedProminent)
            }
            .controlSize(.large)

            Button("Сбросить", role: .destructive) { count = 0 }
                .disabled(count == 0)
        }
        .padding()
    }
}
"""#)
        ]
    )

    static let todo = EditorTemplate(
        id: "todo",
        title: "Список задач",
        subtitle: "Список, ввод текста, удаление",
        files: [
            ("App.swift", appFile),
            ("ContentView.swift", #"""
import SwiftUI

struct TodoItem: Identifiable {
    let id = UUID()
    var title: String
    var done = false
}

struct ContentView: View {
    @State private var items: [TodoItem] = []
    @State private var newTitle = ""

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack {
                        TextField("Новая задача", text: $newTitle)
                            .onSubmit(add)
                        Button("Добавить", action: add)
                            .disabled(newTitle.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }

                Section {
                    ForEach($items) { $item in
                        Button {
                            item.done.toggle()
                        } label: {
                            HStack {
                                Image(systemName: item.done ? "checkmark.circle.fill" : "circle")
                                Text(item.title)
                                    .strikethrough(item.done)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                    .onDelete { offsets in
                        items.remove(atOffsets: offsets)
                    }
                }
            }
            .navigationTitle("Задачи")
        }
    }

    private func add() {
        let title = newTitle.trimmingCharacters(in: .whitespaces)
        guard !title.isEmpty else { return }
        items.append(TodoItem(title: title))
        newTitle = ""
    }
}
"""#)
        ]
    )
}

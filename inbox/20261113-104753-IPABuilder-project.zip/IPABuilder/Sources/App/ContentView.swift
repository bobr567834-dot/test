import SwiftUI

struct ContentView: View {
    @EnvironmentObject var model: BuilderModel

    var body: some View {
        TabView(selection: $model.selectedTab) {
            BuildView()
                .tabItem { Label("Сборка", systemImage: "hammer.fill") }
                .tag(0)

            CodeView()
                .tabItem { Label("Код", systemImage: "chevron.left.forwardslash.chevron.right") }
                .tag(1)

            SettingsView()
                .tabItem { Label("Настройка", systemImage: "gearshape.fill") }
                .tag(2)
        }
        .tint(Theme.accent)
        .onAppear {
            if !model.isConfigured { model.selectedTab = 2 }
        }
    }
}

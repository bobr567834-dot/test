import SwiftUI

struct CodeView: View {
    @EnvironmentObject var model: BuilderModel

    @State private var showNewFile = false
    @State private var newFileName = ""
    @State private var renameTarget: EditorFile?
    @State private var renameText = ""
    @State private var showParams = false
    @State private var templateToLoad: EditorTemplate?
    @State private var confirmClearAll = false

    private var renameBinding: Binding<Bool> {
        Binding(
            get: { renameTarget != nil },
            set: { shown in
                if !shown { renameTarget = nil }
            }
        )
    }

    private var templateBinding: Binding<Bool> {
        Binding(
            get: { templateToLoad != nil },
            set: { shown in
                if !shown { templateToLoad = nil }
            }
        )
    }

    private var canBuild: Bool {
        model.isConfigured && !model.isBusy && !model.editorFiles.isEmpty
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    ScreenHeader(title: "Код", subtitle: "Пишите приложение прямо здесь")
                        .alert("Переименовать", isPresented: renameBinding) {
                            TextField("Имя файла", text: $renameText)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                            Button("Готово") {
                                if let target = renameTarget {
                                    model.renameEditorFile(id: target.id, to: renameText)
                                }
                                renameTarget = nil
                            }
                            Button("Отмена", role: .cancel) { renameTarget = nil }
                        }

                    SectionLabel("Файлы проекта")
                    filesPanel
                        .alert("Новый файл", isPresented: $showNewFile) {
                            TextField("Имя, например Model.swift", text: $newFileName)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                            Button("Создать") {
                                model.addEditorFile(named: newFileName)
                                newFileName = ""
                            }
                            Button("Отмена", role: .cancel) { newFileName = "" }
                        }

                    buildBlock
                        .confirmationDialog("Удалить все файлы проекта?", isPresented: $confirmClearAll, titleVisibility: .visible) {
                            Button("Удалить всё", role: .destructive) {
                                model.clearEditorFiles()
                            }
                            Button("Отмена", role: .cancel) {}
                        } message: {
                            Text("Код во всех файлах будет стёрт. Это нельзя отменить.")
                        }

                    SectionLabel("Шаблоны")
                    templatesPanel
                        .confirmationDialog(
                            "Заменить файлы шаблоном «\(templateToLoad?.title ?? "")»?",
                            isPresented: templateBinding,
                            titleVisibility: .visible
                        ) {
                            Button("Заменить", role: .destructive) {
                                if let template = templateToLoad { model.loadTemplate(template) }
                                templateToLoad = nil
                            }
                            Button("Отмена", role: .cancel) { templateToLoad = nil }
                        } message: {
                            Text("Текущие файлы проекта будут удалены.")
                        }
                }
                .padding(.bottom, 40)
            }
            .background(ScreenBackground().ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
        .sheet(isPresented: $showParams) {
            ProjectParamsSheet()
        }
    }

    // MARK: - Файлы

    private var filesPanel: some View {
        Panel {
            ForEach(model.editorFiles) { file in
                VStack(spacing: 0) {
                    NavigationLink {
                        CodeEditorScreen(fileID: file.id)
                    } label: {
                        fileRow(file)
                    }
                    .buttonStyle(.plain)
                    .contextMenu {
                        Button {
                            renameText = file.name
                            renameTarget = file
                        } label: {
                            Label("Переименовать", systemImage: "pencil")
                        }
                        Button(role: .destructive) {
                            model.deleteEditorFile(id: file.id)
                        } label: {
                            Label("Удалить", systemImage: "trash")
                        }
                    }
                    RowDivider()
                }
            }

            Button {
                showNewFile = true
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "plus")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(Theme.accent)
                        .frame(width: 36, height: 36)
                        .background(Theme.accent.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    Text("Новый файл")
                        .font(.rounded(15, .semibold))
                        .foregroundColor(Theme.accent)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if !model.editorFiles.isEmpty {
                RowDivider()
                Button {
                    confirmClearAll = true
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "trash")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(Theme.danger)
                            .frame(width: 36, height: 36)
                            .background(Theme.danger.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        Text("Удалить все файлы")
                            .font(.rounded(15, .semibold))
                            .foregroundColor(Theme.danger)
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 20)
    }

    private func fileRow(_ file: EditorFile) -> some View {
        let lines = file.text.isEmpty ? 0 : file.text.split(separator: "\n", omittingEmptySubsequences: false).count
        return HStack(spacing: 12) {
            Image(systemName: "doc.text")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(Theme.inkSoft)
                .frame(width: 36, height: 36)
                .background(Theme.track)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(file.name)
                    .font(.mono(14, .medium))
                    .foregroundColor(Theme.ink)
                    .lineLimit(1)
                Text("строк: \(lines)")
                    .font(.system(size: 12))
                    .foregroundColor(Theme.inkSoft)
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(Theme.inkSoft.opacity(0.6))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }

    // MARK: - Сборка

    private var buildBlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                model.startEditorBuild()
            } label: {
                PillButton(title: "Собрать IPA", icon: "hammer.fill", enabled: canBuild)
            }
            .disabled(!canBuild)

            Button {
                showParams = true
            } label: {
                PillButton(title: "Параметры приложения", icon: "slider.horizontal.3", filled: false)
            }

            if let notice = model.buildNotice {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "info.circle.fill")
                    Text(notice)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .font(.system(size: 13))
                .foregroundColor(Theme.inkSoft)
            }

            if !model.isConfigured {
                Text("Сначала подключите GitHub во вкладке «Настройка».")
                    .font(.system(size: 13))
                    .foregroundColor(Theme.inkSoft)
            }

            if let error = model.errorText {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.circle.fill")
                    Text(error)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .font(.system(size: 13))
                .foregroundColor(Theme.danger)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 20)
    }

    // MARK: - Шаблоны

    private var templatesPanel: some View {
        Panel {
            ForEach(EditorTemplates.all) { template in
                VStack(spacing: 0) {
                    Button {
                        templateToLoad = template
                    } label: {
                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(template.title)
                                    .font(.rounded(15, .semibold))
                                    .foregroundColor(Theme.ink)
                                Text(template.subtitle)
                                    .font(.system(size: 13))
                                    .foregroundColor(Theme.inkSoft)
                            }
                            Spacer(minLength: 8)
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(Theme.inkSoft)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)

                    if template.id != EditorTemplates.all.last?.id {
                        RowDivider()
                    }
                }
            }
        }
        .padding(.horizontal, 20)
    }
}

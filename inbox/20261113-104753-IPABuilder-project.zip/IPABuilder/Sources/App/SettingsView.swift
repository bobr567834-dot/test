import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var model: BuilderModel

    private let tokenURL = URL(string: "https://github.com/settings/tokens/new?scopes=repo,workflow&description=IPA%20Builder")

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                ScreenHeader(title: "Настройка", subtitle: "Подключите GitHub один раз")

                SectionLabel("Что вы присылаете")
                Panel {
                    ChoiceRow(label: "Режим загрузки", options: UploadMode.allCases, selection: $model.mode, title: { $0.title })
                    RowDivider()
                    Text(model.mode == .archive
                         ? "Вы присылаете готовый проект одним zip-файлом (с project.yml или .xcodeproj) — как раньше."
                         : "Вы присылаете только файлы приложения (.swift и ресурсы — файлами или папкой). Приложение само добавит project.yml, разрешения и всё остальное для сборки.")
                        .font(.system(size: 13))
                        .foregroundColor(Theme.inkSoft)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                }
                .padding(.horizontal, 20)

                if model.mode == .sources {
                    SectionLabel("Параметры приложения")
                    ProjectParamsPanel()
                    .padding(.horizontal, 20)

                    Text("Платформа «Авто» определяется по коду: если есть WatchKit — это watchOS. Разрешения (Bluetooth, геопозиция, камера, локальная сеть и др.) добавляются автоматически по тому, что используется в коде.")
                        .font(.system(size: 12))
                        .foregroundColor(Theme.inkSoft)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 24)
                        .padding(.top, 10)
                }

                SectionLabel("Доступ")
                Panel {
                    FieldRow(label: "Токен GitHub", text: $model.token, placeholder: "ghp_…", secure: true, mono: true)
                    RowDivider()
                    FieldRow(label: "Репозиторий (владелец/имя)", text: $model.repoFull, placeholder: "ivan/ipa-builder", mono: true)
                }
                .padding(.horizontal, 20)

                VStack(alignment: .leading, spacing: 12) {
                    Button {
                        model.setup()
                    } label: {
                        if model.isSettingUp {
                            HStack(spacing: 8) {
                                ProgressView().tint(.white)
                                Text("Подключаю…")
                            }
                            .font(.rounded(15, .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Theme.accent)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        } else {
                            PillButton(title: "Проверить и подключить", icon: "link")
                        }
                    }
                    .disabled(model.isSettingUp)

                    if let message = model.setupMessage {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: model.setupIsError ? "exclamationmark.circle.fill" : "checkmark.circle.fill")
                            Text(message)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .font(.system(size: 13))
                        .foregroundColor(model.setupIsError ? Theme.danger : Theme.success)
                    } else if model.isConfigured {
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.circle.fill")
                            Text("Подключено")
                        }
                        .font(.system(size: 13))
                        .foregroundColor(Theme.success)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)

                SectionLabel("Как получить токен")
                Panel {
                    VStack(alignment: .leading, spacing: 14) {
                        StepRow(number: 1, text: "Нажмите кнопку ниже — откроется GitHub, права repo и workflow уже отмечены.")
                        StepRow(number: 2, text: "Внизу страницы нажмите «Generate token» и скопируйте токен (он показывается один раз).")
                        StepRow(number: 3, text: "Вставьте токен выше, укажите репозиторий и нажмите «Проверить и подключить».")

                        if let tokenURL = tokenURL {
                            Link(destination: tokenURL) {
                                PillButton(title: "Создать токен на GitHub", icon: "key.fill", filled: false)
                            }
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, 20)

                SectionLabel("Важно знать")
                Panel {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Если репозитория нет, приложение создаст приватный репозиторий с этим именем (только в вашем аккаунте).")
                        Text("Токен хранится на этом устройстве в Keychain и отправляется только на api.github.com.")
                        Text("Архивы остаются в папке inbox/ репозитория — не кладите в них пароли и ключи.")
                        Text("Сборка идёт на macOS-серверах GitHub. В приватных репозиториях такие минуты расходуют лимит бесплатного тарифа с множителем (по правилам GitHub), в публичных они бесплатны.")
                    }
                    .font(.system(size: 13))
                    .foregroundColor(Theme.inkSoft)
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, 20)
            }
            .padding(.bottom, 40)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(ScreenBackground().ignoresSafeArea())
    }
}

import SwiftUI

/// Параметры приложения (название, Bundle ID, платформа, версии, тема) — общие для режима «Только файлы» и редактора.
struct ProjectParamsPanel: View {
    @EnvironmentObject var model: BuilderModel

    var body: some View {
        Panel {
            FieldRow(label: "Название под иконкой", text: $model.appName, placeholder: "Например, Мой проект")
            RowDivider()
            FieldRow(label: "Bundle ID", text: $model.bundleID, placeholder: "com.example.myapp", mono: true)
            RowDivider()
            ChoiceRow(label: "Платформа", options: PlatformChoice.allCases, selection: $model.platformChoice, title: { $0.title })
            RowDivider()
            ChoiceRow(label: "Минимальная iOS", options: ["15.0", "16.0", "17.0"], selection: $model.iosVersion, title: { $0 })
            RowDivider()
            ChoiceRow(label: "Минимальная watchOS", options: ["9.0", "10.0", "11.0"], selection: $model.watchVersion, title: { $0 })
            RowDivider()
            ChoiceRow(label: "Тема (только iOS)", options: ThemeChoice.allCases, selection: $model.themeChoice, title: { $0.title })
        }
    }
}

/// Те же параметры в виде листа — для вкладки «Код».
struct ProjectParamsSheet: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    SectionLabel("Параметры приложения")
                    ProjectParamsPanel()
                        .padding(.horizontal, 20)

                    Text("Разрешения (Bluetooth, геопозиция, камера и др.) добавляются сами по тому, что используется в коде.")
                        .font(.system(size: 12))
                        .foregroundColor(Theme.inkSoft)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 24)
                        .padding(.top, 12)
                }
                .padding(.bottom, 40)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(ScreenBackground().ignoresSafeArea())
            .navigationTitle("Параметры")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }
}

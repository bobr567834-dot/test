import SwiftUI
import UniformTypeIdentifiers
import UIKit

private enum ImportKind {
    case zip, files, folder

    var types: [UTType] {
        switch self {
        case .zip: return [.zip]
        case .files: return [.item]
        case .folder: return [.folder]
        }
    }

    var allowsMultiple: Bool { self == .files }
}

struct BuildView: View {
    @EnvironmentObject var model: BuilderModel
    @State private var showImporter = false
    @State private var importKind: ImportKind = .zip
    @State private var showShare = false
    @State private var showExporter = false
    @State private var copied = false
    @State private var confirmDeleteAll = false

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 0) {
                    ScreenHeader(
                        title: "Сборка",
                        subtitle: model.mode == .archive ? "Загрузите zip — получите IPA" : "Пришлите файлы — получите IPA"
                    )

                    SectionLabel(model.mode == .archive ? "Архив проекта" : "Файлы приложения")
                    archivePanel
                    buildButton

                    if let error = model.errorText {
                        errorBanner(error)
                    }

                    if model.run != nil || model.isBusy {
                        statusBlock
                    }

                    if let ipa = model.ipaURL {
                        successBlock(ipa)
                            .id("result")
                    }

                    if model.phase == .finished, let run = model.run, run.isFinished, !run.isSuccess {
                        failureBlock(run)
                            .id("result")
                    }

                    historyBlock
                }
                .padding(.bottom, 40)
            }
            .onChange(of: model.phase) { phase in
                if phase == .finished {
                    withAnimation(.easeOut(duration: 0.3)) {
                        proxy.scrollTo("result", anchor: .top)
                    }
                }
            }
        }
        .background(ScreenBackground().ignoresSafeArea())
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: importKind.types,
            allowsMultipleSelection: importKind.allowsMultiple
        ) { result in
            switch importKind {
            case .zip: model.pickZip(result)
            case .files: model.pickSourceFiles(result)
            case .folder: model.pickSourceFolder(result)
            }
        }
        .sheet(isPresented: $showShare) {
            if let url = model.ipaURL {
                ActivityView(items: [url])
                    .presentationDetents([.medium, .large])
            }
        }
        .sheet(isPresented: $showExporter) {
            if let url = model.ipaURL {
                DocumentExporter(url: url)
                    .ignoresSafeArea()
            }
        }
        .task {
            await model.refreshHistory()
        }
    }

    // MARK: - Архив и кнопка

    private var zipPanel: some View {
        Panel {
            Button {
                openImporter(.zip)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: model.zipName == nil ? "doc.badge.plus" : "doc.zipper")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(Theme.accent)
                        .frame(width: 40, height: 40)
                        .background(Theme.accent.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))

                    VStack(alignment: .leading, spacing: 2) {
                        Text(model.zipName ?? "Выбрать .zip архив")
                            .font(.rounded(15, .semibold))
                            .foregroundColor(Theme.ink)
                            .lineLimit(1)
                        Text(archiveSubtitle)
                            .font(.system(size: 13))
                            .foregroundColor(Theme.inkSoft)
                    }
                    Spacer(minLength: 8)
                    Text(model.zipName == nil ? "" : "Заменить")
                        .font(.rounded(13, .semibold))
                        .foregroundColor(Theme.accent)
                }
                .padding(16)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
    }

    @ViewBuilder
    private var archivePanel: some View {
        if model.mode == .archive {
            zipPanel
        } else {
            sourcesPanel
        }
    }

    private func openImporter(_ kind: ImportKind) {
        importKind = kind
        DispatchQueue.main.async { showImporter = true }
    }

    private func actionRow(icon: String, title: String, subtitle: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(Theme.accent)
                .frame(width: 40, height: 40)
                .background(Theme.accent.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.rounded(15, .semibold))
                    .foregroundColor(Theme.ink)
                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundColor(Theme.inkSoft)
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(Theme.inkSoft.opacity(0.6))
        }
        .padding(16)
        .contentShape(Rectangle())
    }

    private var sourcesPanel: some View {
        Panel {
            Button {
                openImporter(.files)
            } label: {
                actionRow(icon: "doc.on.doc", title: "Выбрать файлы", subtitle: ".swift, иконки и другие ресурсы")
            }
            .buttonStyle(.plain)

            RowDivider()

            Button {
                openImporter(.folder)
            } label: {
                actionRow(icon: "folder", title: "Выбрать папку", subtitle: "Например, папку Sources целиком")
            }
            .buttonStyle(.plain)

            if let summary = model.sourceSummary {
                RowDivider()
                InfoRow(label: "Выбрано", value: "\(summary.fileCount) · " + ByteCountFormatter.string(fromByteCount: Int64(summary.totalBytes), countStyle: .file))

                if summary.isCompleteProject {
                    RowDivider()
                    Text("Найден project.yml или .xcodeproj — файлы уйдут на сборку как есть, ничего не добавляется.")
                        .font(.system(size: 13))
                        .foregroundColor(Theme.inkSoft)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                } else {
                    RowDivider()
                    InfoRow(label: "Платформа", value: model.effectivePlatform.title)
                    RowDivider()
                    InfoRow(
                        label: "Разрешения",
                        value: summary.permissions.isEmpty ? "не нужны" : summary.permissions.map { $0.title }.joined(separator: ", ")
                    )
                    RowDivider()
                    InfoRow(
                        label: "Точка входа (@main)",
                        value: summary.hasMain ? "найдена" : (summary.rootViewName != nil ? "добавится сама" : "не найдена"),
                        valueColor: summary.hasMain ? Theme.success : (summary.rootViewName != nil ? Theme.accent : Theme.danger)
                    )
                    if let icon = summary.appIconName {
                        RowDivider()
                        InfoRow(label: "Иконка", value: icon)
                    }
                    RowDivider()
                    Text("Приложение добавит project.yml и Info.plist. Название, Bundle ID и версии меняются во вкладке «Настройка».")
                        .font(.system(size: 12))
                        .foregroundColor(Theme.inkSoft)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                }

                RowDivider()
                Button {
                    model.clearSources()
                } label: {
                    Text("Очистить выбор")
                        .font(.rounded(14, .semibold))
                        .foregroundColor(Theme.danger)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 20)
    }

    private var archiveSubtitle: String {
        guard let data = model.zipData else { return "Архив с project.yml или .xcodeproj" }
        return ByteCountFormatter.string(fromByteCount: Int64(data.count), countStyle: .file)
    }

    private var canBuild: Bool {
        model.isReadyToBuild && model.isConfigured && !model.isBusy
    }

    private var buildButton: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                model.startBuild()
            } label: {
                PillButton(title: "Собрать IPA", icon: "hammer.fill", enabled: canBuild)
            }
            .disabled(!canBuild)

            if let notice = model.buildNotice {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "info.circle.fill")
                    Text(notice)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .font(.system(size: 13))
                .foregroundColor(Theme.inkSoft)
            }

            if !model.isConfigured {
                Text("Сначала подключите GitHub во вкладке «Настройка».")
                    .font(.system(size: 13))
                    .foregroundColor(Theme.inkSoft)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
    }

    private func errorBanner(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "exclamationmark.circle.fill")
            Text(text)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .font(.system(size: 13))
        .foregroundColor(Theme.danger)
        .padding(.horizontal, 24)
        .padding(.top, 14)
    }

    // MARK: - Ход сборки

    private var statusBlock: some View {
        VStack(spacing: 0) {
            SectionLabel("Ход сборки")
            Panel {
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(model.run?.title ?? "Новая сборка")
                            .font(.rounded(15, .semibold))
                            .foregroundColor(Theme.ink)
                            .lineLimit(1)
                        if !model.statusText.isEmpty {
                            Text(model.statusText)
                                .font(.system(size: 13))
                                .foregroundColor(Theme.inkSoft)
                                .lineLimit(1)
                        }
                    }
                    Spacer(minLength: 8)
                    if let run = model.run {
                        StatusChip(run: run)
                    } else {
                        ProgressView()
                    }
                }
                .padding(16)

                let steps = model.visibleSteps
                if !steps.isEmpty {
                    RowDivider()
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(steps) { step in
                            HStack(spacing: 12) {
                                StepIcon(status: step.status, conclusion: step.conclusion)
                                Text(step.name)
                                    .font(.system(size: 14))
                                    .foregroundColor(step.status == "pending" ? Theme.inkSoft : Theme.ink)
                                Spacer(minLength: 0)
                            }
                        }
                    }
                    .padding(16)
                }
            }
            .padding(.horizontal, 20)
        }
    }

    // MARK: - Результат

    private func successBlock(_ url: URL) -> some View {
        VStack(spacing: 0) {
            SectionLabel("Готово")
            Panel {
                HStack(spacing: 12) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(Theme.success)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("IPA собран")
                            .font(.rounded(16, .semibold))
                            .foregroundColor(Theme.ink)
                        Text(url.lastPathComponent)
                            .font(.mono(12))
                            .foregroundColor(Theme.inkSoft)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .padding(16)

                RowDivider()

                VStack(spacing: 10) {
                    Button {
                        showShare = true
                    } label: {
                        PillButton(title: "Поделиться / открыть в…", icon: "square.and.arrow.up")
                    }
                    Button {
                        showExporter = true
                    } label: {
                        PillButton(title: "Сохранить в Файлы", icon: "folder", filled: false)
                    }
                    Text("Выберите Feather, ESign или AltStore, чтобы подписать и установить. Файл также лежит в Файлы → На iPhone → «Сборщик» → Builds.")
                        .font(.system(size: 12))
                        .foregroundColor(Theme.inkSoft)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(16)
            }
            .padding(.horizontal, 20)
        }
    }

    private func failureBlock(_ run: RunInfo) -> some View {
        VStack(spacing: 0) {
            SectionLabel("Сборка не удалась")
            Panel {
                HStack(spacing: 12) {
                    Image(systemName: "xmark.octagon.fill")
                        .font(.system(size: 26))
                        .foregroundColor(Theme.danger)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Ошибка на шаге")
                            .font(.system(size: 13))
                            .foregroundColor(Theme.inkSoft)
                        Text(model.failedStep ?? "неизвестно")
                            .font(.rounded(16, .semibold))
                            .foregroundColor(Theme.ink)
                    }
                    Spacer(minLength: 0)
                }
                .padding(16)

                if !model.errorLines.isEmpty {
                    RowDivider()
                    ScrollView(.horizontal, showsIndicators: false) {
                        Text(model.errorLines.joined(separator: "\n"))
                            .font(.mono(11))
                            .foregroundColor(Theme.ink)
                            .textSelection(.enabled)
                            .padding(16)
                    }
                    .background(Theme.codeBG)
                }

                RowDivider()

                VStack(spacing: 10) {
                    Button {
                        UIPasteboard.general.string = model.errorLines.joined(separator: "\n")
                        copied = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { copied = false }
                    } label: {
                        PillButton(
                            title: copied ? "Скопировано" : "Копировать ошибки",
                            icon: copied ? "checkmark" : "doc.on.doc"
                        )
                    }
                    if model.lastBuildWasEditor {
                        Button {
                            model.selectedTab = 1
                        } label: {
                            PillButton(title: "Вернуться к коду", icon: "chevron.left.forwardslash.chevron.right", filled: false)
                        }
                    }
                    if let link = URL(string: run.htmlURL) {
                        Link(destination: link) {
                            PillButton(title: "Открыть на GitHub", icon: "arrow.up.right.square", filled: false)
                        }
                    }
                }
                .padding(16)
            }
            .padding(.horizontal, 20)
        }
    }

    // MARK: - История

    private var historyBlock: some View {
        VStack(spacing: 0) {
            if !model.history.isEmpty {
                SectionLabel("Последние сборки")
                Panel {
                    ForEach(model.history) { item in
                        VStack(spacing: 0) {
                            Button {
                                model.openRun(item)
                            } label: {
                                historyRow(item)
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button {
                                    model.openRun(item)
                                } label: {
                                    Label("Открыть", systemImage: "arrow.up.right.square")
                                }
                                Button(role: .destructive) {
                                    model.deleteBuild(item)
                                } label: {
                                    Label("Удалить", systemImage: "trash")
                                }
                                .disabled(!item.isFinished || model.isDeleting)
                            }

                            if item.id != model.history.last?.id {
                                RowDivider()
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)

                VStack(spacing: 8) {
                    Button {
                        confirmDeleteAll = true
                    } label: {
                        HStack(spacing: 8) {
                            if model.isDeleting {
                                ProgressView()
                                Text("Удаляю…")
                            } else {
                                Image(systemName: "trash")
                                Text("Удалить все сборки")
                            }
                        }
                        .font(.rounded(14, .semibold))
                        .foregroundColor(Theme.danger)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    .disabled(model.isDeleting)

                    Text("Одну сборку можно удалить долгим нажатием на строку. Запущенные сборки не удаляются.")
                        .font(.system(size: 12))
                        .foregroundColor(Theme.inkSoft)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, 24)
                .padding(.top, 12)
                .confirmationDialog("Удалить все сборки?", isPresented: $confirmDeleteAll, titleVisibility: .visible) {
                    Button("Удалить всё", role: .destructive) {
                        model.clearHistory()
                    }
                    Button("Отмена", role: .cancel) {}
                } message: {
                    Text("Будут удалены завершённые запуски на GitHub, релизы с IPA и скачанные на телефон файлы.")
                }
            }
        }
    }

    private func historyRow(_ item: RunInfo) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(item.title)
                    .font(.rounded(14, .semibold))
                    .foregroundColor(Theme.ink)
                    .lineLimit(1)
                Text(subtitle(for: item))
                    .font(.system(size: 12))
                    .foregroundColor(Theme.inkSoft)
            }
            Spacer(minLength: 8)
            StatusChip(run: item)
            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(Theme.inkSoft.opacity(0.6))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }

    private func subtitle(for item: RunInfo) -> String {
        var text = "#\(item.number)"
        if let date = item.created {
            let formatter = RelativeDateTimeFormatter()
            formatter.unitsStyle = .short
            text += " · " + formatter.localizedString(for: date, relativeTo: Date())
        }
        return text
    }
}

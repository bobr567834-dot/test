import SwiftUI

/// Экран редактирования одного файла.
struct CodeEditorScreen: View {
    @EnvironmentObject var model: BuilderModel
    let fileID: UUID

    @State private var confirmClear = false

    var body: some View {
        if let index = model.editorFiles.firstIndex(where: { $0.id == fileID }) {
            CodeTextView(text: $model.editorFiles[index].text)
                .background(Theme.codeBG)
                .navigationTitle(model.editorFiles[index].name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Menu {
                            Button(role: .destructive) {
                                confirmClear = true
                            } label: {
                                Label("Очистить весь код", systemImage: "trash")
                            }
                        } label: {
                            Image(systemName: "ellipsis.circle")
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            model.startEditorBuild()
                        } label: {
                            Label("Собрать", systemImage: "hammer.fill")
                        }
                        .disabled(model.isBusy || !model.isConfigured)
                    }
                }
                .confirmationDialog("Очистить весь код в файле?", isPresented: $confirmClear, titleVisibility: .visible) {
                    Button("Очистить", role: .destructive) {
                        model.clearEditorFileText(id: fileID)
                    }
                    Button("Отмена", role: .cancel) {}
                } message: {
                    Text("Файл останется, но весь текст в нём будет стёрт.")
                }
        } else {
            Text("Файл удалён")
                .foregroundColor(Theme.inkSoft)
        }
    }
}

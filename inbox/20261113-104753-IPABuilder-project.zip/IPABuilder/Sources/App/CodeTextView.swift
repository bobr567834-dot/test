import SwiftUI
import UIKit

enum CodeStyle {
    static let font = UIFont.monospacedSystemFont(ofSize: 14, weight: .regular)
}

/// Простая подсветка синтаксиса Swift: ключевые слова, типы, строки, числа, комментарии.
enum SwiftHighlighter {
    private static let keywordPattern = #"\b(?:import|struct|class|enum|protocol|extension|func|var|let|if|else|guard|return|switch|case|default|for|in|while|repeat|break|continue|do|try|catch|throw|throws|async|await|init|deinit|self|Self|super|static|private|fileprivate|public|internal|open|final|override|mutating|where|as|is|nil|true|false|some|any|typealias|associatedtype|lazy|weak|unowned|inout|defer|subscript)\b"#

    /// Порядок важен: поздние правила перекрашивают более ранние (строки и комментарии — последними).
    private static let definitions: [(String, UIColor)] = [
        (#"\b[A-Z][A-Za-z0-9_]*\b"#, UIColor.systemTeal),
        (#"\b\d[\d_]*(?:\.\d+)?\b"#, UIColor.systemBlue),
        (keywordPattern, UIColor.systemPink),
        (#"@[A-Za-z_][A-Za-z0-9_]*"#, UIColor.systemOrange),
        (#""(?:\\.|[^"\\\n])*""#, UIColor.systemRed),
        (#"//[^\n]*"#, UIColor.systemGreen),
        (#"/\*[\s\S]*?\*/"#, UIColor.systemGreen)
    ]

    /// Если какой-то шаблон не скомпилируется, это правило просто пропускается.
    private static let rules: [(NSRegularExpression, UIColor)] = definitions.compactMap { definition in
        guard let expression = try? NSRegularExpression(pattern: definition.0) else { return nil }
        return (expression, definition.1)
    }

    static func apply(to storage: NSTextStorage) {
        let full = NSRange(location: 0, length: storage.length)
        let text = storage.string

        storage.beginEditing()
        storage.setAttributes([.font: CodeStyle.font, .foregroundColor: UIColor.label], range: full)
        for (regex, color) in rules {
            regex.enumerateMatches(in: text, options: [], range: full) { match, _, _ in
                if let range = match?.range {
                    storage.addAttribute(.foregroundColor, value: color, range: range)
                }
            }
        }
        storage.endEditing()
    }
}

/// Редактор кода на UITextView: без умных кавычек, с автоотступом и панелью символов над клавиатурой.
struct CodeTextView: UIViewRepresentable {
    @Binding var text: String

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> UITextView {
        let textView = UITextView()
        textView.delegate = context.coordinator
        textView.font = CodeStyle.font
        textView.backgroundColor = .clear
        textView.autocorrectionType = .no
        textView.autocapitalizationType = .none
        textView.spellCheckingType = .no
        textView.smartQuotesType = .no
        textView.smartDashesType = .no
        textView.smartInsertDeleteType = .no
        textView.keyboardDismissMode = .interactive
        textView.alwaysBounceVertical = true
        textView.textContainerInset = UIEdgeInsets(top: 12, left: 8, bottom: 12, right: 8)
        textView.inputAccessoryView = context.coordinator.makeAccessoryView(for: textView)
        textView.text = text
        SwiftHighlighter.apply(to: textView.textStorage)
        return textView
    }

    func updateUIView(_ textView: UITextView, context: Context) {
        context.coordinator.parent = self
        if textView.text != text {
            textView.text = text
            SwiftHighlighter.apply(to: textView.textStorage)
        }
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: CodeTextView

        init(_ parent: CodeTextView) {
            self.parent = parent
        }

        func textViewDidChange(_ textView: UITextView) {
            // Пока идёт ввод через IME (составной текст), подсветку не трогаем.
            if textView.markedTextRange == nil {
                SwiftHighlighter.apply(to: textView.textStorage)
            }
            parent.text = textView.text
        }

        /// Автоотступ: новая строка начинается с отступа предыдущей, после «{» — на 4 пробела глубже.
        func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            guard text == "\n" else { return true }

            let ns = textView.text as NSString
            let lineRange = ns.lineRange(for: NSRange(location: range.location, length: 0))
            let beforeCursor = ns.substring(with: NSRange(location: lineRange.location, length: range.location - lineRange.location))

            let indent = String(beforeCursor.prefix { $0 == " " || $0 == "\t" })
            let extra = beforeCursor.trimmingCharacters(in: .whitespaces).hasSuffix("{") ? "    " : ""

            textView.insertText("\n" + indent + extra)
            return false
        }

        // MARK: Панель символов над клавиатурой

        private let symbols: [(label: String, insert: String)] = [
            ("⇥", "    "), ("{", "{"), ("}", "}"), ("(", "("), (")", ")"), ("[", "["), ("]", "]"),
            ("<", "<"), (">", ">"), ("\"", "\""), (".", "."), (",", ","), (":", ":"), (";", ";"),
            ("=", "="), ("$", "$"), ("\\", "\\"), ("!", "!"), ("?", "?"), ("_", "_"), ("/", "/"),
            ("&", "&"), ("|", "|"), ("+", "+"), ("-", "-"), ("*", "*")
        ]

        func makeAccessoryView(for textView: UITextView) -> UIView {
            let width = UIScreen.main.bounds.width
            let bar = UIInputView(frame: CGRect(x: 0, y: 0, width: width, height: 46), inputViewStyle: .keyboard)
            bar.autoresizingMask = [.flexibleWidth]

            let scroll = UIScrollView()
            scroll.showsHorizontalScrollIndicator = false
            scroll.translatesAutoresizingMaskIntoConstraints = false

            let stack = UIStackView()
            stack.axis = .horizontal
            stack.alignment = .center
            stack.spacing = 6
            stack.translatesAutoresizingMaskIntoConstraints = false

            for symbol in symbols {
                var config = UIButton.Configuration.gray()
                config.title = symbol.label
                config.cornerStyle = .medium
                config.contentInsets = NSDirectionalEdgeInsets(top: 6, leading: 12, bottom: 6, trailing: 12)
                config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attributes in
                    var updated = attributes
                    updated.font = UIFont.monospacedSystemFont(ofSize: 17, weight: .medium)
                    return updated
                }
                let insert = symbol.insert
                let action = UIAction { [weak textView] _ in
                    textView?.insertText(insert)
                }
                stack.addArrangedSubview(UIButton(configuration: config, primaryAction: action))
            }

            let dismiss = UIButton(type: .system)
            dismiss.setImage(UIImage(systemName: "keyboard.chevron.compact.down"), for: .normal)
            dismiss.translatesAutoresizingMaskIntoConstraints = false
            dismiss.addAction(UIAction { [weak textView] _ in textView?.resignFirstResponder() }, for: .touchUpInside)

            scroll.addSubview(stack)
            bar.addSubview(scroll)
            bar.addSubview(dismiss)

            NSLayoutConstraint.activate([
                dismiss.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -4),
                dismiss.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
                dismiss.widthAnchor.constraint(equalToConstant: 44),
                dismiss.heightAnchor.constraint(equalToConstant: 44),

                scroll.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 8),
                scroll.trailingAnchor.constraint(equalTo: dismiss.leadingAnchor),
                scroll.topAnchor.constraint(equalTo: bar.topAnchor),
                scroll.bottomAnchor.constraint(equalTo: bar.bottomAnchor),

                stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
                stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
                stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
                stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
                stack.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor)
            ])
            return bar
        }
    }
}

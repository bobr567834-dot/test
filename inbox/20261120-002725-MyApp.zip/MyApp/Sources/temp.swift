import SwiftUI

struct ContentView: View {
    @State private var thermalState: ProcessInfo.ThermalState = ProcessInfo.processInfo.thermalState
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Состояние телефона")
                .font(.headline)
            
            // Отображение одного из четырёх уровней
            Text(stateText(for: thermalState))
                .font(.system(size: 40, weight: .bold))
                .foregroundColor(stateColor(for: thermalState))
                .padding()
                .background(stateColor(for: thermalState).opacity(0.2))
                .cornerRadius(12)
            
            Text("Обновите, чтобы проверить снова")
                .font(.caption)
                .foregroundColor(.gray)
        }
        .onAppear {
            // Можно добавить таймер для автообновления
            updateState()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            updateState()
        }
    }
    
    func updateState() {
        thermalState = ProcessInfo.processInfo.thermalState
    }
    
    func stateText(for state: ProcessInfo.ThermalState) -> String {
        switch state {
        case .nominal: return "Норма"
        case .fair: return "Тепло"
        case .serious: return "Горячо"
        case .critical: return "Перегрев"
        @unknown default: return "Неизвестно"
        }
    }
    
    func stateColor(for state: ProcessInfo.ThermalState) -> Color {
        switch state {
        case .nominal: return .green
        case .fair: return .yellow
        case .serious: return .orange
        case .critical: return .red
        @unknown default: return .gray
        }
    }
}
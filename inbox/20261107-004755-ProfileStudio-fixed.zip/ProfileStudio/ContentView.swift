import SwiftUI
import UniformTypeIdentifiers
import Security

struct ContentView: View {
    @State private var displayName = "My Configuration"
    @State private var identifier = "com.example.profile"
    @State private var organization = ""
    @State private var descriptionText = "Created with Profile Studio"
    @State private var payloads: [ProfilePayload] = []
    @State private var selectedKind: PayloadKind?
    @State private var editingPayload: ProfilePayload?
    @State private var showingImporter = false
    @State private var showingPreview = false
    @State private var showingExporter = false
    @State private var exportDocument = MobileConfigDocument(data: Data())
    @State private var exportName = "Configuration"
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Profile name", text: $displayName)
                    TextField("Identifier", text: $identifier)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Organization (optional)", text: $organization)
                    TextField("Description", text: $descriptionText, axis: .vertical)
                        .lineLimit(2...4)
                } header: {
                    Text("Profile details")
                } footer: {
                    Text("These details appear in the iOS profile installation screen.")
                }

                Section {
                    if payloads.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "doc.badge.plus")
                                .font(.largeTitle)
                                .foregroundStyle(.secondary)
                            Text("No payloads yet")
                                .font(.headline)
                            Text("Add a Wi-Fi, Web Clip, DNS, or HTTP Proxy payload.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                    } else {
                        ForEach(payloads) { payload in
                            Button {
                                if payload.kind != .other { editingPayload = payload }
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    HStack {
                                        Image(systemName: payload.kind.symbol)
                                            .foregroundStyle(.tint)
                                        Text(payload.title)
                                            .font(.headline)
                                            .foregroundStyle(.primary)
                                        Spacer()
                                        Text(payload.kind.shortName)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Text(payload.subtitle)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                }
                            }
                            .disabled(payload.kind == .other)
                        }
                        .onDelete { payloads.remove(atOffsets: $0) }
                    }
                } header: {
                    Text("Payloads")
                } footer: {
                    Text("Swipe left on a payload to remove it. One profile can contain multiple payloads.")
                }

                Section {
                    Button {
                        showingImporter = true
                    } label: {
                        Label("Import existing .mobileconfig", systemImage: "doc.badge.arrow.up")
                    }

                    Menu {
                        ForEach(PayloadKind.allCases.filter { $0 != .other }) { kind in
                            Button {
                                selectedKind = kind
                            } label: {
                                Label(kind.title, systemImage: kind.symbol)
                            }
                        }
                    } label: {
                        Label("Add payload", systemImage: "plus.circle.fill")
                    }
                    .disabled(payloads.count >= 20)
                } header: {
                    Text("Import and add")
                } footer: {
                    Text("Supported: Wi-Fi, Web Clip, encrypted DNS, and HTTP Proxy. Unknown imported payloads are retained when exporting.")
                }

                Section {
                    Button {
                        makePreview()
                    } label: {
                        Label("Preview mobileconfig", systemImage: "doc.text.magnifyingglass")
                    }
                    .disabled(!canExport)

                    Button {
                        exportProfile()
                    } label: {
                        Label("Export .mobileconfig", systemImage: "square.and.arrow.up")
                    }
                    .disabled(!canExport)
                } header: {
                    Text("Export")
                } footer: {
                    Text("The exported file is an unsigned configuration profile. Review its contents before installing it.")
                }
            }
            .navigationTitle("Profile Studio")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showingImporter = true
                    } label: {
                        Image(systemName: "square.and.arrow.down")
                    }
                    .accessibilityLabel("Import profile")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    EditButton()
                }
            }
            .sheet(item: $selectedKind) { kind in
                PayloadEditorView(kind: kind, existing: nil) { payload in
                    payloads.append(payload)
                }
            }
            .sheet(item: $editingPayload) { payload in
                PayloadEditorView(kind: payload.kind, existing: payload) { updated in
                    if let index = payloads.firstIndex(where: { $0.id == payload.id }) {
                        payloads[index] = updated
                    }
                }
            }
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [MobileConfigDocument.mobileConfigType, .xml, .data],
                allowsMultipleSelection: false
            ) { result in
                importProfile(result)
            }
            .sheet(isPresented: $showingPreview) {
                ProfilePreviewView(data: exportDocument.data)
            }
            .fileExporter(
                isPresented: $showingExporter,
                document: exportDocument,
                contentType: MobileConfigDocument.mobileConfigType,
                defaultFilename: exportName
            ) { result in
                if case .failure(let error) = result {
                    errorMessage = error.localizedDescription
                }
            }
            .alert("Unable to create profile", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "Unknown error")
            }
        }
    }

    private var canExport: Bool {
        !displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !identifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !payloads.isEmpty
    }

    private func makePreview() {
        do {
            let data = try ProfileBuilder.make(
                displayName: displayName,
                identifier: identifier,
                organization: organization,
                description: descriptionText,
                payloads: payloads
            )
            exportDocument = MobileConfigDocument(data: data)
            showingPreview = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func exportProfile() {
        do {
            let data = try ProfileBuilder.make(
                displayName: displayName,
                identifier: identifier,
                organization: organization,
                description: descriptionText,
                payloads: payloads
            )
            exportDocument = MobileConfigDocument(data: data)
            exportName = safeFilename(displayName)
            showingExporter = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func importProfile(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else { return }
            let accessed = url.startAccessingSecurityScopedResource()
            defer { if accessed { url.stopAccessingSecurityScopedResource() } }
            let data = try Data(contentsOf: url)
            let imported = try ProfileImporter.read(data)
            displayName = imported.displayName
            identifier = imported.identifier
            organization = imported.organization
            descriptionText = imported.description
            payloads = imported.payloads
        } catch {
            errorMessage = "Import failed: \(error.localizedDescription)"
        }
    }

    private func safeFilename(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        let cleaned = value.replacingOccurrences(of: " ", with: "-")
            .unicodeScalars.filter { allowed.contains($0) }
        return String(String.UnicodeScalarView(cleaned)).isEmpty
            ? "Configuration" : String(String.UnicodeScalarView(cleaned))
    }
}

enum PayloadKind: String, CaseIterable, Identifiable {
    case wifi, webClip, dns, httpProxy, caldav, other

    var id: String { rawValue }
    var title: String {
        switch self {
        case .wifi: return "Wi-Fi Network"
        case .webClip: return "Web Clip"
        case .dns: return "DNS Settings"
        case .httpProxy: return "HTTP Proxy"
        case .caldav: return "Calendar (CalDAV)"
        case .other: return "Other Payload"
        }
    }
    var shortName: String {
        switch self {
        case .wifi: return "Wi-Fi"
        case .webClip: return "Web Clip"
        case .dns: return "DNS"
        case .httpProxy: return "Proxy"
        case .caldav: return "CalDAV"
        case .other: return "Other"
        }
    }
    var symbol: String {
        switch self {
        case .wifi: return "wifi"
        case .webClip: return "safari"
        case .dns: return "network"
        case .httpProxy: return "server.rack"
        case .caldav: return "calendar"
        case .other: return "doc.text"
        }
    }
}

struct ProfilePayload: Identifiable {
    let id: UUID
    let kind: PayloadKind
    let title: String
    let fields: [String: String]
    var rawPayload: [String: Any]? = nil

    var subtitle: String {
        switch kind {
        case .wifi: return fields["SSID"] ?? ""
        case .webClip: return fields["URL"] ?? ""
        case .dns: return fields["Server URL"] ?? fields["Server name"] ?? ""
        case .httpProxy: return fields["Server"] ?? ""
        case .caldav: return fields["Host"] ?? ""
        case .other: return (rawPayload?["PayloadType"] as? String) ?? "Unrecognized payload — preserved"
        }
    }
}

struct PayloadEditorView: View {
    let kind: PayloadKind
    let existing: ProfilePayload?
    let onSave: (ProfilePayload) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var fields: [String: String] = [:]
    @State private var security = "WPA2"
    @State private var dnsProtocol = "HTTPS"
    @State private var autoJoin = true
    @State private var fullScreen = false
    @State private var proxyPort = "8080"
    @State private var calendarPort = "443"
    @State private var calendarSSL = true
    @State private var errorText: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Payload display name", text: $title)
                } header: {
                    Text("General")
                }

                switch kind {
                case .wifi:
                    Section {
                        TextField("Network name (SSID)", text: binding("SSID"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        SecureField("Wi-Fi password", text: binding("Password"))
                        Picker("Security", selection: $security) {
                            Text("WPA2").tag("WPA2")
                            Text("WPA3").tag("WPA3")
                            Text("WEP").tag("WEP")
                            Text("None").tag("None")
                        }
                        Toggle("Auto-join", isOn: $autoJoin)
                    } header: {
                        Text("Wi-Fi configuration")
                    } footer: {
                        Text("The password is stored inside the exported profile. Only share the file with people you trust.")
                    }
                case .webClip:
                    Section {
                        TextField("Website title", text: binding("Label"))
                        TextField("https://example.com", text: binding("URL"))
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        Toggle("Open in full screen", isOn: $fullScreen)
                    } header: {
                        Text("Home Screen shortcut")
                    } footer: {
                        Text("Adds a website shortcut to the Home Screen when the profile is installed.")
                    }
                case .dns:
                    Section {
                        Picker("Protocol", selection: $dnsProtocol) {
                            Text("DNS over HTTPS").tag("HTTPS")
                            Text("DNS over TLS").tag("TLS")
                        }
                        if dnsProtocol == "HTTPS" {
                            TextField("Server URL template", text: binding("Server URL"))
                                .keyboardType(.URL)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        } else {
                            TextField("DNS server IP address(es), comma-separated", text: binding("Server addresses"))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                            TextField("TLS server name", text: binding("Server name"))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        }
                    } header: {
                        Text("Encrypted DNS")
                    } footer: {
                        Text("Use a DNS endpoint provided by a trusted network administrator. The endpoint may affect domain-name lookups on the device.")
                    }
                case .httpProxy:
                    Section {
                        TextField("Proxy server hostname or IP", text: binding("Server"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        TextField("Port", text: $proxyPort)
                            .keyboardType(.numberPad)
                        TextField("Exceptions (comma-separated)", text: binding("Exceptions"))
                    } header: {
                        Text("HTTP proxy")
                    } footer: {
                        Text("Global HTTP Proxy is intended for managed or supervised devices. Verify the server with your network administrator.")
                    }
                case .caldav:
                    Section {
                        TextField("CalDAV server hostname", text: binding("Host"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        TextField("Port", text: $calendarPort)
                            .keyboardType(.numberPad)
                        TextField("Username", text: binding("Username"))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        SecureField("Password (optional)", text: binding("Password"))
                        TextField("Principal URL (optional)", text: binding("Principal URL"))
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        Toggle("Use SSL", isOn: $calendarSSL)
                    } header: {
                        Text("CalDAV account")
                    } footer: {
                        Text("Only add an account for a CalDAV server you trust. Account credentials are stored in the exported profile.")
                    }
                case .other:
                    Text("This payload is preserved as imported and cannot be edited in this version.")
                }
            }
            .navigationTitle(existing == nil ? "Add \(kind.shortName)" : "Edit \(kind.shortName)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(existing == nil ? "Add" : "Save") { save() }
                        .disabled(!isValid)
                }
            }
            .alert("Check the fields", isPresented: Binding(
                get: { errorText != nil },
                set: { if !$0 { errorText = nil } }
            )) {
                Button("OK", role: .cancel) { errorText = nil }
            } message: {
                Text(errorText ?? "")
            }
            .onAppear {
                if let existing {
                    title = existing.title
                    fields = existing.fields
                    security = existing.fields["Security"] ?? "WPA2"
                    dnsProtocol = existing.fields["Protocol"] ?? "HTTPS"
                    autoJoin = existing.fields["AutoJoin"] != "false"
                    fullScreen = existing.fields["FullScreen"] == "true"
                    proxyPort = existing.fields["Port"] ?? "8080"
                    calendarPort = existing.fields["Port"] ?? "443"
                    calendarSSL = existing.fields["SSL"] != "false"
                } else if title.isEmpty {
                    title = kind.title
                }
            }
        }
    }

    private func binding(_ key: String) -> Binding<String> {
        Binding(
            get: { fields[key] ?? "" },
            set: { fields[key] = $0 }
        )
    }

    private var isValid: Bool {
        switch kind {
        case .wifi:
            return !(fields["SSID"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .webClip:
            guard let value = fields["URL"], let url = URL(string: value) else { return false }
            return ["http", "https"].contains(url.scheme?.lowercased() ?? "") && url.host != nil
        case .httpProxy:
            guard let port = Int(proxyPort), (1...65535).contains(port) else { return false }
            return !(fields["Server"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .caldav:
            guard let port = Int(calendarPort), (1...65535).contains(port) else { return false }
            return !(fields["Host"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty &&
                !(fields["Username"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        case .other:
            return false
        case .dns:
            if dnsProtocol == "HTTPS" {
                guard let value = fields["Server URL"], let url = URL(string: value) else { return false }
                return url.scheme == "https" && url.host != nil
            }
            return !(fields["Server addresses"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty &&
                !(fields["Server name"] ?? "").trimmingCharacters(in: .whitespaces).isEmpty
        }
    }

    private func save() {
        guard isValid else {
            errorText = "Enter the required values and check the URL format."
            return
        }
        var values = fields
        if kind == .wifi {
            values["Security"] = security
            values["AutoJoin"] = autoJoin ? "true" : "false"
        } else if kind == .webClip {
            values["FullScreen"] = fullScreen ? "true" : "false"
        } else if kind == .dns {
            values["Protocol"] = dnsProtocol
        } else if kind == .httpProxy {
            values["Port"] = proxyPort
        } else if kind == .caldav {
            values["Port"] = calendarPort
            values["SSL"] = calendarSSL ? "true" : "false"
        }
        onSave(ProfilePayload(
            id: existing?.id ?? UUID(),
            kind: kind,
            title: title.isEmpty ? kind.title : title,
            fields: values,
            rawPayload: nil
        ))
        dismiss()
    }
}

enum ProfileBuilder {
    static func make(
        displayName: String,
        identifier: String,
        organization: String,
        description: String,
        payloads: [ProfilePayload]
    ) throws -> Data {
        let content = payloads.map(makePayload)
        var profile: [String: Any] = [
            "PayloadContent": content,
            "PayloadDescription": description,
            "PayloadDisplayName": displayName,
            "PayloadIdentifier": identifier,
            "PayloadRemovalDisallowed": false,
            "PayloadType": "Configuration",
            "PayloadUUID": UUID().uuidString,
            "PayloadVersion": 1
        ]
        if !organization.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            profile["PayloadOrganization"] = organization
        }
        return try PropertyListSerialization.data(
            fromPropertyList: profile,
            format: .xml,
            options: 0
        )
    }

    private static func makePayload(_ item: ProfilePayload) -> [String: Any] {
        if let raw = item.rawPayload { return raw }
        let payloadType: String
        var settings: [String: Any] = [:]

        switch item.kind {
        case .wifi:
            payloadType = "com.apple.wifi.managed"
            settings["SSID_STR"] = item.fields["SSID"] ?? ""
            settings["AutoJoin"] = item.fields["AutoJoin"] == "true"
            settings["EncryptionType"] = item.fields["Security"] ?? "WPA2"
            if let password = item.fields["Password"], !password.isEmpty,
               (item.fields["Security"] ?? "WPA2") != "None" {
                settings["Password"] = password
            }
        case .webClip:
            payloadType = "com.apple.webClip.managed"
            settings["Label"] = item.fields["Label"] ?? item.title
            settings["URL"] = item.fields["URL"] ?? ""
            settings["IsRemovable"] = true
            settings["FullScreen"] = item.fields["FullScreen"] == "true"
        case .httpProxy:
            payloadType = "com.apple.proxy.http.global"
            settings["ProxyType"] = "Manual"
            settings["ProxyServer"] = item.fields["Server"] ?? ""
            settings["ProxyServerPort"] = Int(item.fields["Port"] ?? "8080") ?? 8080
            let exceptions = (item.fields["Exceptions"] ?? "")
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
            if !exceptions.isEmpty { settings["ProxyExceptionsList"] = exceptions }
        case .caldav:
            payloadType = "com.apple.caldav.account"
            settings["CalDAVHostName"] = item.fields["Host"] ?? ""
            settings["CalDAVPort"] = Int(item.fields["Port"] ?? "443") ?? 443
            settings["CalDAVUsername"] = item.fields["Username"] ?? ""
            settings["CalDAVUseSSL"] = item.fields["SSL"] != "false"
            settings["CalDAVAccountDescription"] = item.title
            if let password = item.fields["Password"], !password.isEmpty {
                settings["CalDAVPassword"] = password
            }
            if let principal = item.fields["Principal URL"], !principal.isEmpty {
                settings["CalDAVPrincipalURL"] = principal
            }
        case .other:
            return item.rawPayload ?? [:]
        case .dns:
            payloadType = "com.apple.dnsSettings.managed"
            let proto = item.fields["Protocol"] ?? "HTTPS"
            var dns: [String: Any] = ["DNSProtocol": proto]
            if proto == "TLS" {
                let addresses = (item.fields["Server addresses"] ?? "")
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                dns["ServerAddresses"] = addresses
                dns["ServerName"] = item.fields["Server name"] ?? ""
            } else {
                dns["ServerURL"] = item.fields["Server URL"] ?? ""
            }
            settings["DNSSettings"] = dns
        }

        settings["PayloadDisplayName"] = item.title
        settings["PayloadIdentifier"] = "com.example.profile.payload.\(item.id.uuidString.lowercased())"
        settings["PayloadType"] = payloadType
        settings["PayloadUUID"] = item.id.uuidString
        settings["PayloadVersion"] = 1
        return settings
    }
}

struct ImportedProfile {
    let displayName: String
    let identifier: String
    let organization: String
    let description: String
    let payloads: [ProfilePayload]
}

enum ProfileImporter {
    static func read(_ data: Data) throws -> ImportedProfile {
        let plistData: Data
        do {
            _ = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
            plistData = data
        } catch {
            plistData = try decodeCMS(data)
        }
        let object = try PropertyListSerialization.propertyList(from: plistData, options: [], format: nil)
        guard let profile = object as? [String: Any],
              (profile["PayloadType"] as? String) == "Configuration" else {
            throw NSError(domain: "ProfileStudio", code: 1, userInfo: [NSLocalizedDescriptionKey: "The selected file is not an Apple configuration profile."])
        }
        let content = profile["PayloadContent"] as? [[String: Any]] ?? []
        return ImportedProfile(
            displayName: profile["PayloadDisplayName"] as? String ?? "Imported Profile",
            identifier: profile["PayloadIdentifier"] as? String ?? "com.example.imported",
            organization: profile["PayloadOrganization"] as? String ?? "",
            description: profile["PayloadDescription"] as? String ?? "",
            payloads: content.map(parsePayload)
        )
    }

    private static func decodeCMS(_ data: Data) throws -> Data {
        var decoder: CMSDecoder?
        guard CMSDecoderCreate(&decoder) == errSecSuccess, let decoder else {
            throw NSError(domain: "ProfileStudio", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not open the signed profile container."])
        }
        let updateStatus = data.withUnsafeBytes { bytes in
            CMSDecoderUpdateMessage(decoder, bytes.baseAddress, data.count)
        }
        guard updateStatus == errSecSuccess, CMSDecoderFinalizeMessage(decoder) == errSecSuccess else {
            throw NSError(domain: "ProfileStudio", code: 3, userInfo: [NSLocalizedDescriptionKey: "The profile is not a readable XML, binary, or signed mobileconfig file."])
        }
        var content: CFData?
        guard CMSDecoderCopyContent(decoder, &content) == errSecSuccess,
              let content else {
            throw NSError(domain: "ProfileStudio", code: 4, userInfo: [NSLocalizedDescriptionKey: "Could not extract the profile contents."])
        }
        return content as Data
    }

    private static func parsePayload(_ raw: [String: Any]) -> ProfilePayload {
        let type = raw["PayloadType"] as? String ?? "unknown"
        let title = raw["PayloadDisplayName"] as? String ?? type
        let uuid = UUID(uuidString: raw["PayloadUUID"] as? String ?? "") ?? UUID()
        var fields: [String: String] = [:]
        let kind: PayloadKind

        switch type {
        case "com.apple.wifi.managed":
            kind = .wifi
            fields["SSID"] = raw["SSID_STR"] as? String ?? ""
            fields["Password"] = raw["Password"] as? String ?? ""
            fields["Security"] = raw["EncryptionType"] as? String ?? "WPA2"
            fields["AutoJoin"] = (raw["AutoJoin"] as? Bool ?? true) ? "true" : "false"
        case "com.apple.webClip.managed":
            kind = .webClip
            fields["Label"] = raw["Label"] as? String ?? title
            fields["URL"] = raw["URL"] as? String ?? ""
            fields["FullScreen"] = (raw["FullScreen"] as? Bool ?? false) ? "true" : "false"
        case "com.apple.dnsSettings.managed":
            kind = .dns
            let dns = raw["DNSSettings"] as? [String: Any] ?? [:]
            let proto = dns["DNSProtocol"] as? String ?? "HTTPS"
            fields["Protocol"] = proto
            fields["Server URL"] = dns["ServerURL"] as? String ?? ""
            fields["Server name"] = dns["ServerName"] as? String ?? ""
            fields["Server addresses"] = (dns["ServerAddresses"] as? [String] ?? []).joined(separator: ", ")
        case "com.apple.proxy.http.global":
            kind = .httpProxy
            fields["Server"] = raw["ProxyServer"] as? String ?? ""
            fields["Port"] = String(raw["ProxyServerPort"] as? Int ?? 8080)
            fields["Exceptions"] = (raw["ProxyExceptionsList"] as? [String] ?? []).joined(separator: ", ")
        case "com.apple.caldav.account":
            kind = .caldav
            fields["Host"] = raw["CalDAVHostName"] as? String ?? ""
            fields["Port"] = String(raw["CalDAVPort"] as? Int ?? 443)
            fields["Username"] = raw["CalDAVUsername"] as? String ?? ""
            fields["Password"] = raw["CalDAVPassword"] as? String ?? ""
            fields["SSL"] = (raw["CalDAVUseSSL"] as? Bool ?? true) ? "true" : "false"
            fields["Principal URL"] = raw["CalDAVPrincipalURL"] as? String ?? ""
        default:
            return ProfilePayload(id: uuid, kind: .other, title: title, fields: [:], rawPayload: raw)
        }
        return ProfilePayload(id: uuid, kind: kind, title: title, fields: fields)
    }
}

struct MobileConfigDocument: FileDocument {
    static var mobileConfigType: UTType { UTType(filenameExtension: "mobileconfig") ?? .data }
    static var readableContentTypes: [UTType] { [mobileConfigType] }
    let data: Data

    init(data: Data) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct ProfilePreviewView: View {
    let data: Data
    @Environment(\.dismiss) private var dismiss

    private var text: String {
        String(data: data, encoding: .utf8) ?? "Unable to display profile."
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text)
                    .font(.system(.footnote, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .navigationTitle("Profile Preview")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

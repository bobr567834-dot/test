import SwiftUI

@main
struct ProfileStudioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

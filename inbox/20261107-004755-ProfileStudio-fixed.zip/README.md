# Profile Studio

A SwiftUI iOS app for creating and editing Apple configuration profiles (`.mobileconfig`).

## Features
- Create profiles with Wi-Fi, Web Clip, encrypted DNS, Global HTTP Proxy, and CalDAV payloads.
- Import XML, binary, and CMS-signed configuration profiles.
- Edit supported imported payloads.
- Preserve unrecognized payload dictionaries when exporting.
- Preview and export `.mobileconfig` files.

## GitHub Actions build

1. Create a GitHub repository.
2. Either upload the **contents** of this archive to the repository root (recommended), or upload this ZIP file into an `inbox/` folder.
3. Open **Actions** and run **Build iOS IPA**, or push to `main` / `master`.
4. Download the `ProfileStudio-unsigned-ipa` artifact from the workflow run.

The workflow supports both layouts and:
- uses `runs-on: macos-15`;
- prints `xcodebuild -version` without selecting an Xcode version;
- installs XcodeGen and generates the `.xcodeproj` from `project.yml`;
- builds with `CODE_SIGNING_ALLOWED=NO` and `generic/platform=iOS`;
- packages `Payload/ProfileStudio.app` into `ProfileStudio.ipa`.

## Important
The IPA is unsigned and cannot be installed directly until it is signed with your own valid Apple signing credentials. Configuration profiles can change device settings. Review every profile before installing it. Wi-Fi and account passwords are stored in exported files when supplied; protect those files accordingly.
